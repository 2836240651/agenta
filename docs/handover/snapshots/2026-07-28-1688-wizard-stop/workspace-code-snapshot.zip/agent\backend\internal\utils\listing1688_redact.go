package utils

import (
	"encoding/json"
	"fmt"
	"strings"

	"commander-agent-t260220/backend/types"
)

// Listing1688RedactCookiePlain 日志用：永不输出 Cookie 明文，仅长度。
func Listing1688RedactCookiePlain(cookie string) string {
	if cookie == "" {
		return ""
	}
	return fmt.Sprintf("*** (len=%d)", len(cookie))
}

// Listing1688RedactCookieInJSON 递归脱敏 JSON 中名为 cookie 的字符串字段。
func Listing1688RedactCookieInJSON(raw []byte) string {
	if len(raw) == 0 {
		return ""
	}
	var v any
	if err := json.Unmarshal(raw, &v); err != nil {
		lower := strings.ToLower(string(raw))
		if strings.Contains(lower, `"cookie"`) {
			return fmt.Sprintf("*** (unparsed json, len=%d, cookie_key_present)", len(raw))
		}
		return string(raw)
	}
	listing1688RedactCookieValue(v)
	out, err := json.Marshal(v)
	if err != nil {
		return "***"
	}
	return string(out)
}

func listing1688RedactCookieValue(v any) {
	switch t := v.(type) {
	case map[string]any:
		for k, val := range t {
			if strings.EqualFold(k, "cookie") {
				if s, ok := val.(string); ok {
					t[k] = Listing1688RedactCookiePlain(s)
					continue
				}
			}
			listing1688RedactCookieValue(val)
		}
	case []any:
		for _, item := range t {
			listing1688RedactCookieValue(item)
		}
	}
}

// Listing1688RedactAgentMessageCopy 返回脱敏副本，供 UI 事件发射；不改动原消息（探针仍需明文 Cookie）。
func Listing1688RedactAgentMessageCopy(msg types.AgentMessage[any, any]) types.AgentMessage[any, any] {
	raw, err := json.Marshal(msg)
	if err != nil {
		out := msg
		out.Send = nil
		out.Receive = nil
		return out
	}
	var v any
	if err := json.Unmarshal(raw, &v); err != nil {
		out := msg
		out.Send = nil
		out.Receive = nil
		return out
	}
	listing1688RedactCookieValue(v)
	cleaned, err := json.Marshal(v)
	if err != nil {
		out := msg
		out.Send = nil
		out.Receive = nil
		return out
	}
	var out types.AgentMessage[any, any]
	if err := json.Unmarshal(cleaned, &out); err != nil {
		fallback := msg
		fallback.Send = nil
		fallback.Receive = nil
		return fallback
	}
	return out
}
