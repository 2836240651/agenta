import { createRouter, createWebHashHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { api } from '@/api'

const routes = [
  {
    path: '/',
    name: 'marketing',
    component: () => import('@/views/marketing/index.vue'),
    meta: { requiresAuth: false, isPublicShell: true }
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/auth/SignInPage.vue'),
    meta: { requiresAuth: false, isPublicShell: true }
  },
  {
    path: '/register',
    name: 'register',
    component: () => import('@/views/auth/RegisterPage.vue'),
    meta: { requiresAuth: false, isPublicShell: true }
  },
  {
    path: '/welcome',
    name: 'welcome',
    component: () => import('@/views/welcome/index.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/admin',
    name: 'admin',
    component: () => import('@/views/admin/index.vue'),
    meta: { requiresAuth: true, requiresAdmin: true }
  },
  {
    path: '/profile',
    name: 'profile',
    component: () => import('@/views/profile/index.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/auto-upload',
    name: 'auto-upload',
    component: () => import('@/views/platform-entrance/auto-upload.vue'),
    meta: { requiresAuth: true }
  },
  // AliExpress 自动上货：与 TEMU 矩阵同一套页面与逻辑，默认平台为 aliexpress
  {
    path: '/aliexpress-auto-upload',
    name: 'aliexpress-auto-upload',
    component: () => import('@/views/platform-entrance/auto-upload.vue'),
    meta: { requiresAuth: true }
  },
  // Ozon 自动上货：与 TEMU 同一套页面与逻辑，默认平台为 temu
  {
    path: '/ozon-auto-upload',
    name: 'ozon-auto-upload',
    component: () => import('@/views/platform-entrance/auto-upload.vue'),
    meta: { requiresAuth: true }
  },
  // 1688 工作台主入口：订单 / 热词 / 热销 + 上架入口（矩阵页）
  {
    path: '/1688-auto-upload',
    name: '1688-auto-upload',
    component: () => import('@/views/platform-entrance/index.vue'),
    meta: { requiresAuth: true }
  },
  // 1688 自动上架：粘贴同行链接 → 采集图优 → 妙手导入（v1 一键）
  {
    path: '/1688-auto-upload/listing',
    name: '1688-listing',
    component: () => import('@/views/platform-entrance/auto-upload.vue'),
    meta: { requiresAuth: true }
  },
  // 1688 竞品向导：采集登录 → CDP 采集 → 图优 → 商家后台发品（Wizard v2）
  {
    path: '/1688-auto-upload/wizard',
    name: '1688-listing-wizard',
    component: () => import('@/views/platform-entrance/listing1688-wizard/index.vue'),
    meta: { requiresAuth: true }
  },
  // 多平台占位页：统一组件，路径与名称保持兼容（不含 aliexpress / ozon / 1688）
  ...[
    'amazon', 'tiktok', 'walmart', 'pinduoduo', 'douyin'
  ].map((platform) => ({
    path: `/${platform}-auto-upload`,
    name: `${platform}-auto-upload`,
    component: () => import('@/views/platform-entrance/index.vue'),
    meta: { requiresAuth: true }
  })),
  {
    path: '/auto-upload/agent/:agentId',
    name: 'auto-upload-agent',
    component: () => import('@/views/platform-entrance/components/auto-upload/AgentWorkspace.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/aliexpress-auto-upload/agent/:agentId',
    name: 'aliexpress-auto-upload-agent',
    component: () => import('@/views/platform-entrance/components/auto-upload/AgentWorkspace.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/ozon-auto-upload/agent/:agentId',
    name: 'ozon-auto-upload-agent',
    component: () => import('@/views/platform-entrance/components/auto-upload/AgentWorkspace.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/1688-auto-upload/listing/agent/:agentId',
    name: '1688-listing-agent',
    component: () => import('@/views/platform-entrance/components/auto-upload/AgentWorkspace.vue'),
    meta: { requiresAuth: true }
  },
  // 兼容旧链接：/1688-auto-upload/agent/:id → listing 工作台
  {
    path: '/1688-auto-upload/agent/:agentId',
    redirect: (to) => `/1688-auto-upload/listing/agent/${to.params.agentId}`
  },
  {
    path: '/support',
    name: 'support',
    component: () => import('@/views/support/index.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/tickets',
    name: 'tickets',
    component: () => import('@/views/tickets/index.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/reptile-analytical-words',
    name: 'reptile-analytical-words',
    component: () => import('@/views/reptile-analytical-words/index.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/chat',
    name: 'chat',
    component: () => import('@/views/chat/index.vue'),
    meta: { requiresAuth: true }
  },
  // AI 生图：独立模块（原 /chat/ai-image 保留重定向）
  {
    path: '/ai-image',
    name: 'ai-image',
    component: () => import('@/views/ai-image/index.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/ae-csp-template-recorder',
    name: 'ae-csp-template-recorder',
    component: () => import('@/views/ae-csp-template-recorder/index.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/chat/ai-image',
    redirect: '/ai-image'
  }
]

const router = createRouter({
  // Hash：避免静态托管下深度链接刷新 404；要干净 URL 需在服务端回退 index.html 并改用 createWebHistory
  history: createWebHashHistory(),
  routes
})

// 路由守卫
router.beforeEach(async (to, from, next) => {
  const accessToken = localStorage.getItem('accessToken')
  const isAuthenticated = accessToken && localStorage.getItem('isAuthenticated') === 'true'

  if (to.meta.requiresAuth && !isAuthenticated) {
    next('/login')
    return
  }
  // 已登录用户访问营销页 / 登录 / 注册：跳转工作台
  if ((to.path === '/' || to.path === '/login' || to.path === '/register') && isAuthenticated) {
    const authStore = useAuthStore()
    next(authStore.isAdmin ? '/admin' : '/welcome')
    return
  }
  // 进入需鉴权页面时，若尚未有 role（超级管理员判断依赖），先拉取用户信息
  if (to.meta.requiresAuth && isAuthenticated && (to.path === '/welcome' || to.path === '/admin')) {
    const authStore = useAuthStore()
    if (!authStore.role && authStore.username?.toLowerCase() !== 'admin') {
      try {
        const info = await api.getUserInfo({ skipGlobalErrorToast: true })
        const d = info?.data ?? info
        if (d?.role) authStore.setRole(d.role)
      } catch (_) {}
    }
  }
  // admin 用户访问 /welcome 时重定向到 /admin
  if (to.path === '/welcome' && isAuthenticated) {
    const authStore = useAuthStore()
    if (authStore.isAdmin) {
      next('/admin')
      return
    }
  }
  // 非 admin 用户访问 /admin 时重定向到 /welcome
  if (to.meta.requiresAdmin && isAuthenticated) {
    const authStore = useAuthStore()
    if (!authStore.isAdmin) {
      next('/welcome')
      return
    }
  }
  next()
})

export default router
