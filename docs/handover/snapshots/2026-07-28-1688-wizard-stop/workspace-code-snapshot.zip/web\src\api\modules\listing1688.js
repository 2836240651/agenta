import { service } from '../request.js'
import { stripCookieKeys } from '@/utils/listing1688CookieStrip.js'

/** AC-08 / TC-X-01：unwrap 后剥离 cookie 明文键（防御性；服务端本不应回传） */
function unwrap(res) {
  return stripCookieKeys(res?.data ?? res)
}

/** 创建 draft Workflow（选 Agent 后） */
export async function createListing1688Workflow(agentId, config = {}) {
  const res = await service.post(
    '/api/v1/listing1688/workflows',
    { agent_id: agentId },
    { skipGlobalErrorToast: true, ...config }
  )
  return unwrap(res)
}

/** 读取 Workflow */
export async function getListing1688Workflow(workflowId, config = {}) {
  const res = await service.get(`/api/v1/listing1688/workflows/${workflowId}`, {
    skipGlobalErrorToast: true,
    ...config
  })
  return unwrap(res)
}

export async function listing1688SessionOpenLogin(workflowId, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/session/open-login`, null, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688SessionConfirm(workflowId, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/session/confirm`, null, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688SessionValidate(workflowId, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/session/validate`, null, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688Collect(workflowId, body, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/collect`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688CollectRetry(workflowId, body, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/collect/retry`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688ImagesGenerate(workflowId, body, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/images/generate`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688ImagesRegenerate(workflowId, body, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/images/regenerate`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688ImagesSelect(workflowId, body, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/images/select`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688ImagesUseOriginal(workflowId, body, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/images/use-original`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688SellerOpenLogin(workflowId, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/session/seller/open-login`, null, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688SellerConfirm(workflowId, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/session/seller/confirm`, null, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688SellerValidate(workflowId, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/session/seller/validate`, null, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688TemplateCandidates(workflowId, body = {}, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/templates/candidates`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688TemplateSelect(workflowId, body = {}, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/templates/select`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688TemplateOpenSimilar(workflowId, body = {}, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/templates/open-similar`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688CategoryInspect(workflowId, body = {}, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/category/inspect`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688PublishFormValidate(workflowId, body = {}, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/form/validate`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688PublishFormSaveDraft(workflowId, body = {}, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/form/save-draft`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688Publish(workflowId, body, config = {}) {
  return unwrap(
    await service.post(`/api/v1/listing1688/workflows/${workflowId}/publish`, body, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}

export async function listing1688PublishStatus(workflowId, config = {}) {
  return unwrap(
    await service.get(`/api/v1/listing1688/workflows/${workflowId}/publish/status`, {
      skipGlobalErrorToast: true,
      ...config
    })
  )
}
