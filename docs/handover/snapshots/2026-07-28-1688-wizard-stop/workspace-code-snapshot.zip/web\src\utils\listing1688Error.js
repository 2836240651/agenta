/** 1688 错误码 → 中文文案
 * - v1 一键：listing_1688_error.go
 * - 向导 v2：listing_1688_wizard.go（AC-05 catalog）
 */

/** v1 一键上架（勿与向导 AGENT_OFFLINE / PUBLISH_FAILED 短码混用） */
const LISTING_1688_V1_ERROR_MESSAGES = {
  LISTING_1688_INVALID_PEER_URL: '同行链接无效，请粘贴 1688 商品详情页链接',
  LISTING_1688_COLLECT_FAILED: '采集同行商品失败，请稍后重试',
  LISTING_1688_COLLECT_NO_IMAGE: '未采集到商品图片，请更换链接',
  LISTING_1688_IMG2IMG_FAILED: '图生图全部失败，请稍后重试',
  LISTING_1688_IMG2IMG_PARTIAL_FAIL: '部分图片图生图失败，任务已终止',
  LISTING_1688_AGENT_OFFLINE: 'Agent 未在线，请先启动客户端',
  LISTING_1688_PUBLISH_FAILED: '妙手 1688 上架失败',
  LISTING_1688_PUBLISH_UNSUPPORTED: '妙手 1688 导入尚未就绪（联调中）',
  LISTING_1688_INTERNAL: '系统内部错误，请联系管理员'
}

/** 向导 AC-05 catalog（与 Server Listing1688WizardErrorCatalog 对齐） */
export const LISTING_1688_WIZARD_ERROR_CODES = [
  'LISTING_1688_WORKFLOW_NOT_FOUND',
  'LISTING_1688_INVALID_AGENT',
  'LISTING_1688_NOT_IMPLEMENTED',
  'SELLER_SESSION_INVALID',
  'COLLECT_NEED_LOGIN',
  'COLLECT_PARSE_FAIL',
  'COLLECT_CAPTCHA',
  'IMAGES_NOT_READY',
  'SESSION_INVALID',
  'PUBLISH_FAILED',
  'AGENT_OFFLINE'
]

/** 兜底中文（无 i18n 时）；正式 UI 走 listing1688Wizard.errors.* */
export const LISTING_1688_WIZARD_ERROR_BASELINE = {
  AGENT_OFFLINE: 'Agent 未在线',
  SESSION_INVALID: '采集会话无效，请重新登录',
  COLLECT_NEED_LOGIN: '请先完成 1688 采集登录',
  COLLECT_CAPTCHA: '遇到验证码，请在 Agent 浏览器处理后重试',
  COLLECT_PARSE_FAIL: '竞品解析失败',
  IMAGES_NOT_READY: '请完成全部图片选定后再发品',
  SELLER_SESSION_INVALID: '请先登录 1688 商家中心',
  PUBLISH_FAILED: '商家发品失败，可重试',
  LISTING_1688_WORKFLOW_NOT_FOUND: '工作流不存在或无权访问',
  LISTING_1688_INVALID_AGENT: 'Agent 无效',
  LISTING_1688_NOT_IMPLEMENTED: '该步骤尚未实现，请等待后续里程碑'
}

const LISTING_1688_ERROR_MESSAGES = {
  ...LISTING_1688_V1_ERROR_MESSAGES,
  ...LISTING_1688_WIZARD_ERROR_BASELINE
}

/** 从 `CODE: 中文` 或纯 code 解析向导错误码；未知返回 '' */
export function parseWizardErrorCode(raw) {
  if (!raw || typeof raw !== 'string') return ''
  const msg = raw.trim()
  for (const code of LISTING_1688_WIZARD_ERROR_CODES) {
    if (msg === code || msg.startsWith(code + ':') || msg.startsWith(code + ' ')) {
      return code
    }
  }
  // 兼容旧向导路径误用 v1 Agent 离线码
  if (msg.includes('LISTING_1688_AGENT_OFFLINE')) {
    return 'AGENT_OFFLINE'
  }
  return ''
}

/**
 * 向导专用：映射为「码 + 中文」。
 * @param {string} raw API msg / error_code
 * @param {(key: string) => string} [t] vue-i18n t；传入时用 listing1688Wizard.errors.*
 * @returns {string} 已知码 → `CODE: 中文`；未知 → 原文
 */
export function mapWizardError(raw, t) {
  if (!raw || typeof raw !== 'string') return raw
  const code = parseWizardErrorCode(raw)
  if (!code) {
    return mapListing1688ErrorMessage(raw)
  }
  let zh = LISTING_1688_WIZARD_ERROR_BASELINE[code] || ''
  if (typeof t === 'function') {
    const key = `listing1688Wizard.errors.${code}`
    const translated = t(key)
    if (translated && translated !== key) {
      zh = translated
    }
  }
  if (!zh) {
    return raw
  }
  return `${code}: ${zh}`
}

/** v1 + 向导共用：只返回中文文案（不含码前缀）；未知回退原文 */
export function mapListing1688ErrorMessage(raw) {
  if (!raw || typeof raw !== 'string') return raw
  const wizardCode = parseWizardErrorCode(raw)
  if (wizardCode && LISTING_1688_WIZARD_ERROR_BASELINE[wizardCode]) {
    return LISTING_1688_WIZARD_ERROR_BASELINE[wizardCode]
  }
  for (const [code, msg] of Object.entries(LISTING_1688_ERROR_MESSAGES)) {
    if (raw.includes(code)) return msg
  }
  return raw
}
