package alibaba

import (
	"commander-agent-t260220/backend/internal/offer1688"
	"commander-agent-t260220/backend/internal/utils"
	"commander-agent-t260220/backend/types"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/proto"
)

const listing1688LoginURL = "https://login.1688.com/member/signin.htm?Done=https://www.1688.com/"
const listing1688CollectHomeURL = "https://www.1688.com/"

// 采集登录 Cookie 标记（对齐 D:\reverselab\1688-\alibaba_1688_login.py LOGIN_COOKIE_MARKERS）
var listing1688LoginCookieMarkers = []string{"lid", "unb", "cookie2", "_nk_", "sgcookie", "cna"}

// Listing1688OpenLogin 仅在 Agent 托管 Chrome（Rod Profile）内操作：
// 复用已有采集相关标签并前置；已登录则停在 www.1688.com，未登录再进登录页。
// 禁止新开多余标签；禁止依赖主浏览器 / Cursor 内嵌页。
func (f *AlibabaFactory) Listing1688OpenLogin(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	_ = payload
	if f.browser == nil || !f.browser.IsReady() {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未就绪"), nil
	}
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未初始化"), nil
	}
	page, reused := listing1688AcquireCollectPage(rodBrowser)
	if page == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 无法打开 Agent 浏览器页"), nil
	}
	target := listing1688CollectHomeURL
	if err := rod.Try(func() {
		page.MustNavigate(listing1688CollectHomeURL)
		page.MustWaitLoad()
	}); err != nil {
		return types.AgentTaskResponse{}.Error("SESSION_INVALID: 打开 1688 首页失败: " + err.Error()), nil
	}
	time.Sleep(600 * time.Millisecond)
	info, _ := page.Info()
	finalURL := listing1688CollectHomeURL
	if info != nil && info.URL != "" {
		finalURL = info.URL
	}
	html, _ := page.HTML()
	// Cookie 标记为准；首页 HTML 常含登录入口文案，勿据此误判未登录
	cookie, _ := listing1688CookiesFromPage(page)
	needLogin := !listing1688HasLoginCookieMarkers(cookie)
	if needLogin && listing1688CollectLooksLoggedOut(finalURL, html) {
		needLogin = true
	}
	if needLogin {
		target = listing1688LoginURL
		if err := rod.Try(func() {
			page.MustNavigate(listing1688LoginURL)
			page.MustWaitLoad()
		}); err != nil {
			return types.AgentTaskResponse{}.Error("SESSION_INVALID: 打开 1688 登录页失败: " + err.Error()), nil
		}
		finalURL = listing1688LoginURL
		if info2, _ := page.Info(); info2 != nil && info2.URL != "" {
			finalURL = info2.URL
		}
	}
	listing1688ActivatePage(page)
	hint := "请在 Agent 弹出的 Chrome 窗口完成 1688 登录（不是本机主浏览器 / 不是 Cursor 内嵌页），然后点「我已登录」"
	if !needLogin {
		hint = "Agent 浏览器已检测到 1688 登录态，可直接点「我已登录」校验（不会再新开页面）"
	}
	return types.AgentTaskResponse{}.Success(map[string]any{
		"login_url":  target,
		"opened":     true,
		"reused":     reused,
		"need_login": needLogin,
		"url":        finalURL,
		"hint":       hint,
		"open_in":    "agent_chrome",
	}), nil
}

// listing1688AcquireCollectPage 优先复用 www/login/detail 采集页；避开 work/sycm（Init 常开、勿抢商家页）。
func listing1688AcquireCollectPage(b *rod.Browser) (*rod.Page, bool) {
	prefer := []string{"www.1688.com", "login.1688.com", "detail.1688.com", "login.taobao.com"}
	avoid := []string{"work.1688.com", "sycm.1688.com"}
	if pages, err := b.Pages(); err == nil {
		var fallback *rod.Page
		for _, p := range pages {
			info, ierr := p.Info()
			if ierr != nil || info == nil {
				continue
			}
			u := strings.ToLower(info.URL)
			skip := false
			for _, a := range avoid {
				if strings.Contains(u, a) {
					skip = true
					break
				}
			}
			if skip {
				continue
			}
			for _, pref := range prefer {
				if strings.Contains(u, pref) {
					return p, true
				}
			}
			if fallback == nil && strings.Contains(u, "1688.com") {
				fallback = p
			}
		}
		if fallback != nil {
			return fallback, true
		}
		// 任意空白页可复用，避免再开
		for _, p := range pages {
			info, ierr := p.Info()
			if ierr != nil || info == nil {
				continue
			}
			u := strings.ToLower(info.URL)
			if u == "" || u == "about:blank" || strings.HasPrefix(u, "chrome://") {
				return p, true
			}
		}
	}
	return b.MustPage("about:blank"), false
}

func listing1688ActivatePage(page *rod.Page) {
	if page == nil {
		return
	}
	_ = rod.Try(func() {
		page.MustActivate()
	})
}

// Listing1688ExportCookie 导出当前浏览器 1688 相关 Cookie（明文仅经 SyncSend 回传一次）。
// 不新开标签：在已有页上 NetworkGetCookies。
func (f *AlibabaFactory) Listing1688ExportCookie(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	_ = payload
	cookie, err := f.exportMerged1688Cookies()
	if err != nil {
		return types.AgentTaskResponse{}.Error("COLLECT_NEED_LOGIN: " + err.Error()), nil
	}
	if strings.TrimSpace(cookie) == "" {
		return types.AgentTaskResponse{}.Error("COLLECT_NEED_LOGIN: Cookie 为空，请先在 Agent 浏览器完成 1688 登录"), nil
	}
	return types.AgentTaskResponse{}.Success(map[string]any{
		"cookie": cookie,
	}), nil
}

// Listing1688Probe 校验采集登录态（买家 Cookie 即可）。
// 复用已有标签，禁止 MustPage 弹新窗；也不再二次 export 开页。
func (f *AlibabaFactory) Listing1688Probe(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	_ = payload
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未初始化"), nil
	}
	page, _ := listing1688AcquireCollectPage(rodBrowser)
	if page == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 无法取得浏览器页"), nil
	}
	// 仅当当前不在 1688 域时才导航首页（避免每次 confirm 都刷新）
	info, _ := page.Info()
	cur := ""
	if info != nil {
		cur = info.URL
	}
	needNav := cur == "" || (!strings.Contains(strings.ToLower(cur), "1688.com") && !strings.Contains(strings.ToLower(cur), "taobao.com"))
	if needNav {
		if err := page.Navigate(listing1688CollectHomeURL); err != nil {
			return types.AgentTaskResponse{}.Error("SESSION_INVALID: 打开 1688 首页失败: " + err.Error()), nil
		}
		// The 1688 homepage can recreate the execution context during redirects.
		// Avoid MustWaitLoad here and re-check page state after a short settle delay.
		time.Sleep(1200 * time.Millisecond)
		info, _ = page.Info()
		if info != nil {
			cur = info.URL
		}
	}
	html, _ := page.HTML()
	finalURL := cur
	cookie, err := listing1688CookiesFromPage(page)
	if err != nil || strings.TrimSpace(cookie) == "" {
		return types.AgentTaskResponse{}.Error("SESSION_INVALID: Cookie 为空，请先在 Agent 浏览器登录 1688"), nil
	}
	if listing1688CollectLooksLoggedOut(finalURL, html) && !listing1688HasLoginCookieMarkers(cookie) {
		return types.AgentTaskResponse{}.Error("SESSION_INVALID: 未检测到 1688 登录态，请在 Agent 浏览器完成登录"), nil
	}
	if !listing1688HasLoginCookieMarkers(cookie) {
		return types.AgentTaskResponse{}.Error("SESSION_INVALID: 缺少登录 Cookie 标记（lid/unb/cookie2 等）"), nil
	}
	// 有登录 Cookie 即过：首页 HTML 偶发含登录入口文案，勿误杀
	return types.AgentTaskResponse{}.Success(map[string]any{
		"ok":      true,
		"code":    0,
		"message": "browser collect session ok",
		"url":     finalURL,
	}), nil
}

func listing1688CollectLooksLoggedOut(url, html string) bool {
	u := strings.ToLower(url)
	// 仅当最终落在登录 URL 才算未登录；首页 HTML 里常有 login 链接勿误判
	if strings.Contains(u, "login.1688.com") || strings.Contains(u, "member/signin") || strings.Contains(u, "login.taobao.com") {
		return true
	}
	h := html
	if len(h) > 8000 {
		h = h[:8000]
	}
	hl := strings.ToLower(h)
	// title/首屏明确是登录页
	if strings.Contains(hl, "<title") && (strings.Contains(h, "密码登录") || strings.Contains(h, "扫码登录")) &&
		!strings.Contains(h, "我的阿里") && !strings.Contains(strings.ToLower(h), "tb") {
		return true
	}
	return false
}

func listing1688HasLoginCookieMarkers(cookieHeader string) bool {
	lower := strings.ToLower(cookieHeader)
	hit := 0
	for _, name := range listing1688LoginCookieMarkers {
		if strings.Contains(lower, strings.ToLower(name)+"=") {
			hit++
		}
	}
	// 至少命中 2 个常见登录标记，避免仅有 cna 误过
	return hit >= 2
}

// Listing1688FetchOffer CDP 打开详情页取 HTML，解析移植自 1688-/fetch_1688_offer.py
// 对齐 1688-：优先复用已打开标签（过验证码后勿强制新开导航，避免再次风控）。
func (f *AlibabaFactory) Listing1688FetchOffer(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	raw, _ := json.Marshal(payload.Send)
	var body struct {
		URL    string `json:"url"`
		Cookie string `json:"cookie"`
	}
	_ = json.Unmarshal(raw, &body)
	url := offer1688.NormalizeURL(body.URL)
	offerID := offer1688.ExtractOfferID(url)
	if offerID == "" {
		return types.AgentTaskResponse{}.Error("COLLECT_PARSE_FAIL: 无法从 URL 解析 offerId"), nil
	}
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未初始化"), nil
	}

	page, created, err := listing1688AcquireOfferPage(rodBrowser, url, offerID)
	if err != nil {
		return types.AgentTaskResponse{}.Error("COLLECT_PARSE_FAIL: 打开详情页失败: " + err.Error()), nil
	}
	closePage := created // 复用标签不关；新建页解析成功后关闭
	defer func() {
		if closePage {
			_ = page.Close()
		}
	}()

	if !created {
		info, _ := page.Info()
		currentURL := ""
		if info != nil {
			currentURL = info.URL
		}
		// Reused tabs may still be parked on 1688 home/notfound after a soft block.
		// Always drive the reused tab back to the target offer page before parsing.
		if !strings.Contains(currentURL, "offer/"+offerID) {
			if navErr := page.Navigate(url); navErr != nil {
				return types.AgentTaskResponse{}.Error("COLLECT_PARSE_FAIL: 跳转详情页失败: " + navErr.Error()), nil
			}
			time.Sleep(1200 * time.Millisecond)
		}
	}

	html, finalURL, err := listing1688WaitOfferHTML(page, url)
	if err != nil {
		return types.AgentTaskResponse{}.Error("COLLECT_PARSE_FAIL: 读取 HTML 失败: " + err.Error()), nil
	}
	// 复用标签仍是验证码壳：在同一页 Navigate 到 offer（Cookie 已落盘），再读一次
	if offer1688.IsCaptchaPage(html, finalURL) && !created {
		if navErr := rod.Try(func() {
			page.MustNavigate(url)
			page.MustWaitLoad()
		}); navErr == nil {
			html, finalURL, err = listing1688WaitOfferHTML(page, url)
			if err != nil {
				return types.AgentTaskResponse{}.Error("COLLECT_PARSE_FAIL: 读取 HTML 失败: " + err.Error()), nil
			}
		}
	}
	if offer1688.IsCaptchaPage(html, finalURL) {
		closePage = false
		listing1688DumpCollectDebug(html, finalURL, "COLLECT_CAPTCHA")
		listing1688DumpPageInventory(rodBrowser)
		return types.AgentTaskResponse{}.Error("COLLECT_CAPTCHA: 遇到验证码，请在 Agent 浏览器完成后再点重试"), nil
	}
	// 软拦截：详情被踢回首页/notfound 且无商品字段（常见于 bxpunish 后无滑块壳）
	if listing1688LooksSoftBlocked(finalURL, html, offerID) {
		closePage = false
		listing1688DumpCollectDebug(html, finalURL, "soft_block_notfound_home")
		listing1688DumpPageInventory(rodBrowser)
		return types.AgentTaskResponse{}.Error("COLLECT_CAPTCHA: 详情被拦截跳转首页，请在 Agent 浏览器打开该链接完成验证后再点重试"), nil
	}
	if offer1688.NeedsLogin(html, finalURL) {
		return types.AgentTaskResponse{}.Error("COLLECT_NEED_LOGIN: 需要重新登录采集会话"), nil
	}
	parsed := offer1688.ParseProductFromHTML(html, url, offerID, finalURL)
	if !parsed.OK {
		code := "COLLECT_PARSE_FAIL"
		if parsed.Captcha {
			closePage = false
			code = "COLLECT_CAPTCHA"
		} else if parsed.NeedLogin {
			code = "COLLECT_NEED_LOGIN"
		}
		listing1688DumpCollectDebug(html, finalURL, parsed.Error)
		return types.AgentTaskResponse{}.Error(code + ": " + parsed.Error), nil
	}
	return types.AgentTaskResponse{}.Success(parsed), nil
}

// listing1688AcquireOfferPage 优先复用含 offerId / 1688 验证码残留页的标签；否则新建并导航。
// 返回 created=true 表示本次新建（成功解析后可关）；created=false 为复用（勿关）。
func listing1688AcquireOfferPage(b *rod.Browser, offerURL, offerID string) (*rod.Page, bool, error) {
	pages, err := b.Pages()
	if err == nil {
		var offerPage, captchaPage *rod.Page
		for _, p := range pages {
			info, ierr := p.Info()
			if ierr != nil || info == nil {
				continue
			}
			u := info.URL
			if offerID != "" && strings.Contains(u, "offer/"+offerID) {
				offerPage = p
				break
			}
			if captchaPage == nil && (strings.Contains(u, "_____tmd_____") ||
				strings.Contains(u, "detail.1688.com") ||
				(strings.Contains(u, "1688.com") && strings.Contains(u, "notfound"))) {
				captchaPage = p
			}
		}
		if offerPage != nil {
			return offerPage, false, nil
		}
		if captchaPage != nil {
			return captchaPage, false, nil
		}
	}
	page := b.MustPage(offerURL)
	if err := rod.Try(func() { page.MustWaitLoad() }); err != nil {
		_ = page.Close()
		return nil, true, err
	}
	return page, true, nil
}

// listing1688WaitOfferHTML 对齐 1688-：load 后最多约 8 次 × 0.8s，要求 HTML>8k 且出现商品标记。
func listing1688WaitOfferHTML(page *rod.Page, fallbackURL string) (html, finalURL string, err error) {
	finalURL = fallbackURL
	productMarkers := []string{"window.context", "offerDetail", "skuMap", "application/ld+json", "og:title", "__INIT_DATA"}
	for i := 0; i < 10; i++ {
		if i == 0 {
			time.Sleep(2 * time.Second) // 首轮给 SPA 注入 window.context
		} else {
			time.Sleep(800 * time.Millisecond)
		}
		html, err = page.HTML()
		if err != nil {
			return "", finalURL, err
		}
		info, _ := page.Info()
		if info != nil && info.URL != "" {
			finalURL = info.URL
		}
		bodyLen := 0
		if ev, e := page.Eval(`() => document.body ? document.body.innerText.length : 0`); e == nil && ev != nil {
			bodyLen = ev.Value.Int()
		}
		hasMarker := false
		for _, m := range productMarkers {
			if strings.Contains(html, m) {
				hasMarker = true
				break
			}
		}
		if len(html) > 8000 && bodyLen > 500 && hasMarker {
			return html, finalURL, nil
		}
		// 验证码/登录页提前结束，避免空等
		if offer1688.IsCaptchaPage(html, finalURL) || offer1688.NeedsLogin(html, finalURL) {
			return html, finalURL, nil
		}
	}
	return html, finalURL, nil
}

func listing1688LooksSoftBlocked(finalURL, html, offerID string) bool {
	u := strings.ToLower(finalURL)
	// 期望在 detail offer 页；落到首页 / notfound / 无 offerId
	onOffer := offerID != "" && strings.Contains(u, "offer/"+offerID)
	if onOffer {
		return false
	}
	homeOrMissing := strings.Contains(u, "notfound") ||
		strings.HasPrefix(u, "https://www.1688.com") ||
		strings.HasPrefix(u, "http://www.1688.com")
	if !homeOrMissing {
		return false
	}
	for _, m := range []string{"window.context", "offerDetail", "skuMap", "og:title", "__INIT_DATA"} {
		if strings.Contains(html, m) {
			return false
		}
	}
	return true
}

func listing1688DumpCollectDebug(html, finalURL, reason string) {
	dir := filepath.Join("agent", "logs")
	_ = os.MkdirAll(dir, 0o755)
	meta := fmt.Sprintf("final_url=%s\nreason=%s\nhtml_len=%d\n", finalURL, reason, len(html))
	_ = os.WriteFile(filepath.Join(dir, "collect-debug-meta.txt"), []byte(meta), 0o644)
	_ = os.WriteFile(filepath.Join(dir, "collect-debug.html"), []byte(html), 0o644)
}

func listing1688DumpPageInventory(b *rod.Browser) {
	if b == nil {
		return
	}
	pages, err := b.Pages()
	if err != nil {
		return
	}
	var sb strings.Builder
	for idx, p := range pages {
		info, ierr := p.Info()
		if ierr != nil || info == nil {
			sb.WriteString(fmt.Sprintf("[%d] <info error: %v>\n", idx, ierr))
			continue
		}
		sb.WriteString(fmt.Sprintf("[%d] title=%s\nurl=%s\n\n", idx, info.Title, info.URL))
	}
	dir := filepath.Join("agent", "logs")
	_ = os.MkdirAll(dir, 0o755)
	_ = os.WriteFile(filepath.Join(dir, "collect-debug-pages.txt"), []byte(sb.String()), 0o644)
}

func (f *AlibabaFactory) exportMerged1688Cookies() (string, error) {
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return "", fmt.Errorf("浏览器未初始化")
	}
	page, created := listing1688AcquireCookiePage(rodBrowser)
	if page == nil {
		return "", fmt.Errorf("浏览器未初始化")
	}
	if created {
		defer func() { _ = page.Close() }()
	}
	return listing1688CookiesFromPage(page)
}

// listing1688AcquireCookiePage 取一页用于 NetworkGetCookies；优先复用，仅必要时开 about:blank。
func listing1688AcquireCookiePage(b *rod.Browser) (*rod.Page, bool) {
	if pages, err := b.Pages(); err == nil && len(pages) > 0 {
		return pages[0], false
	}
	return b.MustPage("about:blank"), true
}

func listing1688CookiesFromPage(page *rod.Page) (string, error) {
	if page == nil {
		return "", fmt.Errorf("页面为空")
	}
	merged := map[string]string{}
	for _, u := range []string{
		"https://www.1688.com",
		"https://work.1688.com",
		"https://detail.1688.com",
		"https://sycm.1688.com",
		"https://login.1688.com",
	} {
		res, err := (&proto.NetworkGetCookies{Urls: []string{u}}).Call(page)
		if err != nil {
			continue
		}
		for _, c := range res.Cookies {
			merged[c.Name] = c.Value
		}
	}
	if len(merged) == 0 {
		return "", fmt.Errorf("未获取到 Cookie")
	}
	parts := make([]string, 0, len(merged))
	for k, v := range merged {
		parts = append(parts, fmt.Sprintf("%s=%s", k, v))
	}
	return strings.Join(parts, "; "), nil
}

func getRodBrowser(b *utils.Browser) *rod.Browser {
	if b == nil {
		return nil
	}
	return b.RodBrowser()
}
