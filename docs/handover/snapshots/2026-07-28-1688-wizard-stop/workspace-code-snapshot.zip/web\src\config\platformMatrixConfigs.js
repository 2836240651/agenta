/**
 * 矩阵占位页：各路由 name 对应的展示配置（中/英）与 path → name 兜底映射。
 * 消费方：`views/platform-entrance/index.vue` + `components/matrix/*`；TEMU/速卖通/Ozon 见 `auto-upload.vue` 与 `components/auto-upload/*`。
 */
export const platformConfigs = {
  'amazon-auto-upload': {
    title: 'Amazon AI 自动化矩阵',
    desc: '覆盖亚马逊多站点、多类目的智能上货与 listing 优化，支持 FBA/FBM 库存同步。',
    icon: 'mdi:store',
    hasAiService: false,
    statsTitle: '店铺与销售概览',
    stats: [
      { label: '关联店铺', value: '0' },
      { label: '今日上架', value: '0' },
      { label: '待处理订单', value: '0' },
      { label: '在售 SKU', value: '0' },
      { label: 'FBA 在途', value: '0' }
    ],
    sectionOrder: ['stats', 'extra', 'features', 'actions', 'tips'],
    extraBlock: {
      title: '已开通站点',
      type: 'tags',
      tags: ['美国', '英国', '德国', '日本', '法国', '意大利', '西班牙']
    },
    layout: 'amazon',
    features: [
      { icon: 'mdi:earth', title: '多站点管理', desc: '美国、欧洲、日本等站点统一看板与一键切换。' },
      { icon: 'mdi:format-list-bulleted', title: 'Listing 智能优化', desc: '标题、关键词、五点描述 AI 建议与批量编辑。' },
      { icon: 'mdi:package-variant', title: 'FBA/FBM 库存', desc: '实时库存同步、补货提醒与多渠道配送管理。' },
      { icon: 'mdi:chart-line', title: '销量与广告', desc: '销售报表、广告数据看板与关键词表现分析。' }
    ],
    quickActions: [
      { icon: 'mdi:upload', label: '批量上货' },
      { icon: 'mdi:sync', label: '同步库存' },
      { icon: 'mdi:file-chart', label: '销售报表' },
      { icon: 'mdi:cog', label: '店铺设置' }
    ],
    tips: [
      '建议先完成卖家中心 API 授权，以便同步订单与库存。',
      '多站点商品可使用模板一键复制到其他站点并自动翻译。',
      '启用「智能调价」可根据竞品与库存自动调整价格。'
    ]
  },
  'tiktok-auto-upload': {
    title: 'TikTok Shop AI 自动化矩阵',
    desc: 'TikTok 短视频与直播电商的智能上货、达人对接与数据运营中心。',
    icon: 'mdi:video',
    hasAiService: false,
    statsTitle: '带货数据',
    stats: [
      { label: '绑定店铺', value: '0' },
      { label: '本周视频', value: '0' },
      { label: '待发货', value: '0' },
      { label: '合作达人', value: '0' }
    ],
    sectionOrder: ['stats', 'extra', 'features', 'actions', 'tips'],
    layout: 'tiktok',
    extraBlock: {
      title: '本周内容日历',
      type: 'list',
      items: [
        { text: '周一 种草视频 · 新品开箱', icon: 'mdi:video' },
        { text: '周三 直播专场 · 美妆护肤', icon: 'mdi:broadcast' },
        { text: '周五 带货短视频 · 限时秒杀', icon: 'mdi:lightning-bolt' }
      ]
    },
    featuresTitle: '能力中心',
    features: [
      { icon: 'mdi:video-plus', title: '短视频带货', desc: '挂车视频批量发布、话题与标签推荐、数据复盘。' },
      { icon: 'mdi:broadcast', title: '直播场控', desc: '直播排期、商品讲解顺序、实时库存与秒杀管理。' },
      { icon: 'mdi:account-group', title: '达人合作', desc: '达人库筛选、邀约与分佣结算一体化。' },
      { icon: 'mdi:trending-up', title: '爆款追踪', desc: '热门商品与趋势品类发现，一键跟品上架。' }
    ],
    quickActions: [
      { icon: 'mdi:upload', label: '发布视频' },
      { icon: 'mdi:calendar-clock', label: '直播排期' },
      { icon: 'mdi:chart-areaspline', label: '带货数据' },
      { icon: 'mdi:handshake', label: '达人中心' }
    ],
    tipsTitle: '运营建议',
    tips: [
      '短视频前 3 秒决定完播率，可使用 AI 生成吸睛脚本与标签。',
      '直播前建议完成商品库同步与讲解顺序配置。',
      '达人佣金支持按场次、按单品多种结算方式。'
    ]
  },
  'walmart-auto-upload': {
    title: 'Walmart AI 自动化矩阵',
    desc: '沃尔玛美国站及跨境卖家智能上货、WFS 仓储与定价策略管理。',
    icon: 'mdi:cart',
    hasAiService: false,
    statsTitle: '店铺与 WFS 概览',
    stats: [
      { label: '店铺数', value: '0' },
      { label: '今日上新', value: '0' },
      { label: 'WFS 在库', value: '0' },
      { label: '待回复消息', value: '0' }
    ],
    sectionOrder: ['stats', 'extra', 'features', 'actions', 'tips'],
    layout: 'walmart',
    extraBlock: {
      title: 'WFS 入库状态',
      type: 'paragraph',
      text: '当前无在途入库单。将商品发往沃尔玛配送中心后，可在此查看接收进度与上架时间，WFS 商品将享受 2 日达等配送标识。'
    },
    features: [
      { icon: 'mdi:warehouse', title: 'WFS 仓储', desc: '沃尔玛配送服务入库、在库库存与履约状态同步。' },
      { icon: 'mdi:tag-multiple', title: '定价与促销', desc: '竞争定价建议、Deal 活动创建与限时降价管理。' },
      { icon: 'mdi:file-document-multiple', title: '商品内容', desc: 'Item Setup 与富媒体批量编辑、类目与属性映射。' },
      { icon: 'mdi:message-reply', title: '客服与评价', desc: '买家消息统一回复、差评监控与申诉建议。' }
    ],
    actionsTitle: '常用操作',
    quickActions: [
      { icon: 'mdi:upload', label: '批量上货' },
      { icon: 'mdi:warehouse', label: 'WFS 看板' },
      { icon: 'mdi:percent', label: '促销管理' },
      { icon: 'mdi:headset', label: '客服中心' }
    ],
    tips: [
      'WFS 商品需符合尺寸与重量要求，系统会标注是否可入仓。',
      '参与 Walmart+ 等活动的商品可获得更多流量扶持。',
      '定价建议会参考同品类畅销品，避免长期滞销。'
    ]
  },
  'aliexpress-auto-upload': {
    title: 'AliExpress 速卖通 AI 自动化矩阵',
    desc: '速卖通全球跨境 B2C 智能上货、多语言与多币种运营、无忧物流对接。',
    icon: 'mdi:store-outline',
    hasAiService: false,
    statsTitle: '刊登与订单',
    stats: [
      { label: '店铺', value: '0' },
      { label: '今日刊登', value: '0' },
      { label: '待发货', value: '0' },
      { label: '运营站点数', value: '0' }
    ],
    sectionOrder: ['stats', 'extra', 'features', 'actions', 'tips'],
    extraBlock: {
      title: '重点运营站点',
      type: 'tags',
      tags: ['俄罗斯', '西班牙', '美国', '巴西', '法国', '沙特', '韩国']
    },
    layout: 'aliexpress',
    features: [
      { icon: 'mdi:translate', title: '多语言 listing', desc: '标题与描述一键翻译、本地化关键词与图片文案。' },
      { icon: 'mdi:airplane', title: '无忧物流', desc: '菜鸟无忧标准/优先对接、运费模板与时效看板。' },
      { icon: 'mdi:currency-usd', title: '多币种定价', desc: '按站点与汇率自动定价、活动与满减规则配置。' },
      { icon: 'mdi:chart-box', title: '跨境数据', desc: '各国家/地区销量、流量与转化分析。' }
    ],
    quickActions: [
      { icon: 'mdi:upload', label: '批量刊登' },
      { icon: 'mdi:translate', label: '翻译中心' },
      { icon: 'mdi:truck-fast', label: '物流看板' },
      { icon: 'mdi:earth', label: '站点切换' }
    ],
    tipsTitle: '速卖通小贴士',
    tips: [
      '俄语、西语、葡语等小语种优化可显著提升当地转化。',
      '大促前建议提前配置好活动商品与库存预警。',
      '无忧物流可降低纠纷率，建议高价值商品优先使用。'
    ]
  },
  'pinduoduo-auto-upload': {
    title: '拼多多 AI 自动化矩阵',
    desc: '拼多多店铺智能上货、活动报名与 AI 客服一体化运营。',
    icon: 'mdi:headset',
    hasAiService: true,
    statsTitle: '店铺与活动',
    stats: [
      { label: '店铺', value: '0' },
      { label: '今日上新', value: '0' },
      { label: '待回复', value: '0' },
      { label: '进行中活动', value: '0' }
    ],
    sectionOrder: ['stats', 'extra', 'features', 'actions', 'tips'],
    layout: 'pinduoduo',
    extraBlock: {
      title: 'AI 客服状态',
      type: 'list',
      items: [
        { text: '当前未开启 AI 客服，开启后可自动回复买家咨询', icon: 'mdi:robot-off-outline' },
        { text: '支持秒杀、退款、物流等常见场景话术库', icon: 'mdi:comment-text-multiple' }
      ]
    },
    features: [
      { icon: 'mdi:robot', title: 'AI 客服', desc: '智能回复、常见问题库与人工转接策略。' },
      { icon: 'mdi:tag-heart', title: '活动与资源位', desc: '秒杀、百亿补贴、领券中心等报名与效果追踪。' },
      { icon: 'mdi:package-variant', title: '商品与库存', desc: '批量上货、规格管理、预售与限购设置。' },
      { icon: 'mdi:chart-timeline-variant', title: '多多数据', desc: '流量、转化、客诉与竞品监控。' }
    ],
    actionsTitle: '快捷入口',
    quickActions: [
      { icon: 'mdi:upload', label: '批量上货' },
      { icon: 'mdi:robot', label: 'AI 客服' },
      { icon: 'mdi:bullhorn', label: '活动报名' },
      { icon: 'mdi:chart-bar', label: '数据报表' }
    ],
    tips: [
      'AI 客服可先使用「仅学习」模式，积累话术后再全自动回复。',
      '报名活动前请确认库存与发货能力，避免超卖与罚单。',
      '主图与短视频对点击率影响大，建议定期 A/B 测试。'
    ]
  },
  '1688-auto-upload': {
    title: '1688 工作台',
    desc: '订单 / 热词 / 热销一览；可进入自动上架，粘贴同行链接完成采集图优再上架。',
    icon: 'mdi:shopping',
    hasAiService: true,
    layout: '1688'
  },
  'douyin-auto-upload': {
    title: '抖音电商 AI 自动化矩阵',
    desc: '抖音小店与兴趣电商智能上货、直播与短视频运营、AI 客服。',
    icon: 'mdi:video',
    hasAiService: true,
    statsTitle: '小店与直播',
    stats: [
      { label: '小店', value: '0' },
      { label: '今日销量', value: '0' },
      { label: '待发货', value: '0' },
      { label: '本月直播场次', value: '0' }
    ],
    sectionOrder: ['stats', 'extra', 'features', 'actions', 'tips'],
    layout: 'douyin',
    extraBlock: {
      title: '直播排期',
      type: 'table',
      rows: [
        { col1: '03-08 14:00', col2: '春季女装专场', col3: '待开播' },
        { col1: '03-10 20:00', col2: '美妆护肤', col3: '已排期' },
        { col1: '03-12 19:00', col2: '家居好物', col3: '已排期' }
      ]
    },
    features: [
      { icon: 'mdi:robot', title: 'AI 客服', desc: '直播间与私信智能回复、售后话术与转人工策略。' },
      { icon: 'mdi:video-box', title: '短视频与直播', desc: '挂车视频发布、直播排期与商品讲解脚本。' },
      { icon: 'mdi:package-variant', title: '商品与履约', desc: '商品库同步、订单发货与售后处理。' },
      { icon: 'mdi:chart-areaspline', title: '达人与数据', desc: '达人合作、带货数据与 ROI 分析。' }
    ],
    actionsTitle: '常用功能',
    quickActions: [
      { icon: 'mdi:upload', label: '商品上架' },
      { icon: 'mdi:broadcast', label: '直播中心' },
      { icon: 'mdi:robot', label: 'AI 客服' },
      { icon: 'mdi:chart-line', label: '经营分析' }
    ],
    tipsTitle: '抖音运营提示',
    tips: [
      '短视频与直播内容需符合平台规范，避免违禁词与夸大宣传。',
      'AI 客服可区分售前与售后场景，自动推送不同话术。',
      '参与平台大促与品牌日可获得流量加权。'
    ]
  }
}

export const platformConfigsEn = {
  'amazon-auto-upload': {
    title: 'Amazon AI Automation',
    desc: 'Multi-site, multi-category listing and FBA/FBM sync.',
    icon: 'mdi:store',
    hasAiService: false,
    statsTitle: 'Store & Sales Overview',
    stats: [
      { label: 'Stores', value: '0' },
      { label: 'Listed Today', value: '0' },
      { label: 'Pending Orders', value: '0' },
      { label: 'SKUs', value: '0' },
      { label: 'FBA In Transit', value: '0' }
    ],
    extraBlock: { title: 'Sites', type: 'tags', tags: ['US', 'UK', 'DE', 'JP', 'FR', 'IT', 'ES'] },
    layout: 'amazon',
    features: [
      { icon: 'mdi:earth', title: 'Multi-site', desc: 'Unified dashboard and one-click switch.' },
      { icon: 'mdi:format-list-bulleted', title: 'Listing Optimizer', desc: 'AI suggestions for title, keywords, bullets.' },
      { icon: 'mdi:package-variant', title: 'FBA/FBM', desc: 'Inventory sync and replenishment.' },
      { icon: 'mdi:chart-line', title: 'Sales & Ads', desc: 'Reports and keyword performance.' }
    ],
    quickActions: [
      { icon: 'mdi:upload', label: 'Batch Upload' },
      { icon: 'mdi:sync', label: 'Sync' },
      { icon: 'mdi:file-chart', label: 'Reports' },
      { icon: 'mdi:cog', label: 'Settings' }
    ],
    tips: ['Complete API authorization first.', 'Use templates to copy listings across sites.', 'Enable smart repricing for inventory.']
  },
  'tiktok-auto-upload': {
    title: 'TikTok Shop AI Automation',
    desc: 'Short video and live commerce listing and data center.',
    icon: 'mdi:video',
    hasAiService: false,
    statsTitle: 'Performance',
    stats: [
      { label: 'Stores', value: '0' },
      { label: 'Videos', value: '0' },
      { label: 'To Ship', value: '0' },
      { label: 'Creators', value: '0' }
    ],
    extraBlock: {
      title: 'Content Calendar',
      type: 'list',
      items: [
        { text: 'Mon · Unboxing', icon: 'mdi:video' },
        { text: 'Wed · Live Beauty', icon: 'mdi:broadcast' },
        { text: 'Fri · Flash Sale', icon: 'mdi:lightning-bolt' }
      ]
    },
    layout: 'tiktok',
    featuresTitle: 'Features',
    features: [
      { icon: 'mdi:video-plus', title: 'Short Video', desc: 'Publish and analytics.' },
      { icon: 'mdi:broadcast', title: 'Live', desc: 'Scheduling and inventory.' },
      { icon: 'mdi:account-group', title: 'Creators', desc: 'Discovery and commission.' },
      { icon: 'mdi:trending-up', title: 'Trending', desc: 'Hot products and categories.' }
    ],
    quickActions: [
      { icon: 'mdi:upload', label: 'Publish' },
      { icon: 'mdi:calendar-clock', label: 'Schedule' },
      { icon: 'mdi:chart-areaspline', label: 'Data' },
      { icon: 'mdi:handshake', label: 'Creators' }
    ],
    tipsTitle: 'Tips',
    tips: ['Hook in first 3 seconds.', 'Sync products before live.', 'Multiple commission types supported.']
  },
  'walmart-auto-upload': {
    title: 'Walmart AI Automation',
    desc: 'US marketplace listing, WFS and pricing.',
    icon: 'mdi:cart',
    hasAiService: false,
    statsTitle: 'Stores & WFS',
    stats: [
      { label: 'Stores', value: '0' },
      { label: 'New Today', value: '0' },
      { label: 'WFS Stock', value: '0' },
      { label: 'Messages', value: '0' }
    ],
    extraBlock: {
      title: 'WFS Status',
      type: 'paragraph',
      text: 'No inbound shipments. Track receiving and 2-day delivery after sending to WFS.'
    },
    layout: 'walmart',
    features: [
      { icon: 'mdi:warehouse', title: 'WFS', desc: 'Fulfillment and inventory.' },
      { icon: 'mdi:tag-multiple', title: 'Pricing', desc: 'Deals and promotions.' },
      { icon: 'mdi:file-document-multiple', title: 'Content', desc: 'Item setup and media.' },
      { icon: 'mdi:message-reply', title: 'Support', desc: 'Messages and reviews.' }
    ],
    actionsTitle: 'Common Actions',
    quickActions: [
      { icon: 'mdi:upload', label: 'Upload' },
      { icon: 'mdi:warehouse', label: 'WFS' },
      { icon: 'mdi:percent', label: 'Promos' },
      { icon: 'mdi:headset', label: 'Support' }
    ],
    tips: ['Check WFS size/weight rules.', 'Walmart+ boosts visibility.', 'Use repricing suggestions.']
  },
  'aliexpress-auto-upload': {
    title: 'AliExpress AI Automation',
    desc: 'Global B2C listing, multi-language and logistics.',
    icon: 'mdi:store-outline',
    hasAiService: false,
    statsTitle: 'Listings & Orders',
    stats: [
      { label: 'Stores', value: '0' },
      { label: 'Listed Today', value: '0' },
      { label: 'To Ship', value: '0' },
      { label: 'Sites', value: '0' }
    ],
    extraBlock: { title: 'Key Sites', type: 'tags', tags: ['Russia', 'Spain', 'USA', 'Brazil', 'France', 'Saudi', 'Korea'] },
    layout: 'aliexpress',
    features: [
      { icon: 'mdi:translate', title: 'Multi-language', desc: 'Translate and localize.' },
      { icon: 'mdi:airplane', title: 'Shipping', desc: 'Cainiao and templates.' },
      { icon: 'mdi:currency-usd', title: 'Pricing', desc: 'Multi-currency and promotions.' },
      { icon: 'mdi:chart-box', title: 'Data', desc: 'Sales by country.' }
    ],
    quickActions: [
      { icon: 'mdi:upload', label: 'Upload' },
      { icon: 'mdi:translate', label: 'Translate' },
      { icon: 'mdi:truck-fast', label: 'Shipping' },
      { icon: 'mdi:earth', label: 'Sites' }
    ],
    tipsTitle: 'Tips',
    tips: ['Localize for RU/ES/PT.', 'Set alerts before campaigns.', 'Use shipping for high-value.']
  },
  'pinduoduo-auto-upload': {
    title: 'Pinduoduo AI Automation',
    desc: 'Listing, campaigns and AI support.',
    icon: 'mdi:headset',
    hasAiService: true,
    statsTitle: 'Stores & Campaigns',
    stats: [
      { label: 'Stores', value: '0' },
      { label: 'New Today', value: '0' },
      { label: 'To Reply', value: '0' },
      { label: 'Campaigns', value: '0' }
    ],
    extraBlock: {
      title: 'AI Support',
      type: 'list',
      items: [
        { text: 'Enable AI support for auto-reply', icon: 'mdi:robot-off-outline' },
        { text: 'Scripts for flash sale, refund, shipping', icon: 'mdi:comment-text-multiple' }
      ]
    },
    layout: 'pinduoduo',
    features: [
      { icon: 'mdi:robot', title: 'AI Support', desc: 'Auto-reply and handoff.' },
      { icon: 'mdi:tag-heart', title: 'Campaigns', desc: 'Deals and resources.' },
      { icon: 'mdi:package-variant', title: 'Products', desc: 'Upload and inventory.' },
      { icon: 'mdi:chart-timeline-variant', title: 'Data', desc: 'Traffic and conversion.' }
    ],
    actionsTitle: 'Shortcuts',
    quickActions: [
      { icon: 'mdi:upload', label: 'Upload' },
      { icon: 'mdi:robot', label: 'AI Support' },
      { icon: 'mdi:bullhorn', label: 'Campaigns' },
      { icon: 'mdi:chart-bar', label: 'Reports' }
    ],
    tips: ['Start with learn-only AI mode.', 'Check stock before campaigns.', 'A/B test images and video.']
  },
  '1688-auto-upload': {
    title: '1688 Workspace',
    desc: 'Orders, hot keywords and bestsellers; enter listing to paste peer links for img2img then publish.',
    icon: 'mdi:shopping',
    hasAiService: true,
    layout: '1688'
  },
  'douyin-auto-upload': {
    title: 'Douyin E-commerce AI',
    desc: 'Shop, live and short video with AI support.',
    icon: 'mdi:video',
    hasAiService: true,
    statsTitle: 'Shop & Live',
    stats: [
      { label: 'Shops', value: '0' },
      { label: 'Sales Today', value: '0' },
      { label: 'To Ship', value: '0' },
      { label: 'Lives', value: '0' }
    ],
    extraBlock: {
      title: 'Live Schedule',
      type: 'table',
      rows: [
        { col1: '03-08 14:00', col2: 'Spring Fashion', col3: 'Upcoming' },
        { col1: '03-10 20:00', col2: 'Beauty', col3: 'Scheduled' },
        { col1: '03-12 19:00', col2: 'Home', col3: 'Scheduled' }
      ]
    },
    layout: 'douyin',
    features: [
      { icon: 'mdi:robot', title: 'AI Support', desc: 'Live and DMs.' },
      { icon: 'mdi:video-box', title: 'Video & Live', desc: 'Publish and scripts.' },
      { icon: 'mdi:package-variant', title: 'Fulfillment', desc: 'Orders and after-sales.' },
      { icon: 'mdi:chart-areaspline', title: 'Data', desc: 'Creators and ROI.' }
    ],
    actionsTitle: 'Common Features',
    quickActions: [
      { icon: 'mdi:upload', label: 'List' },
      { icon: 'mdi:broadcast', label: 'Live' },
      { icon: 'mdi:robot', label: 'AI' },
      { icon: 'mdi:chart-line', label: 'Analytics' }
    ],
    tipsTitle: 'Douyin Tips',
    tips: ['Follow content guidelines.', 'AI can split pre/post-sale.', 'Join platform campaigns.']
  }
}

/** 避免路由 name 未就绪时落到默认「AI 自动化矩阵」标题闪烁 */
export const MATRIX_PATH_TO_ROUTE_NAME = {
  '/amazon-auto-upload': 'amazon-auto-upload',
  '/tiktok-auto-upload': 'tiktok-auto-upload',
  '/walmart-auto-upload': 'walmart-auto-upload',
  '/pinduoduo-auto-upload': 'pinduoduo-auto-upload',
  '/1688-auto-upload': '1688-auto-upload',
  '/douyin-auto-upload': 'douyin-auto-upload'
}
export function resolveMatrixRouteKey(route) {
  const n = route.name
  if (n && platformConfigs[n]) return n
  const p = (route.path || '').replace(/\/$/, '')
  return MATRIX_PATH_TO_ROUTE_NAME[p] || n || ''
}
