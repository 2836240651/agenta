package dispatcher

import (
	interfaces "commander-agent-t260220/backend/internal/Interfaces"
	"commander-agent-t260220/backend/internal/constants"
	"commander-agent-t260220/backend/internal/pkg/usererr"
	"commander-agent-t260220/backend/types"
	"fmt"
)

// Dispatcher 调度器，按 platform + protocol 强类型分发，无反射
type Dispatcher struct {
	platforms map[string]interfaces.PlatformInterface
}

// NewDispatcher 创建调度器
func NewDispatcher() *Dispatcher {
	return &Dispatcher{
		platforms: make(map[string]interfaces.PlatformInterface),
	}
}

// Register 注册平台实现
func (d *Dispatcher) Register(platformId string, p interfaces.PlatformInterface) {
	d.platforms[platformId] = p
}

// Dispatch 根据 platform + protocol 调度到对应平台的实现
func (d *Dispatcher) Dispatch(payload types.AgentMessage[any, any]) (*types.AgentMessage[any, any], error) {
	instance, ok := d.platforms[payload.Platform]
	if !ok {
		resp := types.AgentTaskResponse{}.Error(fmt.Sprintf("平台 %s 未注册", payload.Platform))
		return d.wrapResponse(payload, resp), nil
	}

	var resp types.AgentTaskResponse
	var err error

	// 执行任务
	switch payload.Protocol {
	case constants.ProtocolProductIssue:
		resp, err = instance.ProductIssue(payload)
	case constants.ProtocolProductIssuePrecheck:
		resp, err = instance.ProductIssuePrecheck(payload)
	case constants.ProtocolShopList:
		resp, err = instance.ShopList(payload)
	case constants.ProtocolProductList:
		resp, err = instance.ProductList(payload)
	case constants.ProtocolListing1688OpenLogin,
		constants.ProtocolListing1688ExportCookie,
		constants.ProtocolListing1688Probe,
		constants.ProtocolListing1688FetchOffer,
		constants.ProtocolListing1688SellerOpenLogin,
		constants.ProtocolListing1688SellerExportCookie,
		constants.ProtocolListing1688SellerProbe,
		constants.ProtocolListing1688SellerInspectCategory,
		constants.ProtocolListing1688SellerSaveDraft,
		constants.ProtocolListing1688SellerListProducts,
		constants.ProtocolListing1688SellerOpenSimilarPublish,
		constants.ProtocolListing1688SellerPublish:
		type listing1688Handler interface {
			Listing1688OpenLogin(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
			Listing1688ExportCookie(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
			Listing1688Probe(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
			Listing1688FetchOffer(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
			Listing1688SellerOpenLogin(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
			Listing1688SellerExportCookie(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
			Listing1688SellerProbe(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
			Listing1688SellerInspectCategory(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
			Listing1688SellerSaveDraft(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
			Listing1688SellerListProducts(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
			Listing1688SellerOpenSimilarPublish(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
			Listing1688SellerPublish(types.AgentMessage[any, any]) (types.AgentTaskResponse, error)
		}
		h, ok := instance.(listing1688Handler)
		if !ok {
			resp = types.AgentTaskResponse{}.Error(fmt.Sprintf("协议 %s 仅支持 platform=1688", payload.Protocol))
			break
		}
		switch payload.Protocol {
		case constants.ProtocolListing1688OpenLogin:
			resp, err = h.Listing1688OpenLogin(payload)
		case constants.ProtocolListing1688ExportCookie:
			resp, err = h.Listing1688ExportCookie(payload)
		case constants.ProtocolListing1688Probe:
			resp, err = h.Listing1688Probe(payload)
		case constants.ProtocolListing1688FetchOffer:
			resp, err = h.Listing1688FetchOffer(payload)
		case constants.ProtocolListing1688SellerOpenLogin:
			resp, err = h.Listing1688SellerOpenLogin(payload)
		case constants.ProtocolListing1688SellerExportCookie:
			resp, err = h.Listing1688SellerExportCookie(payload)
		case constants.ProtocolListing1688SellerProbe:
			resp, err = h.Listing1688SellerProbe(payload)
		case constants.ProtocolListing1688SellerInspectCategory:
			resp, err = h.Listing1688SellerInspectCategory(payload)
		case constants.ProtocolListing1688SellerSaveDraft:
			resp, err = h.Listing1688SellerSaveDraft(payload)
		case constants.ProtocolListing1688SellerListProducts:
			resp, err = h.Listing1688SellerListProducts(payload)
		case constants.ProtocolListing1688SellerOpenSimilarPublish:
			resp, err = h.Listing1688SellerOpenSimilarPublish(payload)
		case constants.ProtocolListing1688SellerPublish:
			resp, err = h.Listing1688SellerPublish(payload)
		}
	default:
		resp = types.AgentTaskResponse{}.Error(fmt.Sprintf("平台 %s 未实现协议 %s", payload.Platform, payload.Protocol))
	}
	if err != nil {
		resp = types.AgentTaskResponse{}.Error(err.Error())
	}
	return d.wrapResponse(payload, resp), nil
}

// wrapResponse 将 AgentTaskResponse 包装进 AgentMessage.Receive
func (d *Dispatcher) wrapResponse(payload types.AgentMessage[any, any], resp types.AgentTaskResponse) *types.AgentMessage[any, any] {
	payload.Receive = resp
	if resp.Code == 0 || resp.Code == 200 {
		payload.Status = constants.WsTaskStatusSuccess
	} else {
		payload.Status = constants.WsTaskStatusFailed
	}
	payload.Message = usererr.Normalize(resp.Msg)
	return &payload
}
