package alibaba

import "testing"

func TestListing1688SellerLooksLoggedOutIgnoresHiddenLoginCopy(t *testing.T) {
	url := "https://work.1688.com/?_path_=sellerPro/2017sellerbase_offer/orderPost"
	html := "<html><body>泰州亿拓户外用品 发布商品 商品管理 <iframe src=\"https://login.1688.com/member/signin.htm\"></iframe><div style=\"display:none\">密码登录 短信登录</div></body></html>"

	if listing1688SellerLooksLoggedOut(url, html) {
		t.Fatal("seller workbench with hidden login component must not be treated as logged out")
	}
}

func TestListing1688SellerLooksAccountIneligible(t *testing.T) {
	embeddedHTML := "<iframe src=\"https://cxt.1688.com/tp_service.html\"></iframe>"

	if listing1688SellerLooksAccountIneligible("https://work.1688.com/?_path_=sellerPro/2017sellerbase_offer/orderPost", embeddedHTML) {
		t.Fatal("embedded cxt resource must not reject an otherwise active seller route")
	}
	if !listing1688SellerLooksAccountIneligible("https://cxt.1688.com/tp_service.html", "您当前登录的账号为个人账号") {
		t.Fatal("personal account enrollment page must be rejected")
	}
}

func TestListing1688SellerLooksLikeWorkbenchRejectsBuyerWorkbench(t *testing.T) {
	url := "https://work.1688.com/"
	html := "1688-买家工作台 供应商动态 采购设置 收藏的商品"

	if listing1688SellerLooksLikeWorkbench(html, url) {
		t.Fatal("buyer workbench must not satisfy seller preflight")
	}
}

func TestListing1688SellerPlatformStatus(t *testing.T) {
	if got := listing1688SellerPlatformStatus("商品发布成功"); got != "published" {
		t.Fatalf("published got %q", got)
	}
	if got := listing1688SellerPlatformStatus("商品审核中，请耐心等待"); got != "auditing" {
		t.Fatalf("auditing got %q", got)
	}
	if got := listing1688SellerPlatformStatus("提交成功"); got != "" {
		t.Fatalf("weak hint got %q", got)
	}
}
