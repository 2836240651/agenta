# Fish 工作区 Agent 规则

本文件供 Cursor / AI Agent 在本仓库工作时遵循。覆盖操盘手（Commander）全栈三件套及本地工具链约定。

## 当前用户授权（会话级硬性）

- 用户已明确授权：在本仓库当前任务中，Agent 默认**全权执行**，无需在每个步骤前重复征询。
- 执行方式要求：每完成一段关键动作后，必须**自审本次行为是否有漏洞**；若发现执行链路、环境检查、命令方式或判断依据存在漏洞，应先修复漏洞，再继续执行。
- 记录要求：涉及实质改动、排障结论、执行链路修正时，必须同步写入 `开发文档.md`。
- 上述授权不覆盖本文件中已有的安全边界：仍然禁止未获明确要求的远程部署、敏感信息提交、破坏性 git 操作等。

## 主战场与外部源码（硬性）

| 角色 | 路径 | 说明 |
|------|------|------|
| **主战场（本仓库）** | `D:\dev\workspace` | Commander Web / Server / Agent；1688 向导落地与 spec 均在此 |
| **1688 采集源码（已实现）** | `D:\reverselab\1688-` | CDP 登录 + 解析 `window.context`；**移植解析，禁止从零重写** |
| **非主战场** | `D:\reverselab\open-reverselab` | 公共逆向仓；**不是** Commander / 1688 上架产品主战场 |

做 1688 上架 / 向导任务时：

1. **先读** `docs/superpowers/specs/1688-listing-wizard-v2/README.md`（正位说明）
2. 采集逻辑对照 `D:\reverselab\1688-\`（及该目录 `AGENTS.md`）
3. **1688 向导（场景 A）**：采集移植 `D:\reverselab\1688-`；图优 grsai；**发品 = 自家 1688 商家后台自动化，禁止妙手/店小秘发品**。spec：`docs/superpowers/specs/1688-listing-wizard-v2/README.md`

## 工作区结构

```
D:\dev\
├── env\
│   └── skill\                    # 外部 Skill 包统一落盘（每个包独占子目录）
│       ├── getsentry\            # Sentry 官方 skills 仓库
│       │   └── skills\           # code-review、security-review 等
│       └── reverse-skill\        # 逆向 / 安全技能路由包
└── workspace\
    ├── agents.md                 # 本文件（项目级 Agent 规则）
    ├── 交接文档.md               # 项目交接说明（架构、端口、关键路径）
    ├── 开发文档.md               # 开发变更流水账（每次任务完成追加；超限归档至 docs/handover/）
    ├── docs\superpowers\specs\1688-listing-wizard-v2\  # 1688 向导 spec（正位）
    ├── .cursor\                  # Cursor 项目侧配置（规则 / skills / MCP）
    │   ├── rules\
    │   ├── skills\
    │   └── mcp.json
    ├── commander-agent-t260220-main\commander-agent-t260220-main\   # Wails 桌面客户端
    ├── commander-server-t260220-main\commander-server-t260220-main\ # Go 后端 API + Agent WebSocket
    └── commander-web-t260220-main\commander-web-t260220-main\       # Vue3 管理端 Web
```

工作区根目录：`<WORKSPACE_ROOT>` = `D:\dev\workspace`

环境根目录：`<ENV_ROOT>` = `D:\dev\env`（`FISHAGENT_ENV_ROOT`）

Skill 包落盘根目录：`<SKILL_ROOT>` = `D:\dev\env\skill`（**禁止**把多个包直接解压到该根目录）

## GitHub / 服务器同步（长期规则，必须记住）

当用户要求“更新到 GitHub，并更新到服务器”时，按下面流程执行，避免遗漏：

- **三仓库对应关系（固定）**
  - **server**：`https://github.com/hyhacct/commander-server-t260220`
  - **web**：`https://github.com/hyhacct/commander-web-t260220`
  - **agent**：`https://github.com/hyhacct/commander-agent-t260220`

- **提交前必做**
  - **禁止提交敏感信息**：任何 `api_key`、Token、密码、`config.yaml` 密钥、`.env` 等不得进 git。
  - **只 add 本次相关文件**：不要 `git add .` 盲加；删除 Office 临时文件（例如 `~$*.xlsx`）。

- **生产配置口径（发布/部署前必须切回生产）**
  - **Agent**：`backend/internal/constants/agent.go` 必须为生产 `wss` + `www.yoto.work`（不要带 `localhost`）。

- **服务器更新（用户明确要求后才执行）**
  - 优先使用脚本 `scripts/_ssh-probe/restore-config-and-deploy.js`（包含上传 config 与 docker 更新/重启/健康检查）。
  - 执行前先确认两个本地文件存在：
    - `scripts/_ssh-probe/payload/config.yaml`（服务器用配置）
    - `commander-server-*/.local/bin/commander-server-linux-amd64`（要上传的 Linux 二进制）
  - 若本机 `ssh` 无法免交互登录，不要强行手敲多步命令，直接走上述脚本。

| 子项目 | 技术栈 | 默认端口 |
|--------|--------|----------|
| agent | Wails v2 + Go + Vue3 + TS + shadcn-vue | 连接 Server `34206`；`wails dev` 前端 Vite **`34115`**（仅内嵌 WebView，勿与 Web 混用） |
| server | Go + Gin + GORM + PostgreSQL | `34206` |
| web | Vue3 + Vite + TDesign | `5173` |

## 本地工具链（Windows）

**已写入用户/系统环境变量，新开终端即可用，无需每次 `env.ps1`。**

| 变量 | 路径 |
|------|------|
| `FISHAGENT_ENV_ROOT` | `D:\dev\env` |
| `FISHAGENT_ROOT` | `D:\dev\workspace` |
| `GOROOT` | `D:\dev\env\tools\go` |
| `GOPATH` | `D:\dev\env\data\go` |
| `NODE_HOME` | `D:\dev\env\tools\node` |
| `PNPM_HOME` | `D:\dev\env\tools\pnpm` |
| `ENV` | `dev`（Server 读 config-dev.yaml） |

PATH 已包含：`go\bin`、`node`、`pnpm`、`git`、`pgsql\bin`、`GOPATH\bin`（wails/wire/task）。

变更环境后执行：`powershell -File D:\dev\env\scripts\apply-env.ps1`（需重开终端）。

## 启动顺序

1. **PostgreSQL**（如未运行）
   ```powershell
   powershell -File D:\dev\env\scripts\start-services.ps1
   ```
2. **Server**
   ```powershell
   cd D:\dev\workspace\commander-server-t260220-main\commander-server-t260220-main
   go run .
   ```
3. **Web**
   ```powershell
   cd D:\dev\workspace\commander-web-t260220-main\commander-web-t260220-main
   pnpm install
   pnpm dev
   ```
4. **Agent**（工作目录必须是 agent 项目根；前端 dev 固定 `34115`，不占 Web 的 `5173`）
   ```powershell
   cd D:\dev\workspace\commander-agent-t260220-main\commander-agent-t260220-main
   wails dev
   ```

一键三端重启（推荐）：`powershell -File D:\dev\workspace\scripts\restart-commander.ps1`

Agent 通过 WebSocket 注册：`ws://localhost:34206/api/v1/agent/online`。主页应显示 **ACTIVE**。

## Agent（Wails）硬性规则

### 禁止

- **禁止** 对 agent 使用 `go run`、`go build` 直接编译/运行
- **禁止** 运行未经过 `wails build` 的 exe（会弹窗：*Wails applications will not build without the correct build tags*）
- **禁止** 把 `agent/config.yaml` 中的账号密码写入代码、日志或提交到 git

### 正确做法

**开发模式：**
```powershell
cd D:\dev\workspace\commander-agent-t260220-main\commander-agent-t260220-main
wails dev
```

**生产编译：**
```powershell
wails generate module
wails build -platform windows/amd64
# 产物：build\bin\Agent.exe
```

**后端暴露给前端的 Go 方法变更后**，必须执行 `wails generate module`，再编译前端。

### Agent 配置与数据目录

- 配置文件：`commander-agent-.../agent/config.yaml`
- 日志：`agent/logs/`
- 浏览器数据：`agent/Browser/`
- 本地 Server：`backend/internal/constants/agent.go` → `BaseServerAddress = "localhost:34206"`

## Server 规则

- 配置：`etc/config/config.yaml`（`ENV=dev` 时用 `config-dev.yaml`）
- **不要把 config 里的密钥写入文档或提交**
- 数据库 DSN 见 config.yaml，PostgreSQL 数据目录：`D:\dev\env\data\postgresql`

### Agent 版本发布（`version.yaml`）

Web「Agent 下载列表」与 Agent 端「更新日志」均读取 `GET /api/v1/openapi/agent_version`，数据来自 Server 的 `etc/config/version.yaml`。

| 项 | 说明 |
|----|------|
| 本地文件 | `commander-server-.../etc/config/version.yaml` |
| 线上宿主机 | `/data/commander/config/version.yaml`（Docker 挂载至容器 `/apps/data/etc/config/version.yaml`） |
| **缺文件后果** | 接口 403，Web / Agent 均显示「暂无版本记录」 |

**发布新 Agent 版本时（Agent 必须遵循）：**

1. 在 `commander-agent-...` 执行 `wails build -platform windows/amd64`，产物 `build\bin\Agent.exe`；打包为 `Agent_windows_amd64.zip`（仅含 `Agent.exe`）
   - **硬性新增**：发布前必须同步更新 `backend/internal/constants/agent.go` 中 `AgentVersion`，确保与 `version.yaml` 的最新 `version` 完全一致（例如都为 `4.0.2`）
   - **硬性新增**：打包后必须自检版本号（启动 `Agent.exe` 查看版本 / 调用 `UpdateVersion`），确认二进制内显示版本与发布版本一致；否则禁止上传
2. 在 GitHub 仓库 **`hyhacct/commander-agent-t260220`**（注意是 **t260220**，勿写成 t250220）创建 Release（示例 tag `4.0.1`），上传资产 `Agent_windows_amd64.zip`
3. **`download_url` 必须用公网可直链下载的地址**（Web 下载按钮与 Agent 自更新均直接 GET 该 URL）：
   - 仓库为**私有**时，GitHub `releases/download/...` **未登录会 404**，**禁止**仅填 GitHub 直链
   - 推荐：上传 zip 至 `www.yoto.work` 静态目录（**须用户明确要求**；Agent 禁止自行 scp，见「远程部署」）  
     宿主机：`/opt/1panel/www/sites/www.yoto.work/index/downloads/Agent_windows_amd64_<tag>.zip`  
     公网 URL：`https://www.yoto.work/downloads/Agent_windows_amd64_<tag>.zip`  
     脚本：`scripts/_ssh-probe/upload-agent-401.js`（改文件名后复用）
   - 备选：`open.seawol.cn` 或阿里云 OSS（见 `version.yaml` 历史条目）
   - GitHub Release **页面**可写在 `message` 里作溯源，例如 `.../releases/tag/4.0.1`
4. 在 `version.yaml` **顶部**追加或更新条目：
   - `version`：与 tag 一致（如 `4.0.1`）
   - `is_new`：仅最新一条为 `true`，其余改为 `false`
   - `download_url`：上一步公网直链（示例 `https://www.yoto.work/downloads/Agent_windows_amd64_4.0.1.zip`）
   - `message`：更新说明（简体中文，可附 Release 页链接）
   - `update_time`：10 位 Unix 时间戳
5. **同步线上**（**须用户在本轮对话中明确要求**；Agent **禁止**自行上传，见「远程服务器 → 远程部署」）：
   - `version.yaml` → `124.223.27.98:/data/commander/config/version.yaml`（`scripts/_ssh-probe/upload-version-yaml.js`）
6. 校验（同上，须用户明确要求后执行）：
   - `curl -I https://www.yoto.work/downloads/Agent_windows_amd64_<tag>.zip` → HTTP 200
   - `curl https://www.yoto.work/api/v1/openapi/agent_version` → `code: 0` 且含新版本

**禁止** 仅改 GitHub Release 不同步本地 `version.yaml`（仍须改文件并 push GitHub）；**禁止** `download_url` 使用私有 GitHub 资产直链或错误的仓库名；**禁止** Agent 未经用户明确要求即 scp/ssh 上传至线上。

## 远程服务器（当前项目）

Commander 线上/联调使用的云主机（**仅本地参考，勿提交 git 或对外分享**）。

| 项 | 值 |
|----|-----|
| 地址 | `124.223.27.98` |
| 用户 | `root` |
| SSH | `ssh root@124.223.27.98` |
| 密码 | `Hyh3202276686@@@` |

**同机共存（ybb-site 部署机，2026-07-14 迁入）：** `/opt/ybb-site` + systemd `ybb-deploy-runner` / `ybb-socks-jump`。SSH 别名 `ybb-deploy`。ybb **不占用** Commander 的 `34206`；SOCKS 固定本机 `127.0.0.1:19888`（**勿用 18080**，已被 crosshub）。细则：`D:\开发\fishAgent\总包\skill\reverse-skill\omc-replica\ybb-site\docs\ybb-site-manager\DEPLOY-MACHINE-ubuntu.md`。

常用（**只读排查**；见下方禁止项）：

```powershell
ssh root@124.223.27.98
```

### 远程部署 — Agent 硬性禁止

**无论任务是否完成、无论上文是否写明路径，Agent 均不得将本地改动部署/同步到远程服务器。**

| 禁止操作 | 示例 |
|----------|------|
| 上传代码、二进制、配置 | `scp`、`rsync`、`sftp`、WinSCP、`upload-*.js` / `upload-*.ps1` |
| 在远程构建或重启服务 | `docker compose up`、`systemctl restart`、替换容器内文件 |
| 修改线上目录 | `/data/commander/`、`/opt/1panel/www/`、`/apps/` 等宿主机或容器挂载路径 |
| 以「修复线上」「同步 version.yaml / Agent 包」等理由自行部署 | 须**用户在本轮对话中明确要求**才可执行 |

**允许**（不改动远程文件）：`ssh` 登录后**只读**查看日志、进程、`curl` 探测接口状态。

**代码出口唯一路径**：完成任务后 **commit + push 到 GitHub**（见「Git 仓库」）；由用户或 CI/CD 负责从 GitHub 部署到服务器。

## Git 仓库（smart-agent）

项目主仓库为 GitHub **私有库**，本机已验证可通过 **HTTPS** 拉取与推送（凭据存于 Windows 凭据管理器，账号 `2836240651`）。**当前未配置 SSH 公钥，禁止使用 `git@github.com:` 地址。**

| 项 | 值 |
|----|-----|
| 仓库 | `https://github.com/2836240651/smart-agent` |
| 远程名 | `origin` |
| 默认分支 | `main` |
| 推荐本地路径 | `<WORKSPACE_ROOT>/smart-agent`（即 `D:\dev\workspace\smart-agent`） |
| 认证方式 | HTTPS + Git Credential Manager（`credential.helper=manager`） |
| Git 可执行文件 | `D:\dev\env\tools\git\cmd\git.exe`（新开终端应已在 PATH；否则先 `apply-env.ps1`） |

### 首次克隆

```powershell
cd D:\dev\workspace
git clone https://github.com/2836240651/smart-agent.git
cd smart-agent
```

若全局未配置提交身份（本机常见），在**该仓库**或全局设置一次：

```powershell
git config --global user.name "你的名字"
git config --global user.email "你的邮箱"
```

### 拉取（Pull）规则 — Agent 与用户均遵循

1. **开始改代码前**先拉取，减少冲突：
   ```powershell
   cd D:\dev\workspace\smart-agent
   git fetch origin
   git pull --rebase origin main
   ```
2. **优先 `--rebase`**，保持 `main` 历史线性；有未提交改动时先 `git stash`，拉完再 `git stash pop`。
3. **有冲突**：停止自动合并，列出冲突文件，交用户或明确指令后再处理；**禁止**在未确认时 `git push`。
4. **禁止**对 `main` 使用 `git pull` 后不经检查直接强推；**禁止** `git push --force` / `git push --force-with-lease` 到 `main`（除非用户明确要求）。
5. 仅需查看远程更新、不合并时：`git fetch origin` + `git log HEAD..origin/main --oneline`。

### 推送（Push）规则 — Agent 硬性约定

1. **每次任务产生实质代码/配置/文档改动后，收工前必须 commit 并 push 到 GitHub**（与写 `开发文档.md` 同级，不得只改本地不推送）。
2. **无实质改动**（纯答疑、只读排查、用户明确说「不要提交」）时可跳过 commit/push，须在汇报中说明原因。
3. **多仓库**：改动落在哪个 git 根目录，就在该目录执行 push（如 `<WORKSPACE_ROOT>`、`commander-agent-.../` 等）；多个目录有改动则分别提交推送。
4. 推送前**必须**依次检查：
   ```powershell
   git status
   git diff
   git diff --staged
   git log -3 --oneline
   ```
5. **禁止提交**含密钥、Token、`config.yaml` 密码、`.env` 等敏感内容的文件；若误加入暂存区，先 `git reset` 再提交。
6. 提交信息：简短说明「为什么」，一句或两句；遵循仓库已有风格。
7. 标准推送流程：
   ```powershell
   git add <相关文件>          # 禁止 git add . 盲加，只加本次任务文件
   git commit -m "说明"
   git pull --rebase origin main
   git push origin HEAD
   ```
8. 推送失败（非快进、权限、网络）：**不要** force push；先 `git fetch`，汇报 `git status` 与 `git log origin/main..HEAD`，再按用户指示处理。
9. **不要**修改 `git config`（含 global）。

### 禁止

- **禁止** 使用 SSH 地址 `git@github.com:2836240651/smart-agent.git`（本机未配密钥，会 `Permission denied`）
- **禁止** 把 GitHub PAT / 密码写入 `AGENTS.md`、代码、日志或提交记录
- **禁止** 有实质改动却既不 commit/push 也不说明跳过原因
- **禁止** `git push --force` / `git push --force-with-lease` 到 `main`（除非用户明确要求）
- **禁止** 向仓库提交本地探测/临时文件（如 `probe`、`test` 类无意义提交）

### 故障排查

| 现象 | 处理 |
|------|------|
| `git` 不是内部或外部命令 | 执行 `powershell -File D:\dev\env\scripts\apply-env.ps1` 后重开终端，或用完整路径 `D:\dev\env\tools\git\cmd\git.exe` |
| `Authentication failed` / `Repository not found` | 打开「Windows 凭据管理器」，检查 `git:https://github.com`；或 GitHub → Settings → Developer settings → Personal access tokens 重新生成并登录 |
| `Permission denied (publickey)` | 说明用了 SSH；改回 HTTPS 远程：`git remote set-url origin https://github.com/2836240651/smart-agent.git` |
| 拉取冲突 | `git status` 查看冲突文件，人工或按指令解决后 `git add` + `git rebase --continue` |

## Web 规则

- 包管理：pnpm（`pnpm dev` / `pnpm build`）
- 开发代理：`vite.config.js` → `http://localhost:34206`

## 前端（Agent UI）约定

- 目录：`commander-agent-.../frontend/`
- 包管理：**pnpm**
- 组件库：shadcn-vue + reka-ui

---

## Skill 下载与 Cursor 对齐（硬性规则）

**任何 Skill 下载后，仅完成文件落盘是不够的；必须同步完成 Cursor 侧对齐，并向用户汇报改了什么。**

### 约定目录

| 用途 | 路径 |
|------|------|
| Skill 包落盘根 | `<SKILL_ROOT>` = `D:\dev\env\skill\` |
| 单个 Skill 包 | `<SKILL_ROOT>\<package-name>\`（如 `getsentry\`、`reverse-skill\`） |
| Cursor 用户 Skill | `%USERPROFILE%\.cursor\skills\<skill-name>\` |
| Cursor 项目 Skill | `<WORKSPACE_ROOT>\.cursor\skills\<skill-name>\` |
| Cursor 项目规则 | `<WORKSPACE_ROOT>\.cursor\rules\` |
| Cursor MCP 配置 | `<WORKSPACE_ROOT>\.cursor\mcp.json`（或 Cursor Settings → MCP） |

### 防覆盖安装规则（最高优先级）

接到「拉取 / 下载 / clone / 安装 skill」任务时，**必须先遵守以下规则**，再执行落盘：

1. **一包一目录**
   - 每个 GitHub 仓库必须安装到 `<SKILL_ROOT>\<package-name>\`
   - 示例：`getsentry/skills` → `D:\dev\env\skill\getsentry\`
   - 示例：`zhaoxuya520/reverse-skill` → `D:\dev\env\skill\reverse-skill\`

2. **禁止覆盖根目录**
   - **禁止** `git clone <url> D:\dev\env\skill`
   - **禁止** 把 ZIP 解压到 `<SKILL_ROOT>\` 根目录
   - **禁止** `Move-Item` / `Rename-Item` 把整个 `<SKILL_ROOT>` 替换成新包
   - **禁止** 删除 `<SKILL_ROOT>` 下已有包目录（除非用户明确要求）

3. **安装前检查**
   - 列出 `<SKILL_ROOT>\` 下已有子目录并向用户说明
   - 若目标 `<package-name>\` 已存在：默认 **更新该子目录**（pull / 解压覆盖子目录），不得动其他包

4. **推荐命令模板**

```powershell
# git 可用时
git clone https://github.com/<owner>/<repo>.git "D:\dev\env\skill\<package-name>"

# 无 git 时（ZIP 必须解压到临时目录，再移动到子目录）
$zip = "D:\dev\env\downloads\<package-name>.zip"
$tmp = "D:\dev\env\downloads\<package-name>-extract"
Invoke-WebRequest -Uri "https://github.com/<owner>/<repo>/archive/refs/heads/main.zip" -OutFile $zip
Expand-Archive -Path $zip -DestinationPath $tmp -Force
Move-Item "$tmp\<repo>-main" "D:\dev\env\skill\<package-name>" -Force
```

5. **安装后登记**
   - 在汇报中列出 `<SKILL_ROOT>` 当前所有包目录，便于用户核对未被误删

### 下载后必做清单

1. **落盘** — 仅写入 `<SKILL_ROOT>\<package-name>\`
2. **读引导** — README / SKILL.md / RULES.md，执行 bootstrap
3. **路径对齐** — 旧路径统一改为 `D:\dev\env\skill\<package-name>\...`
4. **注册 Cursor**
   - 扁平 skill 集合（如 getsentry）：将 `<package>\skills\<name>\` 联接至 `%USERPROFILE%\.cursor\skills\<name>\`
   - 路由型大包（如 reverse-skill）：在 `.cursor\skills\reverse-skill\` 写入口 `SKILL.md` 指向真实路由文件
5. **写项目规则** — `.cursor\rules\<name>.mdc`
6. **MCP 对齐**（如需要）
7. **验证** — 入口可读、索引已生成
8. **汇报** — 落盘位置、Cursor 注册、未触碰的其他包

### 禁止

- **禁止** 只 clone 就宣布完成，不做 Cursor 对齐
- **禁止** 把新包安装到 `<SKILL_ROOT>` 根目录导致覆盖其他包
- **禁止** 在规则或 MCP 中保留旧机器路径
- **禁止** 写入 `~/.cursor/skills-cursor/`（Cursor 内置目录）
- **禁止** 把 Skill 包内密钥写入 `agents.md` 或提交 git

### 已安装包

| 包名 | 来源 | 落盘路径 | Cursor 注册 |
|------|------|----------|-------------|
| `getsentry` | [getsentry/skills](https://github.com/getsentry/skills) | `D:\dev\env\skill\getsentry\` | `%USERPROFILE%\.cursor\skills\<name>\` → `getsentry\skills\<name>\` |
| `reverse-skill` | [zhaoxuya520/reverse-skill](https://github.com/zhaoxuya520/reverse-skill) | `D:\dev\env\skill\reverse-skill\` | 项目 + 用户 `reverse-skill\SKILL.md` 路由入口 |

### 示例：reverse-skill bootstrap

```powershell
Set-Location "D:\dev\env\skill\reverse-skill\skills\scripts"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\refresh-tool-index.ps1"
```

入口文件：

- `D:\dev\env\skill\reverse-skill\skills\SKILL.md`
- `D:\dev\env\skill\reverse-skill\skills\routing_zh.md`（或 `routing.md`）
- `D:\dev\env\skill\reverse-skill\skills\tool-index.md`

Burp MCP 桥接：`D:\dev\env\skill\reverse-skill\burp-mcp-full\mcp-bridge.js`

### 示例：getsentry 更新

```powershell
# 仅更新 getsentry 子目录，不得影响 reverse-skill
git -C "D:\dev\env\skill\getsentry" pull
# 或重新解压 ZIP 到 D:\dev\env\skill\getsentry\
```

---

## 开发文档与交接（硬性规则）

**任何任务完成时，若产生实质改动（代码、配置、脚本、资源、路由、端口、文档结构等），必须在收工前更新开发文档。**

### 文档位置

| 文件 | 路径 | 用途 |
|------|------|------|
| 交接文档 | `<WORKSPACE_ROOT>/交接文档.md` | 项目全貌、端口、启动、关键目录；架构级变更时同步修订 |
| 开发文档 | `<WORKSPACE_ROOT>/开发文档.md` | **当前活跃**开发流水账（每次任务一条，最新写在顶部） |
| 归档目录 | `<WORKSPACE_ROOT>/docs/handover/` | 历史开发文档、历史交接快照 |

### 文档归档与拆分（硬性规则）

**禁止**让单份 `开发文档.md` 或 `交接文档.md` 无限变长。达到阈值时**必须先归档，再在新文件中继续写**。

#### 触发条件（满足任一即归档）

| 文档 | 阈值 |
|------|------|
| `开发文档.md` | **≥ 50 条**任务记录，或 **≥ 800 行**，或 **≥ 100 KB** |
| `交接文档.md` | **≥ 400 行**，或「当前状态摘要」章节 **≥ 30 条**历史条目 |

#### 归档操作（开发文档）

1. 将当前 `开发文档.md` **整文件移动**为：  
   `docs/handover/开发文档-归档-YYYYMMDD.md`（同日再次归档则加后缀 `-2`、`-3`…）
2. 新建空白 `开发文档.md`，顶部写入：
   - 指向 `交接文档.md` 的说明
   - **归档索引**表格（文件名、归档时间、条目约数）
   - 最近 **5 条**从刚归档文件中复制的摘要（便于延续上下文）
3. 在新建 `开发文档.md` 顶部追加一条归档记录（含归档时间、原文件路径、触发原因）
4. 向用户汇报已归档及新文档路径

#### 归档操作（交接文档）

1. 将当前 `交接文档.md` 复制为：  
   `docs/handover/交接文档-快照-YYYYMMDD.md`
2. 精简根目录 `交接文档.md`：删除过时的「当前状态摘要」明细，只保留**最近状态** + 指向快照的链接
3. 细节流水仍写在 `开发文档.md`，交接文档只保留可长期有效的结构说明

#### 目录约定

```
<WORKSPACE_ROOT>/
├── 交接文档.md              # 活跃：结构说明 + 最新状态
├── 开发文档.md              # 活跃：当前开发流水
└── docs/handover/
    ├── 开发文档-归档-20260615.md
    └── 交接文档-快照-20260615.md
```

**归档本身也算一次任务**，须写入新的 `开发文档.md` 顶部。

### 每次任务必做

1. **写开发文档** — 在 `开发文档.md` **顶部**追加一条，**不得只口头汇报不写文档**
2. **必填字段**：
   - **改动时间**：本地时间，格式 `YYYY-MM-DD HH:mm`（24 小时制）
   - **任务**：一句话说明本次目标
   - **改动**：做了什么（功能、修复、配置）
   - **涉及文件**：主要路径列表（相对 `workspace` 或完整路径均可）
3. **推送 GitHub** — 有实质改动时按「Git 仓库 → 推送规则」commit + push；**禁止**改为 scp/ssh 部署到远程服务器
4. **同步交接文档** — 若涉及以下任一项，须同时更新 `交接文档.md` 对应章节：
   - 端口 / 启动方式 / 环境变量
   - 新路由、新模块、新子项目
   - 安全禁忌、部署约定
   - 「当前状态摘要」
5. **汇报用户** — 在回复中说明已写入 `开发文档.md`、是否已 push GitHub（含 commit 摘要或跳过原因），及是否更新了 `交接文档.md`

### 记录模板

```markdown
## YYYY-MM-DD HH:mm — 任务标题

**任务**：……

**改动**：
- ……

**涉及文件**：
- `path/to/file`
```

### 禁止

- **禁止** 完成任务却不写 `开发文档.md`
- **禁止** 有实质改动却不 push GitHub（改以 scp/ssh 更新远程服务器）
- **禁止** 在开发文档中写入密钥、Token、config 密码
- **禁止** 用开发文档代替 git commit message（文档是给交接与追溯用的）
- **禁止** 在已达归档阈值时继续往同一文件堆叠记录而不拆分

---

## 代码修改原则

1. **最小改动**：只改与任务相关的文件
2. **不提交敏感信息**：密钥、Token、本地 config 仅本地使用
3. **PowerShell**：旧版不支持 `&&`，用 `;` 或分行执行

## 用户授权与执行

- 当用户明确表示“**全权授权** / **不要再问我** / **接下来你全权执行**”时，在当前任务范围内，Agent 应直接继续执行必要步骤，**不要反复征求同类操作授权**。
- 该授权**不覆盖**涉及敏感信息泄露、提交密钥、远程服务器部署、破坏性 git 操作（如 `reset --hard`、`push --force`）等已有硬性禁令；这些仍遵循本文件其他规则。
- 在全权执行模式下，每完成一段关键操作后，Agent 必须进行**自审**：检查本次动作是否有前置条件遗漏、命令执行漏洞、状态判断偏差或日志/证据缺失；若发现问题，先修复再继续执行。
- 若用户特别要求“写进 `AGENTS.md`”，应将授权口径落到本文件，并同时在 `开发文档.md` 记录本次新增约定与适用范围。

## 交流语言

- 用户用**中文**提问时，一律用**简体中文**回答
- 代码、命令、路径、API 名、变量名等技术标识保持英文原文
- 用户明确用英文交流时，改用英文回答
