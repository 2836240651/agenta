package main

import (
	"commander-server-t260220/ioc"
)

func main() {

	r, err := ioc.Initialize()
	if err != nil {
		panic(err)
	}

	// 注册路由
	r.Register()
	// 从 DB 恢复未完成任务
	r.Prepare()

	// 启动路由
	err = r.Run()
	if err != nil {
		panic(err)
	}
}
