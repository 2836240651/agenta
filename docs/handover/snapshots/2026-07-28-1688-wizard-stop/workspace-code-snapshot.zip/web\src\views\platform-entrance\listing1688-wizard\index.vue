<template>
  <section class="wizard1688">
    <div class="wizard1688__bg" aria-hidden="true" />
    <div class="wizard1688__inner">
      <header class="wizard1688__header">
        <nav class="wizard1688__nav">
          <router-link to="/1688-auto-upload" class="wizard1688__back">
            <Icon icon="mdi:arrow-left" aria-hidden="true" />
            <span>{{ t('listing1688Wizard.backMatrix') }}</span>
          </router-link>
          <router-link to="/1688-auto-upload/listing" class="wizard1688__back wizard1688__back--muted">
            <span>{{ t('listing1688Wizard.toV1Listing') }}</span>
          </router-link>
        </nav>
        <h1 class="wizard1688__title">{{ t('listing1688Wizard.title') }}</h1>
        <p class="wizard1688__desc">{{ t('listing1688Wizard.desc') }}</p>
      </header>

      <ol class="wizard1688__steps" aria-label="Wizard steps">
        <li
          v-for="(step, idx) in steps"
          :key="step.key"
          class="wizard1688__step"
          :class="{
            'wizard1688__step--active': currentStep === idx,
            'wizard1688__step--clickable': !!workflowId
          }"
        >
          <button
            type="button"
            class="wizard1688__step-btn"
            :disabled="!workflowId"
            :aria-current="currentStep === idx ? 'step' : undefined"
            @click="goStep(idx)"
          >
            <span class="wizard1688__step-num">{{ idx + 1 }}</span>
            <span class="wizard1688__step-label">{{ step.label }}</span>
          </button>
        </li>
      </ol>

      <div class="wizard1688__panel">
        <template v-if="!workflowId">
          <h2 class="wizard1688__panel-title">{{ t('listing1688Wizard.selectAgentTitle') }}</h2>
          <p class="wizard1688__panel-hint">{{ t('listing1688Wizard.selectAgentHint') }}</p>
          <div v-if="agentLoading" class="wizard1688__state">{{ t('listing1688Wizard.loadingAgents') }}</div>
          <div v-else-if="agentError" class="wizard1688__state wizard1688__state--err">{{ agentError }}</div>
          <div v-else-if="!agents.length" class="wizard1688__state">{{ t('listing1688Wizard.agentsEmpty') }}</div>
          <ul v-else class="wizard1688__agents">
            <li v-for="agent in agents" :key="agent.uuid" class="wizard1688__agent">
              <button
                type="button"
                class="wizard1688__agent-btn"
                :class="{ 'wizard1688__agent-btn--selected': selectedAgentId === agent.uuid }"
                :disabled="creating"
                @click="selectedAgentId = agent.uuid"
              >
                <span
                  class="wizard1688__agent-dot"
                  :class="{ 'wizard1688__agent-dot--on': !!agent.status }"
                />
                <span class="wizard1688__agent-name">{{ agent.name || agent.uuid }}</span>
                <span class="wizard1688__agent-status">
                  {{ agent.status ? t('listing1688Wizard.online') : t('listing1688Wizard.offline') }}
                </span>
              </button>
            </li>
          </ul>
          <div class="wizard1688__actions">
            <button
              type="button"
              class="wizard1688__btn wizard1688__btn--primary"
              :disabled="!selectedAgentId || creating"
              @click="createWorkflow"
            >
              {{ creating ? t('listing1688Wizard.creating') : t('listing1688Wizard.createWorkflow') }}
            </button>
          </div>
          <p v-if="createError" class="wizard1688__state wizard1688__state--err">{{ createError }}</p>
        </template>

        <template v-else>
          <div class="wizard1688__meta">
            <span>{{ t('listing1688Wizard.workflowId') }}: {{ workflowId }}</span>
            <span>{{ t('listing1688Wizard.status') }}: {{ workflowStatus }}</span>
          </div>

          <div v-if="currentStep === 0" class="wizard1688__step-body">
            <h2 class="wizard1688__panel-title">{{ t('listing1688Wizard.step1Title') }}</h2>
            <p class="wizard1688__panel-hint">{{ t('listing1688Wizard.step1Hint') }}</p>
            <div class="wizard1688__actions">
              <button
                type="button"
                class="wizard1688__btn wizard1688__btn--primary"
                :disabled="sessionBusy"
                @click="openLogin"
              >
                {{ sessionBusy ? t('listing1688Wizard.working') : t('listing1688Wizard.openLogin') }}
              </button>
              <button
                type="button"
                class="wizard1688__btn"
                :disabled="sessionBusy || workflowStatus === 'draft'"
                @click="confirmLogin"
              >
                {{ t('listing1688Wizard.confirmLogin') }}
              </button>
            </div>
            <p v-if="sessionOpenHint" class="wizard1688__m-note">{{ sessionOpenHint }}</p>
            <p v-if="stepError" class="wizard1688__state wizard1688__state--err">{{ stepError }}</p>
            <p v-else-if="workflowStatus === 'session_valid'" class="wizard1688__m-note">
              {{ t('listing1688Wizard.sessionValidHint') }}
            </p>
          </div>

          <div v-else-if="currentStep === 1" class="wizard1688__step-body">
            <h2 class="wizard1688__panel-title">{{ t('listing1688Wizard.step2Title') }}</h2>
            <p class="wizard1688__panel-hint">{{ t('listing1688Wizard.step2Hint') }}</p>
            <label class="wizard1688__field">
              <span>{{ t('listing1688Wizard.offerUrlLabel') }}</span>
              <input
                v-model="offerUrl"
                type="url"
                class="wizard1688__input"
                :placeholder="t('listing1688Wizard.offerUrlPlaceholder')"
                :disabled="collectBusy"
                autocomplete="url"
              />
            </label>
            <div class="wizard1688__actions">
              <button
                type="button"
                class="wizard1688__btn wizard1688__btn--primary"
                :disabled="collectBusy || !sessionValid || !offerUrl.trim()"
                @click="runCollect(false)"
              >
                {{ collectBusy ? t('listing1688Wizard.working') : t('listing1688Wizard.analyze') }}
              </button>
              <button
                type="button"
                class="wizard1688__btn"
                :disabled="collectBusy || !sessionValid"
                @click="runCollect(true)"
              >
                {{ t('listing1688Wizard.retryCollect') }}
              </button>
            </div>
            <p v-if="!sessionValid" class="wizard1688__m-note">{{ t('listing1688Wizard.needSessionFirst') }}</p>
            <p v-if="stepError" class="wizard1688__state wizard1688__state--err">{{ stepError }}</p>
            <div v-if="preview" class="wizard1688__preview">
              <h3>{{ preview.title }}</h3>
              <p class="wizard1688__m-note">
                offer={{ preview.offer_id }} ·
                {{ t('listing1688Wizard.priceRange') }}:
                {{ preview.price_min ?? '-' }} ~ {{ preview.price_max ?? '-' }}
              </p>
              <div class="wizard1688__thumbs">
                <img
                  v-for="(src, i) in (preview.main_images || []).slice(0, 6)"
                  :key="i"
                  :src="src"
                  alt=""
                />
              </div>
              <p class="wizard1688__m-note">
                SKU: {{ Array.isArray(preview.skus) ? preview.skus.length : 0 }}
              </p>
            </div>
          </div>

          <div v-else-if="currentStep === 2" class="wizard1688__step-body">
            <h2 class="wizard1688__panel-title">{{ t('listing1688Wizard.step3Title') }}</h2>
            <p class="wizard1688__panel-hint">{{ t('listing1688Wizard.step3Hint') }}</p>
            <p v-if="!canEditImages" class="wizard1688__m-note">{{ t('listing1688Wizard.step3NeedCollect') }}</p>
            <template v-else>
              <div class="wizard1688__actions">
                <button
                  type="button"
                  class="wizard1688__btn"
                  :disabled="imageBusy"
                  @click="ensureImageSlots"
                >
                  {{ t('listing1688Wizard.ensureSlots') }}
                </button>
              </div>
              <ul v-if="imageJobs.length" class="wizard1688__slots">
                <li v-for="job in imageJobs" :key="job.slot" class="wizard1688__slot">
                  <div class="wizard1688__slot-head">
                    <strong>
                      {{ t('listing1688Wizard.slotLabel') }} {{ job.slot }}
                      ·
                      {{ job.slot === 0 ? t('listing1688Wizard.slotMain') : t('listing1688Wizard.slotExtra') }}
                    </strong>
                    <span
                      v-if="job.status === 'selected'"
                      class="wizard1688__slot-pill wizard1688__slot-pill--ok"
                    >
                      {{ t('listing1688Wizard.slotPickedHint') }}
                    </span>
                    <span v-else class="wizard1688__m-note">{{ t('listing1688Wizard.slotPickHint') }}</span>
                  </div>
                  <div class="wizard1688__pick-row" role="radiogroup" :aria-label="t('listing1688Wizard.slotPickHint')">
                    <div
                      class="wizard1688__pick"
                      :class="{
                        'wizard1688__pick--on': isSideSelected(job, 'source'),
                        'wizard1688__pick--pulse': pickPulseKey === `${job.slot}:source`,
                        'wizard1688__pick--disabled': imageBusy || !job.source_url
                      }"
                      role="button"
                      tabindex="0"
                      :aria-pressed="isSideSelected(job, 'source')"
                      :aria-disabled="imageBusy || !job.source_url"
                      @click="!(imageBusy || !job.source_url) && pickSlotSide(job, 'source')"
                      @keydown.enter.prevent="!(imageBusy || !job.source_url) && pickSlotSide(job, 'source')"
                      @keydown.space.prevent="!(imageBusy || !job.source_url) && pickSlotSide(job, 'source')"
                    >
                      <span class="wizard1688__pick-tag">{{ t('listing1688Wizard.slotSource') }}</span>
                      <span class="wizard1688__pick-frame">
                        <img v-if="job.source_url" :src="job.source_url" alt="" draggable="false" />
                        <span v-if="isSideSelected(job, 'source')" class="wizard1688__pick-check" aria-hidden="true">
                          <Icon icon="mdi:check-bold" />
                        </span>
                      </span>
                      <button
                        v-if="job.source_url"
                        type="button"
                        class="wizard1688__pick-zoom"
                        :title="t('listing1688Wizard.slotZoom')"
                        :aria-label="t('listing1688Wizard.slotZoom')"
                        @click.stop="openLightbox(job.source_url, t('listing1688Wizard.slotSource'))"
                      >
                        <Icon icon="mdi:magnify-plus-outline" />
                      </button>
                    </div>
                    <div
                      class="wizard1688__pick"
                      :class="{
                        'wizard1688__pick--on': isSideSelected(job, 'result'),
                        'wizard1688__pick--empty': !hasAiResult(job),
                        'wizard1688__pick--pulse': pickPulseKey === `${job.slot}:result`,
                        'wizard1688__pick--disabled': imageBusy || !hasAiResult(job)
                      }"
                      role="button"
                      tabindex="0"
                      :aria-pressed="isSideSelected(job, 'result')"
                      :aria-disabled="imageBusy || !hasAiResult(job)"
                      @click="!(imageBusy || !hasAiResult(job)) && pickSlotSide(job, 'result')"
                      @keydown.enter.prevent="!(imageBusy || !hasAiResult(job)) && pickSlotSide(job, 'result')"
                      @keydown.space.prevent="!(imageBusy || !hasAiResult(job)) && pickSlotSide(job, 'result')"
                    >
                      <span class="wizard1688__pick-tag">{{ t('listing1688Wizard.slotResult') }}</span>
                      <span class="wizard1688__pick-frame">
                        <img v-if="hasAiResult(job)" :src="job.result_url" alt="" draggable="false" />
                        <span v-else class="wizard1688__pick-placeholder">{{ t('listing1688Wizard.slotResultEmpty') }}</span>
                        <span v-if="isSideSelected(job, 'result')" class="wizard1688__pick-check" aria-hidden="true">
                          <Icon icon="mdi:check-bold" />
                        </span>
                      </span>
                      <button
                        v-if="hasAiResult(job)"
                        type="button"
                        class="wizard1688__pick-zoom"
                        :title="t('listing1688Wizard.slotZoom')"
                        :aria-label="t('listing1688Wizard.slotZoom')"
                        @click.stop="openLightbox(job.result_url, t('listing1688Wizard.slotResult'))"
                      >
                        <Icon icon="mdi:magnify-plus-outline" />
                      </button>
                    </div>
                  </div>
                  <label class="wizard1688__field">
                    <span>{{ t('listing1688Wizard.slotPrompt') }}</span>
                    <input
                      v-model="slotPrompts[job.slot]"
                      type="text"
                      class="wizard1688__input"
                      :disabled="imageBusy"
                    />
                  </label>
                  <div class="wizard1688__actions">
                    <button
                      type="button"
                      class="wizard1688__btn wizard1688__btn--primary"
                      :disabled="imageBusy"
                      @click="runImageAction('generate', job.slot)"
                    >
                      {{ t('listing1688Wizard.slotGenerate') }}
                    </button>
                    <button
                      type="button"
                      class="wizard1688__btn"
                      :disabled="imageBusy"
                      @click="runImageAction('regenerate', job.slot)"
                    >
                      {{ t('listing1688Wizard.slotRegenerate') }}
                    </button>
                  </div>
                </li>
              </ul>
              <p v-if="workflowStatus === 'img_ready'" class="wizard1688__m-note">
                {{ t('listing1688Wizard.imgReadyHint') }}
              </p>
            </template>
            <p v-if="stepError" class="wizard1688__state wizard1688__state--err">{{ stepError }}</p>
          </div>

          <div v-else class="wizard1688__step-body">
            <h2 class="wizard1688__panel-title">{{ t('listing1688Wizard.step4Title') }}</h2>
            <p class="wizard1688__panel-hint">{{ t('listing1688Wizard.step4Hint') }}</p>
            <p v-if="workflowStatus !== 'img_ready' && workflowStatus !== 'publishing' && workflowStatus !== 'published'" class="wizard1688__state wizard1688__state--err">
              {{ t('listing1688Wizard.imagesNotReady') }}
            </p>
            <template v-else>
              <div class="wizard1688__actions">
                <button
                  type="button"
                  class="wizard1688__btn wizard1688__btn--primary"
                  :disabled="sellerBusy || publishBusy"
                  @click="openSellerLogin"
                >
                  {{ t('listing1688Wizard.sellerOpenLogin') }}
                </button>
                <button
                  type="button"
                  class="wizard1688__btn"
                  :disabled="sellerBusy || publishBusy"
                  @click="confirmSellerLogin"
                >
                  {{ t('listing1688Wizard.sellerConfirmLogin') }}
                </button>
                <button
                  type="button"
                  class="wizard1688__btn"
                  :disabled="sellerBusy || publishBusy || !sellerOk"
                  @click="validateSellerLogin"
                >
                  {{ t('listing1688Wizard.sellerValidate') }}
                </button>
              </div>
              <p v-if="sellerOk" class="wizard1688__m-note">{{ t('listing1688Wizard.sellerOkHint') }}</p>
              <div class="wizard1688__actions">
                <button
                  type="button"
                  class="wizard1688__btn"
                  :disabled="templateBusy || !sellerOk"
                  @click="loadTemplateCandidates"
                >
                  {{ templateBusy ? t('listing1688Wizard.working') : t('listing1688Wizard.loadTemplateCandidates') }}
                </button>
              </div>
              <p v-if="similarPageUrl" class="wizard1688__m-note">
                {{ t('listing1688Wizard.similarPageReady') }}: {{ similarPageUrl }}
              </p>
              <div v-if="templateCandidates.length" class="wizard1688__templates">
                <h3 class="wizard1688__sub-title">{{ t('listing1688Wizard.templateCandidatesTitle') }}</h3>
                <div
                  v-for="candidate in templateCandidates"
                  :key="candidate.offer_id"
                  class="wizard1688__template-card"
                  :class="{ 'wizard1688__template-card--selected': selectedTemplateOfferId === candidate.offer_id }"
                >
                  <div class="wizard1688__template-head">
                    <strong>{{ candidate.title }}</strong>
                    <span class="wizard1688__slot-pill wizard1688__slot-pill--ok">
                      Score {{ candidate.score ?? 0 }}
                    </span>
                  </div>
                  <p class="wizard1688__m-note">
                    offer={{ candidate.offer_id }}
                    <template v-if="candidate.price_text"> · {{ candidate.price_text }}</template>
                  </p>
                  <p v-if="candidate.reason_summary" class="wizard1688__m-note">{{ candidate.reason_summary }}</p>
                  <div class="wizard1688__actions">
                    <button
                      type="button"
                      class="wizard1688__btn"
                      :disabled="templateBusy"
                      @click="selectTemplateCandidate(candidate)"
                    >
                      {{ selectedTemplateOfferId === candidate.offer_id ? t('listing1688Wizard.templateSelected') : t('listing1688Wizard.useThisTemplate') }}
                    </button>
                  </div>
                </div>
              </div>
              <div class="wizard1688__actions">
                <button
                  type="button"
                  class="wizard1688__btn"
                  :disabled="templateBusy || !selectedTemplateOfferId"
                  @click="openSimilarPublishPage"
                >
                  {{ t('listing1688Wizard.openSimilarPage') }}
                </button>
                <button
                  type="button"
                  class="wizard1688__btn"
                  :disabled="formBusy || !matchedCategoryId"
                  @click="inspectCategoryForm"
                >
                  {{ t('listing1688Wizard.inspectCategory') }}
                </button>
                <button
                  type="button"
                  class="wizard1688__btn"
                  :disabled="formBusy || !matchedCategoryId"
                  @click="validatePublishDraft"
                >
                  {{ t('listing1688Wizard.validatePublishDraft') }}
                </button>
                <button
                  type="button"
                  class="wizard1688__btn"
                  :disabled="formBusy || !canSaveDraft"
                  @click="savePublishDraft"
                >
                  {{ t('listing1688Wizard.saveDraftBtn') }}
                </button>
              </div>
              <p v-if="matchedCategoryId" class="wizard1688__m-note">
                {{ t('listing1688Wizard.matchedCategory') }}: {{ matchedCategoryId }}
              </p>
              <p v-if="publishDraft?.validation_status" class="wizard1688__m-note">
                {{ t('listing1688Wizard.publishDraftStatus') }}: {{ publishDraft.validation_status }}
                <template v-if="publishDraft?.draft_saved"> · {{ t('listing1688Wizard.draftSaved') }}</template>
              </p>
              <p v-if="categoryInspect?.required_fields?.length" class="wizard1688__m-note">
                {{ t('listing1688Wizard.requiredFieldsCount') }}: {{ categoryInspect.required_fields.length }}
              </p>
              <label class="wizard1688__field">
                <span>{{ t('listing1688Wizard.publishTitleLabel') }}</span>
                <input v-model="publishTitle" type="text" class="wizard1688__input" :disabled="publishBusy" />
              </label>
              <p class="wizard1688__m-note">{{ t('listing1688Wizard.selectedImages') }}: {{ selectedImageCount }}</p>
              <div class="wizard1688__thumbs" v-if="selectedImageUrls.length">
                <img v-for="(src, i) in selectedImageUrls" :key="i" :src="src" alt="" />
              </div>
              <div class="wizard1688__actions">
                <button
                  type="button"
                  class="wizard1688__btn wizard1688__btn--primary"
                  :disabled="publishBusy || !sellerOk || workflowStatus === 'published' || !canPublishNow"
                  @click="runPublish"
                >
                  {{ publishBusy || workflowStatus === 'publishing' ? t('listing1688Wizard.publishing') : t('listing1688Wizard.publishBtn') }}
                </button>
              </div>
              <p v-if="workflowStatus === 'published'" class="wizard1688__m-note">{{ t('listing1688Wizard.publishSuccess') }}</p>
            </template>
            <p v-if="stepError" class="wizard1688__state wizard1688__state--err">{{ stepError }}</p>
          </div>

          <div class="wizard1688__actions">
            <button
              type="button"
              class="wizard1688__btn"
              :disabled="currentStep === 0"
              @click="goStep(currentStep - 1)"
            >
              {{ t('listing1688Wizard.prev') }}
            </button>
            <button
              type="button"
              class="wizard1688__btn wizard1688__btn--primary"
              :disabled="!canGoNext"
              @click="goNext"
            >
              {{ t('listing1688Wizard.next') }}
            </button>
          </div>
          <p class="wizard1688__m-note">{{ t('listing1688Wizard.browseShellHint') }}</p>
        </template>
      </div>
    </div>

    <Teleport to="body">
      <div
        v-if="lightbox.url"
        class="wizard1688-lb"
        role="dialog"
        aria-modal="true"
        :aria-label="lightbox.caption || t('listing1688Wizard.slotZoom')"
        @click.self="closeLightbox"
      >
        <button type="button" class="wizard1688-lb__close" :aria-label="t('listing1688Wizard.slotZoomClose')" @click="closeLightbox">
          <Icon icon="mdi:close" />
        </button>
        <figure class="wizard1688-lb__figure" @click.stop>
          <img :src="lightbox.url" :alt="lightbox.caption || ''" />
          <figcaption v-if="lightbox.caption">{{ lightbox.caption }}</figcaption>
        </figure>
      </div>
    </Teleport>
  </section>
</template>

<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { useRoute } from 'vue-router'
import { Icon } from '@iconify/vue'
import { getAgentList } from '@/api/modules/agent.js'
import {
  createListing1688Workflow,
  getListing1688Workflow,
  listing1688SessionOpenLogin,
  listing1688SessionConfirm,
  listing1688Collect,
  listing1688CollectRetry,
  listing1688ImagesGenerate,
  listing1688ImagesRegenerate,
  listing1688ImagesSelect,
  listing1688ImagesUseOriginal,
  listing1688SellerOpenLogin,
  listing1688SellerConfirm,
  listing1688SellerValidate,
  listing1688TemplateCandidates,
  listing1688TemplateSelect,
  listing1688TemplateOpenSimilar,
  listing1688CategoryInspect,
  listing1688PublishFormValidate,
  listing1688PublishFormSaveDraft,
  listing1688Publish,
  listing1688PublishStatus
} from '@/api/modules/listing1688.js'
import { mapWizardError } from '@/utils/listing1688Error.js'

const { t } = useI18n()
const route = useRoute()

const steps = computed(() => [
  { key: 'login', label: t('listing1688Wizard.step1') },
  { key: 'collect', label: t('listing1688Wizard.step2') },
  { key: 'images', label: t('listing1688Wizard.step3') },
  { key: 'publish', label: t('listing1688Wizard.step4') }
])

const agents = ref([])
const agentLoading = ref(false)
const agentError = ref('')
const selectedAgentId = ref('')
const creating = ref(false)
const createError = ref('')
const workflowId = ref(null)
const workflowStatus = ref('')
const currentStep = ref(0)
const sessionBusy = ref(false)
const collectBusy = ref(false)
const imageBusy = ref(false)
const sellerBusy = ref(false)
const templateBusy = ref(false)
const formBusy = ref(false)
const publishBusy = ref(false)
const sellerOk = ref(false)
const publishTitle = ref('')
const selectedImageUrls = ref([])
const stepError = ref('')
const sessionOpenHint = ref('')
const offerUrl = ref('')
const preview = ref(null)
const imageJobs = ref([])
const templateCandidates = ref([])
const selectedTemplateOfferId = ref('')
const matchedCategoryId = ref('')
const similarPageUrl = ref('')
const categoryInspect = ref(null)
const publishDraft = ref(null)
const slotPrompts = reactive({})
const pickPulseKey = ref('')
const lightbox = reactive({ url: '', caption: '' })
let pickPulseTimer = 0

const selectedImageCount = computed(() => selectedImageUrls.value.length)
const sessionValid = computed(() =>
  ['session_valid', 'collected', 'collecting', 'failed', 'img_editing', 'img_ready'].includes(
    workflowStatus.value
  )
)

const canEditImages = computed(() =>
  ['collected', 'img_editing', 'img_ready'].includes(workflowStatus.value)
)

const canGoNext = computed(() => {
  if (currentStep.value >= 3) return false
  if (currentStep.value === 2 && workflowStatus.value !== 'img_ready') return false
  return true
})

const canSaveDraft = computed(() =>
  !!matchedCategoryId.value && publishDraft.value?.validation_status === 'ready'
)

const canPublishNow = computed(() =>
  !!selectedTemplateOfferId.value &&
  !!matchedCategoryId.value &&
  !!publishDraft.value?.draft_saved
)

function sameImageUrl(a, b) {
  const x = String(a || '').trim()
  const y = String(b || '').trim()
  if (!x || !y) return false
  return x === y || x.split('?')[0] === y.split('?')[0]
}

function hasAiResult(job) {
  const result = String(job?.result_url || '').trim()
  if (!result) return false
  return !sameImageUrl(result, job?.source_url)
}

function isSideSelected(job, side) {
  if (job?.status !== 'selected' || !job?.result_url) return false
  const usingSource = sameImageUrl(job.result_url, job.source_url)
  return side === 'source' ? usingSource : !usingSource
}

function triggerPickPulse(slot, side) {
  pickPulseKey.value = `${slot}:${side}`
  if (pickPulseTimer) window.clearTimeout(pickPulseTimer)
  pickPulseTimer = window.setTimeout(() => {
    pickPulseKey.value = ''
    pickPulseTimer = 0
  }, 480)
}

function openLightbox(url, caption) {
  const src = String(url || '').trim()
  if (!src) return
  lightbox.url = src
  lightbox.caption = caption || ''
}

function closeLightbox() {
  lightbox.url = ''
  lightbox.caption = ''
}

function onLightboxKey(e) {
  if (e.key === 'Escape' && lightbox.url) closeLightbox()
}

async function pickSlotSide(job, side) {
  if (!workflowId.value || imageBusy.value || !canEditImages.value || !job) return
  if (side === 'source') {
    if (!job.source_url) return
    if (isSideSelected(job, 'source')) {
      openLightbox(job.source_url, t('listing1688Wizard.slotSource'))
      return
    }
    imageBusy.value = true
    stepError.value = ''
    try {
      let data = await listing1688ImagesUseOriginal(workflowId.value, { slot: job.slot })
      data = await listing1688ImagesSelect(workflowId.value, { slot: job.slot })
      workflowStatus.value = data?.status || workflowStatus.value
      applyImageJobs(data?.image_jobs || [])
      triggerPickPulse(job.slot, 'source')
    } catch (e) {
      stepError.value = mapErr(e)
      await refreshWorkflow().catch(() => {})
    } finally {
      imageBusy.value = false
    }
    return
  }
  if (!hasAiResult(job)) return
  if (isSideSelected(job, 'result')) {
    openLightbox(job.result_url, t('listing1688Wizard.slotResult'))
    return
  }
  imageBusy.value = true
  stepError.value = ''
  try {
    const data = await listing1688ImagesSelect(workflowId.value, { slot: job.slot })
    workflowStatus.value = data?.status || workflowStatus.value
    applyImageJobs(data?.image_jobs || [])
    triggerPickPulse(job.slot, 'result')
  } catch (e) {
    stepError.value = mapErr(e)
    await refreshWorkflow().catch(() => {})
  } finally {
    imageBusy.value = false
  }
}

function applyImageJobs(jobs) {
  const list = Array.isArray(jobs) ? jobs : []
  imageJobs.value = list
  for (const j of list) {
    if (slotPrompts[j.slot] == null || slotPrompts[j.slot] === '') {
      slotPrompts[j.slot] = j.prompt || ''
    }
  }
}

/** 步骤浏览：Step4 须 img_ready（C5）；其余步骤可浏览占位 */
function goStep(idx) {
  if (!workflowId.value) return
  const next = Math.max(0, Math.min(3, Number(idx)))
  if (next === 3 && !['img_ready', 'publishing', 'published'].includes(workflowStatus.value)) {
    stepError.value = mapWizardError('IMAGES_NOT_READY', t)
    return
  }
  currentStep.value = next
  stepError.value = ''
  if (next === 2 && canEditImages.value && !imageJobs.value.length) {
    ensureImageSlots().catch(() => {})
  }
}

function goNext() {
  if (!canGoNext.value) {
    if (currentStep.value === 2) {
      stepError.value = mapWizardError('IMAGES_NOT_READY', t)
    }
    return
  }
  goStep(currentStep.value + 1)
}

function mapErr(e) {
  return mapWizardError(e?.message || String(e || ''), t)
}

async function refreshWorkflow() {
  if (!workflowId.value) return
  const detail = await getListing1688Workflow(workflowId.value)
  workflowStatus.value = detail?.status || workflowStatus.value
  preview.value = null
  imageJobs.value = []
  templateCandidates.value = []
  selectedTemplateOfferId.value = ''
  matchedCategoryId.value = ''
  similarPageUrl.value = ''
  selectedImageUrls.value = []
  categoryInspect.value = null
  publishDraft.value = null
  sellerOk.value = false
  if (detail?.offer_url) offerUrl.value = detail.offer_url
  if (detail?.image_jobs) applyImageJobs(detail.image_jobs)
  selectedTemplateOfferId.value = detail?.matched_template_offer_id || ''
  matchedCategoryId.value = detail?.matched_category_id || ''
  similarPageUrl.value = detail?.similar_page_url || ''
  const matchResult = detail?.template_match_result
  templateCandidates.value = matchResult && Array.isArray(matchResult.candidates) ? matchResult.candidates : []
  if (Array.isArray(detail?.selected_image_idx)) {
    selectedImageUrls.value = detail.selected_image_idx
      .map((x) => x?.result_url)
      .filter(Boolean)
  } else if (typeof detail?.selected_image_idx === 'string') {
    try {
      const arr = JSON.parse(detail.selected_image_idx)
      selectedImageUrls.value = (arr || []).map((x) => x?.result_url).filter(Boolean)
    } catch (_) {}
  }
  if (detail?.offer_snapshot) {
    const snap = typeof detail.offer_snapshot === 'string'
      ? JSON.parse(detail.offer_snapshot)
      : detail.offer_snapshot
    if (snap?.title) {
      preview.value = {
        title: snap.title,
        main_images: snap.main_images || [],
        skus: snap.skus || [],
        price_min: snap.price_min,
        price_max: snap.price_max,
        offer_id: snap.source_item_id,
        url: snap.url
      }
      if (!publishTitle.value) publishTitle.value = snap.title
    }
  }
}

async function openSellerLogin() {
  if (!workflowId.value || sellerBusy.value) return
  sellerBusy.value = true
  stepError.value = ''
  try {
    await listing1688SellerOpenLogin(workflowId.value)
  } catch (e) {
    stepError.value = mapErr(e)
  } finally {
    sellerBusy.value = false
  }
}

async function confirmSellerLogin() {
  if (!workflowId.value || sellerBusy.value) return
  sellerBusy.value = true
  stepError.value = ''
  try {
    await listing1688SellerConfirm(workflowId.value)
    sellerOk.value = true
  } catch (e) {
    sellerOk.value = false
    stepError.value = mapErr(e)
  } finally {
    sellerBusy.value = false
  }
}

async function validateSellerLogin() {
  if (!workflowId.value || sellerBusy.value) return
  sellerBusy.value = true
  stepError.value = ''
  try {
    await listing1688SellerValidate(workflowId.value)
    sellerOk.value = true
  } catch (e) {
    sellerOk.value = false
    stepError.value = mapErr(e)
  } finally {
    sellerBusy.value = false
  }
}

async function loadTemplateCandidates() {
  if (!workflowId.value || templateBusy.value || !sellerOk.value) return
  templateBusy.value = true
  stepError.value = ''
  try {
    const data = await listing1688TemplateCandidates(workflowId.value, { limit: 3 })
    templateCandidates.value = Array.isArray(data?.candidates) ? data.candidates : []
    if (!selectedTemplateOfferId.value && templateCandidates.value.length) {
      selectedTemplateOfferId.value = templateCandidates.value[0].offer_id || ''
    }
    if (data?.page_url) similarPageUrl.value = data.page_url
  } catch (e) {
    stepError.value = mapErr(e)
  } finally {
    templateBusy.value = false
  }
}

async function selectTemplateCandidate(candidate) {
  if (!workflowId.value || templateBusy.value || !candidate?.offer_id) return
  templateBusy.value = true
  stepError.value = ''
  try {
    const data = await listing1688TemplateSelect(workflowId.value, {
      offer_id: candidate.offer_id,
      title: candidate.title,
      category_id: candidate.category_id || ''
    })
    selectedTemplateOfferId.value = data?.matched_template_offer_id || candidate.offer_id
    matchedCategoryId.value = data?.matched_category_id || matchedCategoryId.value
  } catch (e) {
    stepError.value = mapErr(e)
  } finally {
    templateBusy.value = false
  }
}

async function openSimilarPublishPage() {
  if (!workflowId.value || templateBusy.value || !selectedTemplateOfferId.value) return
  templateBusy.value = true
  stepError.value = ''
  try {
    const data = await listing1688TemplateOpenSimilar(workflowId.value, {
      offer_id: selectedTemplateOfferId.value
    })
    matchedCategoryId.value = data?.matched_category_id || matchedCategoryId.value
    similarPageUrl.value = data?.similar_page_url || similarPageUrl.value
  } catch (e) {
    stepError.value = mapErr(e)
  } finally {
    templateBusy.value = false
  }
}

async function inspectCategoryForm() {
  if (!workflowId.value || formBusy.value || !matchedCategoryId.value) return
  formBusy.value = true
  stepError.value = ''
  try {
    categoryInspect.value = await listing1688CategoryInspect(workflowId.value, {
      category_id: matchedCategoryId.value
    })
  } catch (e) {
    stepError.value = mapErr(e)
  } finally {
    formBusy.value = false
  }
}

async function validatePublishDraft() {
  if (!workflowId.value || formBusy.value || !matchedCategoryId.value) return
  formBusy.value = true
  stepError.value = ''
  try {
    publishDraft.value = await listing1688PublishFormValidate(workflowId.value, {
      category_id: matchedCategoryId.value,
      fields: {}
    })
  } catch (e) {
    stepError.value = mapErr(e)
  } finally {
    formBusy.value = false
  }
}

async function savePublishDraft() {
  if (!workflowId.value || formBusy.value || !canSaveDraft.value) return
  formBusy.value = true
  stepError.value = ''
  try {
    const data = await listing1688PublishFormSaveDraft(workflowId.value, {})
    publishDraft.value = {
      ...(publishDraft.value || {}),
      ...data
    }
  } catch (e) {
    stepError.value = mapErr(e)
  } finally {
    formBusy.value = false
  }
}

async function runPublish() {
  if (!workflowId.value || publishBusy.value || !sellerOk.value || !canPublishNow.value) return
  publishBusy.value = true
  stepError.value = ''
  try {
    const data = await listing1688Publish(workflowId.value, { title: publishTitle.value.trim() })
    workflowStatus.value = data?.status || 'publishing'
    await pollPublishStatus()
  } catch (e) {
    stepError.value = mapErr(e)
    await refreshWorkflow().catch(() => {})
  } finally {
    publishBusy.value = false
  }
}

async function pollPublishStatus() {
  for (let i = 0; i < 60; i++) {
    await new Promise((r) => setTimeout(r, 2000))
    try {
      const st = await listing1688PublishStatus(workflowId.value)
      workflowStatus.value = st?.status || workflowStatus.value
      if (st?.status === 'published') return
      if (st?.status === 'img_ready' && st?.error_code) {
        stepError.value = mapWizardError(st.error_code + ': ' + (st.message || ''), t)
        return
      }
    } catch (_) {
      break
    }
  }
}
async function ensureImageSlots() {
  if (!workflowId.value || !canEditImages.value || imageBusy.value) return
  imageBusy.value = true
  stepError.value = ''
  try {
    await refreshWorkflow()
  } catch (e) {
    stepError.value = mapErr(e)
  } finally {
    imageBusy.value = false
  }
}

async function pollImageSlotUntilSettled(slot, timeoutMs = 600000) {
  const t0 = Date.now()
  while (Date.now() - t0 < timeoutMs) {
    await refreshWorkflow()
    const job = imageJobs.value.find((j) => Number(j?.slot) === Number(slot))
    const st = String(job?.status || '')
    if (st && st !== 'running') return job
    await new Promise((r) => setTimeout(r, 2000))
  }
  throw new Error('生图超时，请稍后刷新查看结果')
}

async function runImageAction(kind, slot) {
  if (!workflowId.value || imageBusy.value || !canEditImages.value) return
  imageBusy.value = true
  stepError.value = ''
  try {
    const prompt = String(slotPrompts[slot] ?? '').trim()
    let data
    if (kind === 'generate') {
      data = await listing1688ImagesGenerate(workflowId.value, { slot, prompt })
      workflowStatus.value = data?.status || workflowStatus.value
      applyImageJobs(data?.image_jobs || [])
      if (data?.job?.prompt) slotPrompts[slot] = data.job.prompt
      const settled = await pollImageSlotUntilSettled(slot)
      if (settled?.status === 'failed') {
        throw new Error(settled.message || '图生图失败')
      }
    } else if (kind === 'regenerate') {
      data = await listing1688ImagesRegenerate(workflowId.value, { slot, prompt })
      workflowStatus.value = data?.status || workflowStatus.value
      applyImageJobs(data?.image_jobs || [])
      if (data?.job?.prompt) slotPrompts[slot] = data.job.prompt
      const settled = await pollImageSlotUntilSettled(slot)
      if (settled?.status === 'failed') {
        throw new Error(settled.message || '图生图失败')
      }
    } else if (kind === 'useOriginal') {
      data = await listing1688ImagesUseOriginal(workflowId.value, { slot })
      workflowStatus.value = data?.status || workflowStatus.value
      applyImageJobs(data?.image_jobs || [])
      if (data?.job?.prompt) slotPrompts[slot] = data.job.prompt
    } else {
      data = await listing1688ImagesSelect(workflowId.value, { slot })
      workflowStatus.value = data?.status || workflowStatus.value
      applyImageJobs(data?.image_jobs || [])
      if (data?.job?.prompt) slotPrompts[slot] = data.job.prompt
    }
  } catch (e) {
    stepError.value = mapErr(e)
    await refreshWorkflow().catch(() => {})
  } finally {
    imageBusy.value = false
  }
}

async function openLogin() {
  if (!workflowId.value || sessionBusy.value) return
  sessionBusy.value = true
  stepError.value = ''
  sessionOpenHint.value = t('listing1688Wizard.openLoginHint')
  try {
    const data = await listing1688SessionOpenLogin(workflowId.value)
    workflowStatus.value = data?.status || 'session_pending'
    const agentRaw = data?.agent
    const agent =
      agentRaw && typeof agentRaw === 'string'
        ? (() => {
            try {
              return JSON.parse(agentRaw)
            } catch {
              return null
            }
          })()
        : agentRaw && typeof agentRaw === 'object'
          ? agentRaw
          : data
    if (agent?.hint) sessionOpenHint.value = String(agent.hint)
    else sessionOpenHint.value = t('listing1688Wizard.openLoginHint')
  } catch (e) {
    stepError.value = mapErr(e)
  } finally {
    sessionBusy.value = false
  }
}

async function confirmLogin() {
  if (!workflowId.value || sessionBusy.value) return
  sessionBusy.value = true
  stepError.value = ''
  try {
    const data = await listing1688SessionConfirm(workflowId.value)
    workflowStatus.value = data?.status || 'session_valid'
    if (workflowStatus.value === 'session_valid') currentStep.value = 1
  } catch (e) {
    stepError.value = mapErr(e)
    await refreshWorkflow().catch(() => {})
  } finally {
    sessionBusy.value = false
  }
}

async function runCollect(isRetry) {
  if (!workflowId.value || collectBusy.value || !sessionValid.value) return
  collectBusy.value = true
  stepError.value = ''
  try {
    const fn = isRetry ? listing1688CollectRetry : listing1688Collect
    const data = await fn(workflowId.value, { url: offerUrl.value.trim() })
    workflowStatus.value = data?.status || 'collected'
    preview.value = data?.preview || null
    if (workflowStatus.value === 'collected') {
      currentStep.value = 2
      imageJobs.value = []
    }
  } catch (e) {
    stepError.value = mapErr(e)
    // 失败后 Server 回写 session_valid，刷新以便继续重试
    try {
      await refreshWorkflow()
      if (!['session_valid', 'collected', 'collecting', 'img_editing', 'img_ready'].includes(workflowStatus.value)) {
        workflowStatus.value = 'session_valid'
      }
    } catch (_) {
      workflowStatus.value = 'session_valid'
    }
  } finally {
    collectBusy.value = false
  }
}

async function loadAgents() {
  agentLoading.value = true
  agentError.value = ''
  try {
    const list = await getAgentList()
    agents.value = Array.isArray(list) ? list : Array.isArray(list?.data) ? list.data : []
  } catch (e) {
    agentError.value = e?.message || t('listing1688Wizard.loadAgentsFailed')
    agents.value = []
  } finally {
    agentLoading.value = false
  }
}

/** 按状态落到可继续的步骤（支持 ?id= / ?workflow_id= 恢复） */
function stepForStatus(st) {
  switch (st) {
    case 'collected':
    case 'img_editing':
      return 2
    case 'img_ready':
    case 'publishing':
    case 'published':
      return 3
    case 'session_valid':
    case 'collecting':
    case 'failed':
      return 1
    default:
      return 0
  }
}

async function resumeWorkflowFromQuery() {
  const raw = route.query.id || route.query.workflow_id
  const id = Number(raw)
  if (!Number.isFinite(id) || id <= 0) return
  workflowId.value = id
  try {
    await refreshWorkflow()
    if (!workflowStatus.value) {
      throw new Error('WORKFLOW_NOT_FOUND')
    }
    currentStep.value = stepForStatus(workflowStatus.value)
    stepError.value = ''
    createError.value = ''
  } catch (e) {
    const msg = mapErr(e) || t('listing1688Wizard.createFailed')
    stepError.value = msg
    createError.value = msg
    workflowId.value = null
  }
}

watch(
  () => [route.query.id, route.query.workflow_id],
  () => {
    resumeWorkflowFromQuery().catch(() => {})
  }
)

async function createWorkflow() {
  if (!selectedAgentId.value || creating.value) return
  creating.value = true
  createError.value = ''
  try {
    const data = await createListing1688Workflow(selectedAgentId.value)
    workflowId.value = data?.id
    workflowStatus.value = data?.status || 'draft'
    currentStep.value = 0
    preview.value = null
    imageJobs.value = []
    templateCandidates.value = []
    selectedTemplateOfferId.value = ''
    matchedCategoryId.value = ''
    similarPageUrl.value = ''
    categoryInspect.value = null
    publishDraft.value = null
    if (workflowId.value) {
      try {
        await refreshWorkflow()
      } catch (_) {}
    }
  } catch (e) {
    createError.value = mapErr(e) || t('listing1688Wizard.createFailed')
  } finally {
    creating.value = false
  }
}

watch(currentStep, (v) => {
  if (v === 2 && canEditImages.value) {
    refreshWorkflow().catch(() => {})
  }
})

onMounted(async () => {
  window.addEventListener('keydown', onLightboxKey)
  await loadAgents()
  await resumeWorkflowFromQuery()
})

onUnmounted(() => {
  window.removeEventListener('keydown', onLightboxKey)
  if (pickPulseTimer) window.clearTimeout(pickPulseTimer)
})
</script>

<style scoped>
.wizard1688 {
  --w-ink: #1a2332;
  --w-muted: #5c6b7a;
  --w-line: #d7dee7;
  --w-accent: #e36b2c;
  --w-panel: rgba(255, 252, 248, 0.92);
  position: relative;
  min-height: 100%;
  color: var(--w-ink);
}
.wizard1688__bg {
  position: absolute;
  inset: 0;
  background:
    radial-gradient(ellipse 80% 50% at 10% 0%, rgba(227, 107, 44, 0.12), transparent 55%),
    linear-gradient(165deg, #f7f3ee 0%, #eef2f6 45%, #f4efe8 100%);
  pointer-events: none;
}
.wizard1688__inner {
  position: relative;
  max-width: 880px;
  margin: 0 auto;
  padding: 28px 20px 64px;
}
.wizard1688__nav {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 16px;
}
.wizard1688__back {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: var(--w-muted);
  text-decoration: none;
  font-size: 14px;
}
.wizard1688__back--muted {
  opacity: 0.85;
}
.wizard1688__title {
  margin: 0 0 8px;
  font-size: 28px;
  font-weight: 700;
  letter-spacing: -0.02em;
}
.wizard1688__desc {
  margin: 0 0 28px;
  color: var(--w-muted);
  font-size: 15px;
  line-height: 1.5;
}
.wizard1688__steps {
  list-style: none;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 8px;
  padding: 0;
  margin: 0 0 20px;
}
.wizard1688__step {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  padding: 0;
  border: 1px solid var(--w-line);
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.55);
  overflow: hidden;
}
.wizard1688__step-btn {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 6px;
  width: 100%;
  padding: 12px;
  border: 0;
  background: transparent;
  color: inherit;
  text-align: left;
  cursor: default;
}
.wizard1688__step--clickable .wizard1688__step-btn {
  cursor: pointer;
}
.wizard1688__step--clickable .wizard1688__step-btn:hover {
  background: rgba(227, 107, 44, 0.06);
}
.wizard1688__step--clickable .wizard1688__step-btn:disabled {
  cursor: not-allowed;
}
.wizard1688__step--active {
  border-color: var(--w-accent);
  background: #fff;
  box-shadow: 0 0 0 1px rgba(227, 107, 44, 0.25);
}
.wizard1688__step-num {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 700;
  background: #e8edf2;
}
.wizard1688__step--active .wizard1688__step-num {
  background: var(--w-accent);
  color: #fff;
}
.wizard1688__step-label {
  font-size: 13px;
  font-weight: 600;
}
.wizard1688__panel {
  border: 1px solid var(--w-line);
  border-radius: 14px;
  padding: 22px;
  background: var(--w-panel);
}
.wizard1688__panel-title {
  margin: 0 0 8px;
  font-size: 18px;
}
.wizard1688__panel-hint {
  margin: 0 0 16px;
  color: var(--w-muted);
  font-size: 14px;
  line-height: 1.5;
}
.wizard1688__agents {
  list-style: none;
  margin: 0 0 16px;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.wizard1688__agent-btn {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 14px;
  border: 1px solid var(--w-line);
  border-radius: 10px;
  background: #fff;
  cursor: pointer;
  text-align: left;
}
.wizard1688__agent-btn--selected {
  border-color: var(--w-accent);
  box-shadow: inset 0 0 0 1px var(--w-accent);
}
.wizard1688__agent-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #9aa7b5;
}
.wizard1688__agent-dot--on {
  background: #2f9e64;
}
.wizard1688__agent-name {
  flex: 1;
  font-weight: 600;
}
.wizard1688__agent-status {
  font-size: 12px;
  color: var(--w-muted);
}
.wizard1688__actions {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  margin-top: 8px;
}
.wizard1688__btn {
  border: 1px solid var(--w-line);
  background: #fff;
  border-radius: 8px;
  padding: 10px 16px;
  font-size: 14px;
  cursor: pointer;
}
.wizard1688__btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
.wizard1688__btn--primary {
  background: var(--w-accent);
  border-color: var(--w-accent);
  color: #fff;
  font-weight: 600;
}
.wizard1688__state {
  margin: 8px 0;
  font-size: 14px;
  color: var(--w-muted);
}
.wizard1688__state--err {
  color: #b42318;
}
.wizard1688__meta {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 16px;
  font-size: 13px;
  color: var(--w-muted);
}
.wizard1688__m-note {
  margin: 12px 0 0;
  font-size: 13px;
  color: var(--w-muted);
}
.wizard1688__field {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 12px;
  font-size: 13px;
  color: var(--w-muted);
}
.wizard1688__input {
  border: 1px solid var(--w-line);
  border-radius: 8px;
  padding: 10px 12px;
  font-size: 14px;
  color: var(--w-ink);
  background: #fff;
}
.wizard1688__preview {
  margin-top: 16px;
  padding-top: 12px;
  border-top: 1px solid var(--w-line);
}
.wizard1688__preview h3 {
  margin: 0 0 8px;
  font-size: 16px;
}
.wizard1688__sub-title {
  margin: 18px 0 8px;
  font-size: 15px;
}
.wizard1688__templates {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 12px;
}
.wizard1688__template-card {
  border: 1px solid var(--w-line);
  border-radius: 12px;
  padding: 12px;
  background: #fff;
}
.wizard1688__template-card--selected {
  border-color: var(--w-accent);
  box-shadow: 0 0 0 1px rgba(227, 107, 44, 0.18);
}
.wizard1688__template-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.wizard1688__thumbs {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin: 10px 0;
}
.wizard1688__thumbs img {
  width: 72px;
  height: 72px;
  object-fit: cover;
  border-radius: 8px;
  border: 1px solid var(--w-line);
}
.wizard1688__slots {
  list-style: none;
  margin: 16px 0 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.wizard1688__slot {
  border: 1px solid var(--w-line);
  border-radius: 12px;
  padding: 14px;
  background: #fff;
}
.wizard1688__slot-head {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 10px;
}
.wizard1688__slot-pill {
  font-size: 12px;
  line-height: 1;
  padding: 6px 10px;
  border-radius: 999px;
  letter-spacing: 0.02em;
}
.wizard1688__slot-pill--ok {
  color: #0f6b4c;
  background: rgba(34, 160, 110, 0.12);
}
.wizard1688__pick-row {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 12px;
}
.wizard1688__pick {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0;
  padding: 10px;
  border: 2px solid var(--w-line);
  border-radius: 14px;
  background: #f7f9fb;
  cursor: pointer;
  text-align: left;
  color: inherit;
  transition:
    border-color 0.22s ease,
    background 0.22s ease,
    transform 0.22s ease,
    box-shadow 0.22s ease;
}
.wizard1688__pick:hover:not(.wizard1688__pick--disabled) {
  border-color: #b7c4d2;
  transform: translateY(-1px);
}
.wizard1688__pick--disabled {
  cursor: not-allowed;
  opacity: 0.72;
}
.wizard1688__pick--empty {
  background: #f3f5f7;
}
.wizard1688__pick--on {
  border-color: var(--w-accent);
  background: rgba(227, 107, 44, 0.08);
  box-shadow: 0 0 0 3px rgba(227, 107, 44, 0.16);
}
.wizard1688__pick--pulse {
  animation: wizard1688-pick-pulse 0.48s ease;
}
.wizard1688__pick-tag {
  font-size: 12px;
  font-weight: 600;
  color: var(--w-muted);
}
.wizard1688__pick--on .wizard1688__pick-tag {
  color: var(--w-accent);
}
.wizard1688__pick-frame {
  position: relative;
  display: block;
  width: 100%;
  aspect-ratio: 1;
  overflow: hidden;
  border-radius: 10px;
  background: #e8edf2;
}
.wizard1688__pick-frame img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: transform 0.28s ease;
}
.wizard1688__pick--on .wizard1688__pick-frame img {
  transform: scale(1.03);
}
.wizard1688__pick-placeholder {
  display: grid;
  place-items: center;
  width: 100%;
  height: 100%;
  padding: 12px;
  font-size: 12px;
  color: var(--w-muted);
  text-align: center;
}
.wizard1688__pick-check {
  position: absolute;
  right: 8px;
  bottom: 8px;
  width: 28px;
  height: 28px;
  display: grid;
  place-items: center;
  border-radius: 50%;
  color: #fff;
  background: var(--w-accent);
  box-shadow: 0 4px 12px rgba(227, 107, 44, 0.35);
  animation: wizard1688-check-pop 0.36s cubic-bezier(0.2, 0.9, 0.3, 1.35);
}
.wizard1688__pick-check :deep(svg) {
  width: 16px;
  height: 16px;
}
.wizard1688__pick-zoom {
  position: absolute;
  top: 10px;
  right: 10px;
  width: 30px;
  height: 30px;
  display: grid;
  place-items: center;
  border: 0;
  border-radius: 8px;
  color: #fff;
  background: rgba(26, 35, 50, 0.55);
  backdrop-filter: blur(4px);
  cursor: pointer;
  transition: background 0.18s ease, transform 0.18s ease;
}
.wizard1688__pick-zoom:hover {
  background: rgba(26, 35, 50, 0.78);
  transform: scale(1.06);
}
.wizard1688__pick-zoom :deep(svg) {
  width: 18px;
  height: 18px;
}
.wizard1688-lb {
  position: fixed;
  inset: 0;
  z-index: 12000;
  display: grid;
  place-items: center;
  padding: 24px;
  background: rgba(12, 18, 28, 0.72);
  backdrop-filter: blur(6px);
  animation: wizard1688-lb-in 0.2s ease;
}
.wizard1688-lb__close {
  position: absolute;
  top: 18px;
  right: 18px;
  width: 40px;
  height: 40px;
  display: grid;
  place-items: center;
  border: 0;
  border-radius: 999px;
  color: #fff;
  background: rgba(255, 255, 255, 0.14);
  cursor: pointer;
}
.wizard1688-lb__close :deep(svg) {
  width: 22px;
  height: 22px;
}
.wizard1688-lb__figure {
  margin: 0;
  max-width: min(920px, 96vw);
  max-height: 88vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
}
.wizard1688-lb__figure img {
  max-width: 100%;
  max-height: 80vh;
  object-fit: contain;
  border-radius: 12px;
  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.35);
  background: #111;
}
.wizard1688-lb__figure figcaption {
  color: rgba(255, 255, 255, 0.86);
  font-size: 13px;
}
@keyframes wizard1688-pick-pulse {
  0% {
    transform: scale(1);
  }
  40% {
    transform: scale(1.035);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes wizard1688-check-pop {
  0% {
    transform: scale(0.4);
    opacity: 0;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}
@keyframes wizard1688-lb-in {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@media (max-width: 720px) {
  .wizard1688__steps {
    grid-template-columns: 1fr 1fr;
  }
  .wizard1688__pick-row {
    grid-template-columns: 1fr;
  }
}
</style>
