package utils

import (
	"commander-agent-t260220/backend/internal/constants"
	"commander-agent-t260220/backend/internal/dispatcher"
	"commander-agent-t260220/backend/types"
	"context"
	"encoding/json"
	"net/url"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gorilla/websocket"
)

const (
	writeWait       = 10 * time.Second
	pongWait        = 60 * time.Second
	reconnectDelay  = 5 * time.Second
	reconnectFlap   = 10 * time.Second // 连接存活过短时的退避，避免同 ID 多连接互相踢下线
)

// 进程内串行拨号，避免同 Agent ID 并发建立多条 WebSocket
var wsDialMu sync.Mutex

// WsAgent WebSocket 客户端，负责与后端通信
type WsAgent struct {
	ws         *websocket.Conn
	connGen    uint64
	logger     *Logger
	ctx        context.Context
	cancel     context.CancelFunc
	config     *AgentConfig
	events     *Events
	sendChan   chan types.AgentMessage[any, any]
	dispatcher *dispatcher.Dispatcher
	startOnce  sync.Once
	mu         sync.Mutex
}

func NewWsAgent(logger *Logger, config *AgentConfig, events *Events, dispatcher *dispatcher.Dispatcher) *WsAgent {
	ctx, cancel := context.WithCancel(context.Background())
	return &WsAgent{
		logger:     logger,
		ctx:        ctx,
		cancel:     cancel,
		config:     config,
		events:     events,
		sendChan:   make(chan types.AgentMessage[any, any], 100),
		dispatcher: dispatcher,
	}
}

// Status 是否已连接
func (s *WsAgent) Status() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.ws != nil
}

// Start 启动连接循环（断线自动重连，仅启动一次）
func (s *WsAgent) Start() error {
	s.startOnce.Do(func() {
		go s.runLoop()
	})
	return nil
}

// Stop 停止连接循环并关闭底层连接。
func (s *WsAgent) Stop() {
	if s.cancel != nil {
		s.cancel()
	}
	s.closeConn()
}

// runLoop 主循环：连接 -> 读写 -> 断开 -> 退避重连
func (s *WsAgent) runLoop() {
	for {
		select {
		case <-s.ctx.Done():
			return
		default:
		}

		if err := s.connect(); err != nil {
			s.logger.Warn("WebSocket 连接失败: %v，%v 后重试", err, reconnectDelay)
			if !sleepOrDone(s.ctx, reconnectDelay) {
				return
			}
			continue
		}

		gen := atomic.LoadUint64(&s.connGen)
		connectedAt := time.Now()
		s.logger.Info("WebSocket 已连接服务器")

		done := make(chan struct{})
		go s.writeLoop(done, gen)
		s.readLoop(done, gen)

		s.closeConn(gen)
		lived := time.Since(connectedAt)
		delay := reconnectDelay
		if lived < 3*time.Second {
			s.logger.Warn("WebSocket 连接存活仅 %v，可能与其他实例冲突，%v 后重连", lived.Round(time.Millisecond), reconnectFlap)
			delay = reconnectFlap
		} else {
			s.logger.Warn("WebSocket 与服务器断开，%v 后重连", delay)
		}
		if !sleepOrDone(s.ctx, delay) {
			return
		}
	}
}

func sleepOrDone(ctx context.Context, d time.Duration) bool {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return false
	case <-t.C:
		return true
	}
}

// connect 建立 WebSocket 连接
func (s *WsAgent) connect() error {
	wsDialMu.Lock()
	defer wsDialMu.Unlock()

	select {
	case <-s.ctx.Done():
		return s.ctx.Err()
	default:
	}

	s.closeConn(0)

	cfg := s.config.GetConfig()
	u := url.URL{Scheme: constants.WsProtocol, Host: constants.WsServerAddress, Path: constants.WsServerPath}
	q := u.Query()
	q.Set("name", cfg.Agent.Name)
	q.Set("id", cfg.Agent.Id)
	u.RawQuery = q.Encode()

	conn, _, err := websocket.DefaultDialer.Dial(u.String(), nil)
	if err != nil {
		return err
	}

	gen := atomic.AddUint64(&s.connGen, 1)

	s.mu.Lock()
	s.ws = conn
	s.mu.Unlock()

	conn.SetPingHandler(func(msg string) error {
		if atomic.LoadUint64(&s.connGen) != gen {
			return websocket.ErrCloseSent
		}
		conn.SetReadDeadline(time.Now().Add(pongWait))
		return conn.WriteControl(websocket.PongMessage, []byte(msg), time.Now().Add(writeWait))
	})

	return nil
}

func (s *WsAgent) closeConn(expectedGen ...uint64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(expectedGen) > 0 && expectedGen[0] != 0 && atomic.LoadUint64(&s.connGen) != expectedGen[0] {
		return
	}
	if s.ws != nil {
		_ = s.ws.Close()
		s.ws = nil
	}
}

// readLoop 读取消息并调度，结果通过 sendChan 发送
func (s *WsAgent) readLoop(done chan struct{}, gen uint64) {
	defer close(done)

	s.mu.Lock()
	conn := s.ws
	s.mu.Unlock()
	if conn == nil || atomic.LoadUint64(&s.connGen) != gen {
		return
	}

	conn.SetReadDeadline(time.Now().Add(pongWait))
	conn.SetPongHandler(func(string) error {
		if atomic.LoadUint64(&s.connGen) != gen {
			return websocket.ErrCloseSent
		}
		conn.SetReadDeadline(time.Now().Add(pongWait))
		return nil
	})

	for {
		if atomic.LoadUint64(&s.connGen) != gen {
			return
		}

		var msg types.AgentMessage[any, any]
		if err := conn.ReadJSON(&msg); err != nil {
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
				s.logger.Error("WebSocket 读取异常: %v", err)
			}
			return
		}

		conn.SetReadDeadline(time.Now().Add(pongWait))
		s.events.EventDispatcher(msg)
		go s.handleMessage(msg)
	}
}

// handleMessage 调度并回写结果
func (s *WsAgent) handleMessage(msg types.AgentMessage[any, any]) {
	start := time.Now()
	s.logger.Info("开始处理任务: protocol=%s platform=%s task_id=%s agent_id=%s", msg.Protocol, msg.Platform, msg.TaskId, msg.AgentId)
	resp, err := s.dispatcher.Dispatch(msg)
	if err != nil {
		s.logger.Error("任务处理失败: protocol=%s task_id=%s err=%v elapsed=%v", msg.Protocol, msg.TaskId, err, time.Since(start).Round(time.Millisecond))
		msg.Receive = types.AgentTaskResponse{}.Error(err.Error())
		s.sendChan <- msg
		return
	}
	if resp == nil {
		s.logger.Error("任务处理失败: protocol=%s task_id=%s err=调度返回空响应 elapsed=%v", msg.Protocol, msg.TaskId, time.Since(start).Round(time.Millisecond))
		msg.Receive = types.AgentTaskResponse{}.Error("调度返回空响应")
		s.sendChan <- msg
		return
	}
	receiveJSON, _ := json.Marshal(resp.Receive)
	s.logger.Info("任务处理完成: protocol=%s task_id=%s elapsed=%v receive=%s", msg.Protocol, msg.TaskId, time.Since(start).Round(time.Millisecond), string(receiveJSON))
	s.sendChan <- *resp
}

// writeLoop 将 sendChan 中的消息写入服务端
func (s *WsAgent) writeLoop(done chan struct{}, gen uint64) {
	for {
		select {
		case <-done:
			return
		case <-s.ctx.Done():
			return
		case msg, ok := <-s.sendChan:
			if !ok {
				return
			}
			if atomic.LoadUint64(&s.connGen) != gen {
				return
			}
			s.mu.Lock()
			conn := s.ws
			s.mu.Unlock()
			if conn == nil {
				return
			}
			conn.SetWriteDeadline(time.Now().Add(writeWait))
			if err := conn.WriteJSON(msg); err != nil {
				s.logger.Error("WebSocket 写入失败: %v", err)
				return
			}
		}
	}
}
