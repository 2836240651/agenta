package alibaba

import (
	interfaces "commander-agent-t260220/backend/internal/Interfaces"
	"commander-agent-t260220/backend/internal/utils"
	"commander-agent-t260220/backend/types"
)

type AlibabaFactory struct {
	config   types.Config
	browser  *utils.Browser
	miaoshou *utils.RestyMiaoshou1688Utils
}

func NewAlibabaFactory(config types.Config, browser *utils.Browser) interfaces.PlatformInterface {
	return &AlibabaFactory{
		config:   config,
		browser:  browser,
		miaoshou: utils.NewRestyMiaoshou1688Utils(browser),
	}
}

func (f *AlibabaFactory) ProductIssuePrecheck(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	result := &utils.ProductIssuePrecheckResult{
		OK: true,
		Checks: []utils.PrecheckItem{{
			Key: "platform", Label: "平台预检", OK: true,
			Message: "1688 妙手导入预检：请确保 Agent 浏览器已登录 https://erp.91miaoshou.com",
		}},
	}
	if _, err := f.miaoshou.GetCurrentShopInfo(); err != nil {
		result.OK = false
		result.Checks[0].OK = false
		result.Checks[0].Message = "妙手 ERP 未登录或登录态失效"
	}
	return types.AgentTaskResponse{}.Success(result), nil
}

func (f *AlibabaFactory) CategoryList(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	return types.AgentTaskResponse{}.Error("1688类目列表暂未实现"), nil
}

func (f *AlibabaFactory) IsLogin() bool {
	_, err := f.miaoshou.GetCurrentShopInfo()
	return err == nil
}

func (f *AlibabaFactory) ProductList(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	return types.AgentTaskResponse{}.Error("1688商品列表暂未实现"), nil
}

func (f *AlibabaFactory) ShopList(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	return types.AgentTaskResponse{}.Error("1688店铺列表暂未实现"), nil
}
