package constants

const (
	ProtocolCategoryList         = "category_list"          // 店铺类目列表协议
	ProtocolShopList             = "shop_list"              // 店铺列表协议
	ProtocolProductIssue         = "product_issue"          // 产品发布协议
	ProtocolProductIssuePrecheck = "product_issue_precheck" // 产品发布预检
	ProtocolProductList          = "product_list"           // 商品列表协议

	ProtocolListing1688OpenLogin    = "listing1688_open_login"
	ProtocolListing1688ExportCookie = "listing1688_export_cookie"
	ProtocolListing1688Probe        = "listing1688_probe"
	ProtocolListing1688FetchOffer   = "listing1688_fetch_offer"

	ProtocolListing1688SellerOpenLogin          = "listing1688_seller_open_login"
	ProtocolListing1688SellerExportCookie       = "listing1688_seller_export_cookie"
	ProtocolListing1688SellerProbe              = "listing1688_seller_probe"
	ProtocolListing1688SellerPublish            = "listing1688_seller_publish"
	ProtocolListing1688SellerInspectCategory    = "listing1688_seller_inspect_category"
	ProtocolListing1688SellerSaveDraft          = "listing1688_seller_save_draft"
	ProtocolListing1688SellerListProducts       = "listing1688_seller_list_products"
	ProtocolListing1688SellerOpenSimilarPublish = "listing1688_seller_open_similar_publish"
)
