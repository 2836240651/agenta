package utils

import (
	"commander-agent-t260220/backend/internal/pkg"
	"context"
	"fmt"
	neturl "net/url"
	"strings"
	"sync"
	"time"

	"github.com/gen2brain/beeep"
	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/go-rod/rod/lib/proto"
)

// 浏览器结构体
type Browser struct {
	browser  *rod.Browser       // 浏览器实例
	launcher *launcher.Launcher // 浏览器启动器
	ctx      context.Context    // 上下文
	cancel   context.CancelFunc // 取消函数
	cfg      *AgentConfig       // 读取 Headless 等启动参数（可为 nil，按非无头处理）
	mu       sync.RWMutex       // 并发保护 browser/launcher/cancel 等字段
	initSeq  uint64             // 初始化代次，重启时递增以废弃旧 goroutine
}

func NewBrowser(cfg *AgentConfig) *Browser {
	return &Browser{
		browser:  nil,
		launcher: nil,
		ctx:      nil,
		cancel:   nil,
		cfg:      cfg,
	}
}

// 初始化启动浏览器
func (m *Browser) Init() {
	m.mu.Lock()
	m.initSeq++
	seq := m.initSeq
	m.mu.Unlock()

	go func() {
		headless := m.cfg != nil && m.cfg.GetConfig().Agent.Headless
		userDataDir := pkg.GetBrowserDir()
		cleanupStaleBrowserProfile(userDataDir)

		newLauncher := func() *launcher.Launcher {
			l := launcher.New().
				Leakless(false).
				UserDataDir(userDataDir).
				Set("disable-gpu"). // 增加稳定性
				Set("no-sandbox").  // Linux 环境必备
				Set("disable-dev-shm-usage").
				Set("disable-blink-features", "AutomationControlled") // 防检测
			if headless {
				return l.Headless(true)
			}
			return l.Headless(false).
				Set("window-size", "1280,720").
				Set("window-position", "100,80")
		}

		l := newLauncher()
		u, err := l.Launch()
		if err != nil && isBrowserProfileLocked(err) {
			cleanupStaleBrowserProfile(userDataDir)
			l = newLauncher()
			u, err = l.Launch()
		}
		if err != nil {
			fmt.Printf("启动浏览器失败: %v\n", err)
			_ = beeep.Alert("Agent", fmt.Sprintf("启动浏览器失败: %s\n\n程序将继续运行，可在设置中切换无头模式或检查杀毒软件是否拦截浏览器组件。", err.Error()), "")
			return
		}
		b := rod.New().ControlURL(u).MustConnect().NoDefaultDevice()

		m.mu.Lock()
		if seq != m.initSeq {
			m.mu.Unlock()
			_ = b.Close()
			l.Kill()
			return
		}
		m.launcher = l
		m.browser = b
		m.ctx, m.cancel = context.WithCancel(context.Background())
		m.mu.Unlock()

		urls := []string{
			"https://www.dianxiaomi.com",
			"https://work.1688.com",
			"https://sycm.1688.com/",
			"https://seller.kuajingmaihuo.com/login",
			"https://agentseller.temu.com/",
			"https://erp.91miaoshou.com",
			"https://www.yoto.work/",
		}

		for _, url := range urls {
			m.mu.RLock()
			if seq != m.initSeq || m.browser == nil {
				m.mu.RUnlock()
				return
			}
			current := m.browser
			m.mu.RUnlock()
			page := current.MustPage()
			page.Navigate(url)
		}

	}()
}

// 重启浏览器
func (m *Browser) Restart() {
	m.mu.Lock()
	m.initSeq++
	oldCancel := m.cancel
	oldBrowser := m.browser
	oldLauncher := m.launcher
	m.cancel = nil
	m.ctx = nil
	m.browser = nil
	m.launcher = nil
	m.mu.Unlock()

	if oldCancel != nil {
		oldCancel() // 先取消旧协程
	}
	if oldBrowser != nil {
		_ = oldBrowser.Close()
	}
	if oldLauncher != nil {
		oldLauncher.Kill()
	}
	time.Sleep(1 * time.Second)
	m.Init()
}

// Close 退出时关闭浏览器并杀死 Chromium 进程，避免残留僵尸进程影响下次启动。
func (m *Browser) Close() {
	m.mu.Lock()
	m.initSeq++ // 让 Init() 内的 goroutine 立刻失效并尽快退出
	oldCancel := m.cancel
	oldBrowser := m.browser
	oldLauncher := m.launcher
	m.cancel = nil
	m.ctx = nil
	m.browser = nil
	m.launcher = nil
	m.mu.Unlock()

	if oldCancel != nil {
		oldCancel()
	}
	if oldBrowser != nil {
		_ = oldBrowser.Close()
	}
	if oldLauncher != nil {
		oldLauncher.Kill()
	}
}

func (m *Browser) currentBrowser() *rod.Browser {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return m.browser
}

// RodBrowser 返回底层 rod 实例（向导 CDP 导航用）；未就绪时为 nil
func (m *Browser) RodBrowser() *rod.Browser {
	return m.currentBrowser()
}

// IsReady 浏览器进程是否已成功拉起
func (m *Browser) IsReady() bool {
	return m.currentBrowser() != nil
}

// GetCookiesByContext 按接口地址和页面上下文获取 Cookies 与店铺 ID。
// targetURL 是实际请求的接口地址，pageURL 是用于读取 localStorage 的页面地址。
func (m *Browser) GetCookiesByContext(targetURL string, pageURL string, localStorageKey string) (string, string, error) {
	browser := m.currentBrowser()
	if browser == nil {
		return "", "", fmt.Errorf("浏览器未就绪")
	}

	parsedTargetURL, err := neturl.Parse(targetURL)
	if err != nil || parsedTargetURL.Host == "" {
		return "", "", fmt.Errorf("无效的目标地址")
	}
	if pkg.TextIsEmpty(pageURL) {
		pageURL = targetURL
	}
	parsedPageURL, err := neturl.Parse(pageURL)
	if err != nil || parsedPageURL.Host == "" {
		return "", "", fmt.Errorf("无效的页面地址")
	}
	if pkg.TextIsEmpty(localStorageKey) {
		return "", "", fmt.Errorf("localStorage 键不能为空")
	}

	// 1. 尝试寻找已存在的页面
	pages, err := browser.Pages()
	if err != nil {
		return "", "", err
	}

	var targetPage *rod.Page
	for _, p := range pages {
		info, err := p.Info()
		if err != nil {
			continue
		}
		if strings.Contains(info.URL, parsedPageURL.Host) {
			targetPage = p
			break
		}
	}

	// 2. 如果没找到，则新建页面
	if targetPage == nil {
		targetPage = browser.MustPage(pageURL)
		// 建议加上超时控制
		err := rod.Try(func() {
			targetPage.MustWaitLoad()
		})
		if err != nil {
			targetPage.MustClose()
			return "", "", fmt.Errorf("页面加载超时: %v", err)
		}
	}

	// 3. 获取 Cookies
	// 注意：获取全量 Cookie 建议直接通过 Page 获取，或者指定根路径
	cookies, err := targetPage.Cookies([]string{targetURL})
	if err != nil {
		return "", "", err
	}

	var (
		cookiePairs []string
		shopId      string
	)
	for _, c := range cookies {
		cookiePairs = append(cookiePairs, fmt.Sprintf("%s=%s", c.Name, c.Value))
	}

	res, err := targetPage.Eval(fmt.Sprintf(`() => localStorage.getItem(%q)`, localStorageKey))
	if err != nil {
		return "", "", fmt.Errorf("获取店铺ID失败: %v", err)
	}

	shopId = strings.TrimSpace(res.Value.String())
	if shopId == "<nil>" || strings.EqualFold(shopId, "null") || strings.EqualFold(shopId, "undefined") {
		shopId = ""
	}
	if pkg.TextIsEmpty(shopId) {
		return "", "", fmt.Errorf("获取店铺ID失败, localStorage 键 %s 不存在", localStorageKey)
	}
	return strings.Join(cookiePairs, "; "), shopId, nil
}

// 获取指定域名的Cookies
func (m *Browser) GetCookiesByURL(targetURL string) (string, string, error) {
	parsedURL, err := neturl.Parse(targetURL)
	if err != nil || parsedURL.Host == "" {
		return "", "", fmt.Errorf("无效的目标地址")
	}

	localStorageKey := "agentseller-mall-info-id"
	switch parsedURL.Host {
	case "seller.kuajingmaihuo.com":
		localStorageKey = "mall-info-id"
	case "agentseller.temu.com":
		localStorageKey = "agentseller-mall-info-id"
	}

	return m.GetCookiesByContext(targetURL, targetURL, localStorageKey)
}

// 获取1688 Cookies
func (m *Browser) GetBy1688Cookies() (string, error) {
	browser := m.currentBrowser()
	if browser == nil {
		return "", fmt.Errorf("浏览器未初始化")
	}
	pages, err := browser.Pages()
	if err != nil {
		return "", err
	}
	var targetPage *rod.Page
	for _, p := range pages {
		if strings.Contains(p.MustInfo().URL, "work.1688.com") {
			targetPage = p
			break
		}
	}
	if targetPage == nil {
		targetPage = browser.MustPage("https://work.1688.com")
		defer targetPage.MustClose() // 函数结束立即关闭，防止堆积空页面
	}
	params := &proto.NetworkGetCookies{
		Urls: []string{"https://work.1688.com"},
	}
	result, err := params.Call(targetPage)
	if err != nil {
		return "", fmt.Errorf("获取 Cookies 失败: %v", err)
	}
	var cookiePairs []string
	for _, c := range result.Cookies {
		cookiePairs = append(cookiePairs, fmt.Sprintf("%s=%s", c.Name, c.Value))
	}
	return strings.Join(cookiePairs, "; "), nil
}

// GetBy1688SycmCookies 获取生意参谋（sycm.1688.com）请求所需的 Cookie。
// 与工作台 work.1688.com 不同，部分 Cookie（如 c_csrf、sycm_1688_version）只在访问生意参谋域名后才会下发，
// 因此不能复用 GetBy1688Cookies(work) 的取法；这里按 Chrome 对 https://sycm.1688.com 会携带的规则拉取。
func (m *Browser) GetBy1688SycmCookies() (string, error) {
	browser := m.currentBrowser()
	if browser == nil {
		return "", fmt.Errorf("浏览器未初始化")
	}
	pages, err := browser.Pages()
	if err != nil {
		return "", err
	}

	var cookiePage *rod.Page
	for _, p := range pages {
		info, err := p.Info()
		if err != nil {
			continue
		}
		if strings.Contains(info.URL, "sycm.1688.com") {
			cookiePage = p
			break
		}
	}
	if cookiePage == nil {
		cookiePage = browser.MustPage("https://sycm.1688.com/")
		defer cookiePage.MustClose()
		if err := rod.Try(func() {
			cookiePage.MustWaitLoad()
		}); err != nil {
			return "", fmt.Errorf("生意参谋页面加载超时: %v", err)
		}
	}

	// 合并 work / sycm 等域下会随请求带到 sycm 的 Cookie。仅拉 sycm 时，Rod 里若只开过工作台，
	// 部分登录态、_m_h5_tk 等可能只挂在 work.1688.com，导致裸请求能带全 Cookie、CDP 只取 sycm 则缺字段，
	// 接口仍 code=0 但 data 为空。
	merged := make(map[string]string)
	for _, u := range []string{"https://work.1688.com", "https://sycm.1688.com"} {
		res, err := (&proto.NetworkGetCookies{Urls: []string{u}}).Call(cookiePage)
		if err != nil {
			return "", fmt.Errorf("获取生意参谋 Cookies 失败: %v", err)
		}
		for _, c := range res.Cookies {
			merged[c.Name] = c.Value
		}
	}
	if len(merged) == 0 {
		return "", fmt.Errorf("生意参谋 Cookie 为空，请在浏览器中登录 1688 并打开 https://sycm.1688.com/")
	}
	pairs := make([]string, 0, len(merged))
	for n, v := range merged {
		pairs = append(pairs, fmt.Sprintf("%s=%s", n, v))
	}
	return strings.Join(pairs, "; "), nil
}
