/** AC-08 / TC-X-01：递归剥离对象中的 cookie 明文键（大小写不敏感）。 */

export function stripCookieKeys(value) {
  if (Array.isArray(value)) {
    return value.map(stripCookieKeys)
  }
  if (value && typeof value === 'object') {
    const out = {}
    for (const [k, v] of Object.entries(value)) {
      if (String(k).toLowerCase() === 'cookie') {
        continue
      }
      out[k] = stripCookieKeys(v)
    }
    return out
  }
  return value
}
