package alibaba

import (
	"commander-agent-t260220/backend/types"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/proto"
)

// Listing1688SellerOpenLogin 仅在 Agent Chrome 内打开/复用商家工作台，不关页。
func (f *AlibabaFactory) Listing1688SellerOpenLogin(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	_ = payload
	if f.browser == nil || !f.browser.IsReady() {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未就绪"), nil
	}
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未初始化"), nil
	}
	page, reused := listing1688AcquireSellerPage(rodBrowser)
	if page == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 无法打开 Agent 浏览器页"), nil
	}
	target := listing1688SellerPublishEntryURL
	if err := rod.Try(func() {
		page.MustNavigate(listing1688SellerPublishEntryURL)
		page.MustWaitLoad()
	}); err != nil {
		return types.AgentTaskResponse{}.Error("SELLER_SESSION_INVALID: 打开商家工作台失败: " + err.Error()), nil
	}
	time.Sleep(600 * time.Millisecond)
	info, _ := page.Info()
	finalURL := listing1688SellerPublishEntryURL
	if info != nil && info.URL != "" {
		finalURL = info.URL
	}
	html, _ := page.HTML()
	needLogin := listing1688SellerLooksLoggedOut(finalURL, html) || !listing1688SellerLooksLikeWorkbench(html, finalURL)
	if needLogin {
		target = listing1688SellerLoginURL
		if err := rod.Try(func() {
			page.MustNavigate(listing1688SellerLoginURL)
			page.MustWaitLoad()
		}); err != nil {
			return types.AgentTaskResponse{}.Error("SELLER_SESSION_INVALID: 打开商家登录页失败: " + err.Error()), nil
		}
		if info2, _ := page.Info(); info2 != nil && info2.URL != "" {
			finalURL = info2.URL
		}
	}
	listing1688ActivatePage(page)
	hint := "请在 Agent 弹出的 Chrome 登录商家中心（work.1688.com），不要用本机主浏览器"
	if !needLogin {
		hint = "Agent 浏览器已打开商家工作台，可点「我已登录商家中心」校验"
	}
	return types.AgentTaskResponse{}.Success(map[string]any{
		"login_urls": []string{target},
		"opened":     true,
		"reused":     reused,
		"need_login": needLogin,
		"url":        finalURL,
		"hint":       hint,
		"open_in":    "agent_chrome",
	}), nil
}

func listing1688AcquireSellerPage(b *rod.Browser) (*rod.Page, bool) {
	if pages, err := b.Pages(); err == nil {
		for _, p := range pages {
			info, ierr := p.Info()
			if ierr != nil || info == nil {
				continue
			}
			u := strings.ToLower(info.URL)
			if strings.Contains(u, "sellerpro/") || strings.Contains(u, "sellerbasenew/") || strings.Contains(u, "login.1688.com") {
				return p, true
			}
		}
	}
	return b.MustPage("about:blank"), false
}

// Listing1688SellerExportCookie 导出商家工作台相关 Cookie（明文仅 SyncSend 一次）
func (f *AlibabaFactory) Listing1688SellerExportCookie(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	_ = payload
	cookie, err := f.exportSeller1688Cookies()
	if err != nil {
		return types.AgentTaskResponse{}.Error("SELLER_SESSION_INVALID: " + err.Error()), nil
	}
	if strings.TrimSpace(cookie) == "" {
		return types.AgentTaskResponse{}.Error("SELLER_SESSION_INVALID: Cookie 为空，请先在 Agent 浏览器登录商家中心"), nil
	}
	return types.AgentTaskResponse{}.Success(map[string]any{"cookie": cookie}), nil
}

// Listing1688SellerProbe 用 Agent 浏览器打开工作台校验登录态（与发品同一 Profile，不用纯 Header 冒充）
func (f *AlibabaFactory) Listing1688SellerProbe(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	_ = payload
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未初始化"), nil
	}
	page := rodBrowser.MustPage(listing1688SellerPublishEntryURL)
	defer func() { _ = page.Close() }()
	if err := rod.Try(func() { page.MustWaitLoad() }); err != nil {
		return types.AgentTaskResponse{}.Error("SELLER_SESSION_INVALID: 打开工作台失败: " + err.Error()), nil
	}
	time.Sleep(800 * time.Millisecond)
	info, _ := page.Info()
	finalURL := ""
	if info != nil {
		finalURL = info.URL
	}
	html, _ := page.HTML()
	if listing1688SellerLooksLoggedOut(finalURL, html) {
		return types.AgentTaskResponse{}.Error("SELLER_SESSION_INVALID: 商家中心未登录或已失效（请在 Agent 浏览器登录 work.1688.com）"), nil
	}
	if listing1688SellerLooksAccountIneligible(finalURL, html) {
		return types.AgentTaskResponse{}.Error("SELLER_ACCOUNT_INELIGIBLE: 当前账号未开通 1688 企业商家店铺，请登录已开通店铺的企业账号"), nil
	}
	// 需看到商家工作台特征，避免买家 Cookie「半登录」误过
	if !listing1688SellerLooksLikeWorkbench(html, finalURL) {
		return types.AgentTaskResponse{}.Error("SELLER_SESSION_INVALID: 未识别到商家工作台（可能是买家账号或未入驻）"), nil
	}
	return types.AgentTaskResponse{}.Success(map[string]any{
		"ok":      true,
		"code":    0,
		"message": "browser workbench session ok",
		"url":     finalURL,
	}), nil
}

func listing1688SellerLooksLoggedOut(url, html string) bool {
	u := strings.ToLower(url)
	_ = html
	return strings.Contains(u, "login.1688.com") || strings.Contains(u, "member/signin")
}

func listing1688SellerLooksAccountIneligible(url, html string) bool {
	u := strings.ToLower(url)
	h := strings.ToLower(html)
	if strings.Contains(u, "cxt.1688.com") {
		return true
	}
	markers := []string{"个人账号", "商家自助开店", "只有1688企业账号", "注册店铺账号"}
	for _, marker := range markers {
		if strings.Contains(h, strings.ToLower(marker)) {
			return true
		}
	}
	return false
}

func listing1688SellerLooksLikeWorkbench(html, url string) bool {
	u := strings.ToLower(url)
	h := strings.ToLower(html)
	if strings.Contains(u, "work.1688.com") && !strings.Contains(u, "login") && (strings.Contains(u, "sellerpro/") || strings.Contains(u, "sellerbasenew/")) {
		// 工作台常见文案/导航
		markers := []string{"发布商品", "发布供应产品", "商品管理", "产品管理"}
		for _, m := range markers {
			if strings.Contains(h, strings.ToLower(m)) || strings.Contains(h, m) {
				return true
			}
		}
	}
	return false
}

func (f *AlibabaFactory) Listing1688SellerInspectCategory(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	var body struct {
		CategoryID string `json:"category_id"`
	}
	raw, _ := json.Marshal(payload.Send)
	_ = json.Unmarshal(raw, &body)
	categoryID := strings.TrimSpace(body.CategoryID)
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未初始化"), nil
	}
	page, url := listing1688SellerFindOpenCategoryForm(rodBrowser, categoryID)
	if page == nil {
		return types.AgentTaskResponse{}.Error("CATEGORY_FORM_NOT_OPEN: 请先在 Agent 浏览器打开目标类目的 offer-new 发品页"), nil
	}
	pageText := ""
	if bodyElement, err := page.Element("body"); err == nil && bodyElement != nil {
		pageText, _ = bodyElement.Text()
	}
	if strings.TrimSpace(pageText) == "" {
		return types.AgentTaskResponse{}.Error("CATEGORY_FORM_NOT_OPEN: 无法读取发品页表单"), nil
	}
	return types.AgentTaskResponse{}.Success(map[string]any{
		"category_id":       categoryID,
		"page_url":          url,
		"required_fields":   listing1688SellerRequiredFieldsFromPageText(pageText),
		"validation_errors": listing1688SellerValidationErrorsFromPageText(pageText),
		"save_draft_ready":  strings.Contains(pageText, "保存草稿"),
		"submit_ready":      strings.Contains(pageText, "我要发布"),
		"field_bindings":    listing1688SellerVerifiedBindings(),
	}), nil
}

func listing1688SellerFindOpenCategoryForm(browser *rod.Browser, categoryID string) (*rod.Page, string) {
	pages, err := browser.Pages()
	if err != nil {
		return nil, ""
	}
	for _, page := range pages {
		info, infoErr := page.Info()
		if infoErr != nil || info == nil {
			continue
		}
		url := info.URL
		if !strings.Contains(url, "offer-new.1688.com/popular/publish.htm") {
			continue
		}
		if categoryID != "" && !strings.Contains(url, "catId="+categoryID) {
			continue
		}
		return page, url
	}
	return nil, ""
}

func listing1688SellerRequiredFieldsFromPageText(pageText string) []string {
	out := make([]string, 0)
	seen := make(map[string]struct{})
	for _, line := range strings.Split(pageText, "\n") {
		raw := strings.TrimSpace(line)
		field := strings.TrimSpace(strings.TrimLeft(raw, "*＊"))
		if field == "" || (!strings.HasPrefix(raw, "*") && !strings.HasPrefix(raw, "＊")) {
			continue
		}
		if _, ok := seen[field]; ok {
			continue
		}
		seen[field] = struct{}{}
		out = append(out, field)
	}
	return out
}

func listing1688SellerValidationErrorsFromPageText(pageText string) []string {
	out := make([]string, 0)
	seen := make(map[string]struct{})
	for _, line := range strings.Split(pageText, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || (!strings.Contains(line, "必填") && !strings.Contains(line, "不能为空") && !strings.Contains(line, "请填写")) {
			continue
		}
		if _, ok := seen[line]; ok {
			continue
		}
		seen[line] = struct{}{}
		out = append(out, line)
	}
	return out
}

type listing1688SellerTemplateProduct struct {
	OfferID   string   `json:"offer_id"`
	Title     string   `json:"title"`
	PriceText string   `json:"price_text,omitempty"`
	PriceMin  *float64 `json:"price_min,omitempty"`
	PriceMax  *float64 `json:"price_max,omitempty"`
}

func (f *AlibabaFactory) Listing1688SellerListProducts(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	var body struct {
		Limit int `json:"limit"`
	}
	raw, _ := json.Marshal(payload.Send)
	_ = json.Unmarshal(raw, &body)
	limit := body.Limit
	if limit <= 0 || limit > 200 {
		limit = 120
	}
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未初始化"), nil
	}
	page, url, err := listing1688SellerEnsureManagePage(rodBrowser)
	if err != nil {
		return types.AgentTaskResponse{}.Error("SELLER_SESSION_INVALID: " + err.Error()), nil
	}
	pageText := ""
	if bodyElement, err := page.Element("body"); err == nil && bodyElement != nil {
		pageText, _ = bodyElement.Text()
	}
	products := listing1688SellerParseManageProducts(pageText, limit)
	if len(products) == 0 {
		return types.AgentTaskResponse{}.Error("PUBLISH_FAILED: 未在商品管理页解析到商品候选"), nil
	}
	return types.AgentTaskResponse{}.Success(map[string]any{
		"page_url": url,
		"products": products,
	}), nil
}

func (f *AlibabaFactory) Listing1688SellerOpenSimilarPublish(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	var body struct {
		OfferID string `json:"offer_id"`
	}
	raw, _ := json.Marshal(payload.Send)
	_ = json.Unmarshal(raw, &body)
	offerID := strings.TrimSpace(body.OfferID)
	if offerID == "" {
		return types.AgentTaskResponse{}.Error("PUBLISH_FAILED: offer_id is required"), nil
	}
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未初始化"), nil
	}
	page, _, err := listing1688SellerEnsureManagePage(rodBrowser)
	if err != nil {
		return types.AgentTaskResponse{}.Error("SELLER_SESSION_INVALID: " + err.Error()), nil
	}
	clicked, clickErr := listing1688SellerClickSimilarByOfferID(page, offerID)
	if !clicked {
		msg := "未找到对应商品的发布相似品入口"
		if clickErr != nil {
			msg += ": " + clickErr.Error()
		}
		return types.AgentTaskResponse{}.Error("PUBLISH_FAILED: " + msg), nil
	}
	time.Sleep(1800 * time.Millisecond)
	_ = rod.Try(func() { page.MustWaitLoad() })
	info, _ := page.Info()
	finalURL := ""
	if info != nil {
		finalURL = info.URL
	}
	categoryID := listing1688SellerExtractCategoryID(finalURL)
	if categoryID == "" {
		html, _ := page.HTML()
		categoryID = listing1688SellerExtractCategoryID(html)
	}
	if categoryID == "" {
		return types.AgentTaskResponse{}.Error("PUBLISH_FAILED: 已打开相似品页但未解析到 catId"), nil
	}
	return types.AgentTaskResponse{}.Success(map[string]any{
		"offer_id":    offerID,
		"category_id": categoryID,
		"page_url":    finalURL,
	}), nil
}

func listing1688SellerEnsureManagePage(browser *rod.Browser) (*rod.Page, string, error) {
	page, reused := listing1688AcquireSellerPage(browser)
	if page == nil {
		return nil, "", fmt.Errorf("无法打开 Agent 浏览器页")
	}
	if !reused {
		page = browser.MustPage("about:blank")
	}
	info, _ := page.Info()
	cur := ""
	if info != nil {
		cur = info.URL
	}
	if strings.Contains(cur, "offer-new.1688.com") {
		return page, cur, nil
	}
	if strings.Contains(cur, "offer_manage") || strings.Contains(cur, "商品管理") {
		_ = rod.Try(func() { page.MustWaitLoad() })
		return page, cur, nil
	}
	if err := rod.Try(func() {
		page.MustNavigate(listing1688SellerWorkbenchURL)
		page.MustWaitLoad()
	}); err != nil {
		return nil, "", fmt.Errorf("打开商家工作台失败: %w", err)
	}
	time.Sleep(1200 * time.Millisecond)
	info, _ = page.Info()
	cur = ""
	if info != nil {
		cur = info.URL
	}
	html, _ := page.HTML()
	if listing1688SellerLooksLoggedOut(cur, html) {
		return nil, "", fmt.Errorf("商家中心未登录或已失效")
	}
	if !listing1688SellerOpenManageFromWorkbench(page) {
		_ = rod.Try(func() {
			page.MustNavigate(listing1688SellerManageURL)
			page.MustWaitLoad()
		})
	}
	time.Sleep(1500 * time.Millisecond)
	info, _ = page.Info()
	cur = ""
	if info != nil {
		cur = info.URL
	}
	return page, cur, nil
}

func listing1688SellerOpenManageFromWorkbench(page *rod.Page) bool {
	for _, pair := range listing1688SellerManageClickPairs {
		el, err := page.Timeout(2*time.Second).ElementR(pair[0], pair[1])
		if err != nil || el == nil {
			continue
		}
		_ = el.Click(proto.InputMouseButtonLeft, 1)
		_ = rod.Try(func() { page.MustWaitLoad() })
		return true
	}
	return false
}

var listing1688ManagePriceRe = regexp.MustCompile(`(\d+(?:\.\d+)?)\s*(?:~\s*(\d+(?:\.\d+)?))?`)

func listing1688SellerParseManageProducts(pageText string, limit int) []listing1688SellerTemplateProduct {
	lines := strings.Split(pageText, "\n")
	out := make([]listing1688SellerTemplateProduct, 0)
	seen := make(map[string]struct{})
	for i := 0; i < len(lines); i++ {
		line := strings.TrimSpace(lines[i])
		if !strings.HasPrefix(line, "[ID]") {
			continue
		}
		offerID := strings.TrimSpace(strings.TrimPrefix(line, "[ID]"))
		if offerID == "" {
			continue
		}
		if _, ok := seen[offerID]; ok {
			continue
		}
		title := ""
		for j := i - 1; j >= 0 && j >= i-6; j-- {
			candidate := strings.TrimSpace(lines[j])
			if candidate == "" || strings.HasPrefix(candidate, "[货号]") || strings.HasPrefix(candidate, "[ID]") {
				continue
			}
			title = candidate
			break
		}
		if title == "" {
			continue
		}
		priceText := ""
		for j := i + 1; j < len(lines) && j <= i+8; j++ {
			candidate := strings.TrimSpace(lines[j])
			if candidate == "" || strings.Contains(candidate, "年销") || strings.Contains(candidate, "混批") {
				continue
			}
			if listing1688ManagePriceRe.MatchString(candidate) {
				priceText = candidate
				break
			}
		}
		pMin, pMax := listing1688ParsePriceRange(priceText)
		out = append(out, listing1688SellerTemplateProduct{
			OfferID:   offerID,
			Title:     title,
			PriceText: priceText,
			PriceMin:  pMin,
			PriceMax:  pMax,
		})
		seen[offerID] = struct{}{}
		if len(out) >= limit {
			break
		}
	}
	return out
}

func listing1688ParsePriceRange(text string) (*float64, *float64) {
	m := listing1688ManagePriceRe.FindStringSubmatch(strings.TrimSpace(text))
	if len(m) < 2 {
		return nil, nil
	}
	min, err := strconv.ParseFloat(strings.TrimSpace(m[1]), 64)
	if err != nil {
		return nil, nil
	}
	minVal := min
	if len(m) > 2 && strings.TrimSpace(m[2]) != "" {
		max, err := strconv.ParseFloat(strings.TrimSpace(m[2]), 64)
		if err == nil {
			maxVal := max
			return &minVal, &maxVal
		}
	}
	return &minVal, &minVal
}

func listing1688SellerClickSimilarByOfferID(page *rod.Page, offerID string) (bool, error) {
	js := fmt.Sprintf(`() => {
	  const offerId = %q;
	  const hasText = (el, text) => !!el && String(el.innerText || el.textContent || '').includes(text);
	  const clickableIn = (root) => {
	    if (!root) return null;
	    const selectors = ['button','a','span','div'];
	    for (const sel of selectors) {
	      const list = root.querySelectorAll(sel);
	      for (const el of list) {
	        if (hasText(el, '发布相似品')) return el;
	      }
	    }
	    return null;
	  };
	  const all = Array.from(document.querySelectorAll('body *'));
	  const hits = all.filter((el) => {
	    const text = String(el.innerText || el.textContent || '').trim();
	    return text.includes(offerId) && text.length > 0 && text.length < 1200;
	  });
	  hits.sort((a, b) => (a.innerText || '').length - (b.innerText || '').length);
	  for (const base of hits) {
	    let cur = base;
	    for (let i = 0; i < 6 && cur; i++, cur = cur.parentElement) {
	      const btn = clickableIn(cur);
	      if (btn) {
	        btn.click();
	        return true;
	      }
	    }
	  }
	  return false;
	}`, offerID)
	result, err := page.Eval(js)
	if err != nil || result == nil {
		return false, err
	}
	return result.Value.Bool(), nil
}

func listing1688SellerExtractCategoryID(text string) string {
	m := regexp.MustCompile(`catId=(\d+)`).FindStringSubmatch(text)
	if len(m) > 1 {
		return strings.TrimSpace(m[1])
	}
	return ""
}

func (f *AlibabaFactory) Listing1688SellerSaveDraft(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	var body struct {
		CategoryID       string         `json:"category_id"`
		ConfirmSaveDraft bool           `json:"confirm_save_draft"`
		Title            string         `json:"title"`
		Images           []string       `json:"images"`
		PublishForm      map[string]any `json:"publish_form"`
	}
	raw, _ := json.Marshal(payload.Send)
	_ = json.Unmarshal(raw, &body)
	if !body.ConfirmSaveDraft {
		return types.AgentTaskResponse{}.Error("DRAFT_SAVE_CONFIRM_REQUIRED: confirm_save_draft must be true"), nil
	}
	title, images := listing1688SellerResolvePublishTitleImages(body.Title, body.Images, body.PublishForm)
	if title == "" {
		return types.AgentTaskResponse{}.Error("DRAFT_CONTENT_MISSING: 标题为空"), nil
	}
	if len(images) < 1 {
		return types.AgentTaskResponse{}.Error("DRAFT_CONTENT_MISSING: 无选定图片"), nil
	}
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未初始化"), nil
	}
	page, url := listing1688SellerFindOpenCategoryForm(rodBrowser, strings.TrimSpace(body.CategoryID))
	if page == nil {
		return types.AgentTaskResponse{}.Error("CATEGORY_FORM_NOT_OPEN: 请先在 Agent 浏览器打开目标类目的 offer-new 发品页"), nil
	}
	if !listing1688SellerFillTitle(page, title) {
		return types.AgentTaskResponse{}.Error("DRAFT_CONTENT_MISSING: 未能填写标题"), nil
	}
	imagesSet, imgErr := listing1688SellerUploadImages(page, images)
	if imagesSet < 1 {
		msg := "DRAFT_CONTENT_MISSING: 未能上传选定图片"
		if imgErr != nil {
			msg += ": " + imgErr.Error()
		}
		return types.AgentTaskResponse{}.Error(msg), nil
	}
	if !listing1688SellerClickSaveDraft(page) {
		return types.AgentTaskResponse{}.Error("DRAFT_SAVE_UNAVAILABLE: 未找到保存草稿按钮"), nil
	}
	time.Sleep(1200 * time.Millisecond)
	pageText := ""
	if bodyElement, err := page.Element("body"); err == nil && bodyElement != nil {
		pageText, _ = bodyElement.Text()
	}
	validationErrors := listing1688SellerValidationErrorsFromPageText(pageText)
	if len(validationErrors) > 0 {
		return types.AgentTaskResponse{}.Error("DRAFT_VALIDATION_FAILED: " + strings.Join(validationErrors, "；")), nil
	}
	if !listing1688SellerDraftSaveConfirmed(pageText) {
		return types.AgentTaskResponse{}.Error("DRAFT_SAVE_UNCONFIRMED: 保存后未检测到草稿成功提示"), nil
	}
	return types.AgentTaskResponse{}.Success(map[string]any{
		"draft_saved":       true,
		"validation_errors": []string{},
		"page_url":          url,
		"title_filled":      true,
		"images_set":        imagesSet,
	}), nil
}

func listing1688SellerResolvePublishTitleImages(title string, images []string, form map[string]any) (string, []string) {
	title = strings.TrimSpace(title)
	outImages := make([]string, 0)
	for _, u := range images {
		if u = strings.TrimSpace(u); u != "" {
			outImages = append(outImages, u)
		}
	}
	if form != nil {
		if title == "" {
			if t, ok := form["title"].(string); ok {
				title = strings.TrimSpace(t)
			}
		}
		if len(outImages) == 0 {
			switch typed := form["images"].(type) {
			case []string:
				for _, u := range typed {
					if u = strings.TrimSpace(u); u != "" {
						outImages = append(outImages, u)
					}
				}
			case []any:
				for _, item := range typed {
					if u, ok := item.(string); ok {
						if u = strings.TrimSpace(u); u != "" {
							outImages = append(outImages, u)
						}
					}
				}
			}
		}
	}
	return title, outImages
}

func listing1688SellerClickSaveDraft(page *rod.Page) bool {
	for _, pair := range [][2]string{{"button", "保存草稿"}, {"span", "保存草稿"}} {
		el, err := page.Timeout(2*time.Second).ElementR(pair[0], pair[1])
		if err != nil || el == nil {
			continue
		}
		_ = el.Click(proto.InputMouseButtonLeft, 1)
		return true
	}
	return false
}

func listing1688SellerDraftSaveConfirmed(pageText string) bool {
	return strings.Contains(pageText, "草稿保存成功") || strings.Contains(pageText, "保存草稿成功") || strings.Contains(pageText, "已保存到草稿箱")
}

// Listing1688SellerPublish 商家后台发品：仅在 draft_verified 后，对已打开的 offer-new 页点最终发布
func (f *AlibabaFactory) Listing1688SellerPublish(payload types.AgentMessage[any, any]) (types.AgentTaskResponse, error) {
	raw, _ := json.Marshal(payload.Send)
	var body struct {
		Title         string         `json:"title"`
		Images        []string       `json:"images"`
		CategoryID    string         `json:"category_id"`
		DraftVerified bool           `json:"draft_verified"`
		PublishForm   map[string]any `json:"publish_form"`
	}
	_ = json.Unmarshal(raw, &body)
	if !body.DraftVerified {
		return types.AgentTaskResponse{}.Error("DRAFT_NOT_VERIFIED: 请先完成类目表单校验并保存草稿"), nil
	}
	title, images := listing1688SellerResolvePublishTitleImages(body.Title, body.Images, body.PublishForm)
	if title == "" || len(images) < 1 {
		return types.AgentTaskResponse{}.Error("DRAFT_CONTENT_MISSING: 发布载荷缺少标题或图片"), nil
	}
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return types.AgentTaskResponse{}.Error("AGENT_OFFLINE: 浏览器未初始化"), nil
	}
	page, cur := listing1688SellerFindOpenCategoryForm(rodBrowser, strings.TrimSpace(body.CategoryID))
	if page == nil {
		return types.AgentTaskResponse{}.Error("CATEGORY_FORM_NOT_OPEN: 请先在 Agent 浏览器打开已保存草稿的 offer-new 发品页"), nil
	}
	html0, _ := page.HTML()
	if listing1688SellerLooksLoggedOut(cur, html0) {
		return types.AgentTaskResponse{}.Error("SELLER_SESSION_INVALID: 请先在 Agent 浏览器登录商家中心"), nil
	}

	submitted := listing1688SellerClickSubmit(page)
	time.Sleep(1500 * time.Millisecond)
	html, _ := page.HTML()
	info2, _ := page.Info()
	finalURL := cur
	if info2 != nil && info2.URL != "" {
		finalURL = info2.URL
	}
	if strings.Contains(html, "验证码") || strings.Contains(finalURL, "captcha") {
		return types.AgentTaskResponse{}.Error("PUBLISH_FAILED: 发品遇到验证码，请在 Agent 浏览器处理后重试"), nil
	}
	if !submitted {
		return types.AgentTaskResponse{}.Error("PUBLISH_FAILED: 未能点击提交/发布"), nil
	}

	offerID := listing1688SellerExtractOfferID(finalURL, html)
	platformStatus := listing1688SellerPlatformStatus(html)
	okHint := offerID != "" && platformStatus != ""
	if !okHint {
		return types.AgentTaskResponse{}.Error("PUBLISH_FAILED: 已提交但未检测到发布成功/审核态（请人工确认后重试或更新选择器）"), nil
	}

	return types.AgentTaskResponse{}.Success(map[string]any{
		"ok":              true,
		"offer_id":        offerID,
		"platform_status": platformStatus,
		"message":         "商家发品自动化成功",
		"clicked_entry":   false,
		"title_filled":    true,
		"images_set":      len(images),
		"price_filled":    false,
		"sku_filled":      false,
		"submitted":       submitted,
		"final_url":       finalURL,
		"success_hint":    true,
		"draft_verified":  true,
	}), nil
}

func listing1688SellerClickEntry(page *rod.Page) bool {
	for _, pair := range listing1688SellerEntryClickPairs {
		el, err := page.Timeout(2*time.Second).ElementR(pair[0], pair[1])
		if err != nil || el == nil {
			continue
		}
		_ = el.Click(proto.InputMouseButtonLeft, 1)
		_ = rod.Try(func() { page.MustWaitLoad() })
		time.Sleep(800 * time.Millisecond)
		return true
	}
	for _, sel := range listing1688SellerEntryHrefSelectors {
		el, err := page.Timeout(2 * time.Second).Element(sel)
		if err != nil || el == nil {
			continue
		}
		_ = el.Click(proto.InputMouseButtonLeft, 1)
		_ = rod.Try(func() { page.MustWaitLoad() })
		time.Sleep(800 * time.Millisecond)
		return true
	}
	return false
}

func listing1688SellerFillTitle(page *rod.Page, title string) bool {
	for _, sel := range listing1688SellerTitleSelectors {
		el, err := page.Timeout(2 * time.Second).Element(sel)
		if err != nil || el == nil {
			continue
		}
		_ = el.SelectAllText()
		_ = el.Input(title)
		return true
	}
	return false
}

func listing1688SellerClickSubmit(page *rod.Page) bool {
	for _, pair := range listing1688SellerSubmitPairs {
		el, err := page.Timeout(2*time.Second).ElementR(pair[0], pair[1])
		if err != nil || el == nil {
			continue
		}
		_ = el.Click(proto.InputMouseButtonLeft, 1)
		time.Sleep(1200 * time.Millisecond)
		return true
	}
	el, err := page.Timeout(2 * time.Second).Element(`button[type="submit"]`)
	if err == nil && el != nil {
		_ = el.Click(proto.InputMouseButtonLeft, 1)
		time.Sleep(1200 * time.Millisecond)
		return true
	}
	return false
}

func listing1688SellerUploadImages(page *rod.Page, urls []string) (int, error) {
	paths := make([]string, 0, len(urls))
	tmpdir, err := os.MkdirTemp("", "listing1688-seller-img-*")
	if err != nil {
		return 0, err
	}
	defer func() { _ = os.RemoveAll(tmpdir) }()

	for i, u := range urls {
		u = strings.TrimSpace(u)
		if u == "" {
			continue
		}
		p, err := listing1688DownloadToFile(tmpdir, i, u)
		if err != nil {
			continue
		}
		paths = append(paths, p)
		if len(paths) >= 10 {
			break
		}
	}
	if len(paths) == 0 {
		return 0, fmt.Errorf("全部参考图下载失败")
	}

	setCount := 0
	for _, sel := range listing1688SellerFileInputSelectors {
		els, err := page.Timeout(3 * time.Second).Elements(sel)
		if err != nil || len(els) == 0 {
			continue
		}
		// 主图优先第一个 input；其余图尽量塞后续 input
		for i, el := range els {
			if i >= len(paths) {
				break
			}
			if err := el.SetFiles([]string{paths[i]}); err != nil {
				continue
			}
			setCount++
			time.Sleep(400 * time.Millisecond)
		}
		if setCount > 0 {
			// 若只有一个多选 file input，一次塞多张
			if setCount == 1 && len(paths) > 1 && len(els) == 1 {
				_ = els[0].SetFiles(paths)
				setCount = len(paths)
			}
			return setCount, nil
		}
	}
	return 0, fmt.Errorf("页面无可用 file input")
}

func listing1688DownloadToFile(dir string, idx int, url string) (string, error) {
	client := &http.Client{Timeout: 60 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return "", fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	ext := ".jpg"
	ct := resp.Header.Get("Content-Type")
	if strings.Contains(ct, "png") {
		ext = ".png"
	} else if strings.Contains(ct, "webp") {
		ext = ".webp"
	}
	path := filepath.Join(dir, fmt.Sprintf("img_%d%s", idx, ext))
	f, err := os.Create(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	if _, err := io.Copy(f, resp.Body); err != nil {
		return "", err
	}
	return path, nil
}

func listing1688SellerFillFirstPrice(page *rod.Page, skus json.RawMessage) bool {
	price := listing1688FirstSKUPrice(skus)
	if price == "" {
		return false
	}
	for _, sel := range listing1688SellerPriceSelectors {
		el, err := page.Timeout(1500 * time.Millisecond).Element(sel)
		if err != nil || el == nil {
			continue
		}
		_ = el.SelectAllText()
		_ = el.Input(price)
		return true
	}
	return false
}

func listing1688SellerFillFirstSKU(page *rod.Page, skus json.RawMessage) bool {
	code := listing1688FirstSKUCode(skus)
	if code == "" {
		return false
	}
	for _, sel := range listing1688SellerSKUSelectors {
		el, err := page.Timeout(1500 * time.Millisecond).Element(sel)
		if err != nil || el == nil {
			continue
		}
		_ = el.SelectAllText()
		_ = el.Input(code)
		return true
	}
	return false
}

func listing1688FirstSKUPrice(skus json.RawMessage) string {
	var arr []map[string]any
	if json.Unmarshal(skus, &arr) != nil || len(arr) == 0 {
		return ""
	}
	for _, k := range []string{"price", "price_min", "consignPrice", "salePrice"} {
		if v, ok := arr[0][k]; ok {
			s := strings.TrimSpace(fmt.Sprint(v))
			if s != "" && s != "<nil>" {
				return s
			}
		}
	}
	return ""
}

func listing1688FirstSKUCode(skus json.RawMessage) string {
	var arr []map[string]any
	if json.Unmarshal(skus, &arr) != nil || len(arr) == 0 {
		return ""
	}
	// Prefer 1688- canonical ids/attrs, then legacy wizard aliases.
	for _, k := range []string{
		"source_sku_id", "sku_id", "skuId",
		"spec_attrs", "sku_key", "spec_id",
		"spec", "name", "cargoNumber",
	} {
		if v, ok := arr[0][k]; ok {
			s := strings.TrimSpace(fmt.Sprint(v))
			if s != "" && s != "<nil>" {
				return s
			}
		}
	}
	return ""
}

var listing1688OfferIDRe = regexp.MustCompile(`(?i)(?:offer[_/]|offerId=|/offer/)(\d{8,})`)

func listing1688SellerExtractOfferID(url, html string) string {
	if m := listing1688OfferIDRe.FindStringSubmatch(url); len(m) > 1 {
		return m[1]
	}
	if m := listing1688OfferIDRe.FindStringSubmatch(html); len(m) > 1 {
		return m[1]
	}
	return ""
}

func listing1688SellerPlatformStatus(html string) string {
	if strings.Contains(html, "发布成功") {
		return "published"
	}
	if strings.Contains(html, "审核中") {
		return "auditing"
	}
	return ""
}

func (f *AlibabaFactory) exportSeller1688Cookies() (string, error) {
	if f.browser != nil {
		if c, err := f.browser.GetBy1688Cookies(); err == nil && strings.TrimSpace(c) != "" {
			return c, nil
		}
	}
	rodBrowser := getRodBrowser(f.browser)
	if rodBrowser == nil {
		return "", fmt.Errorf("浏览器未初始化")
	}
	page := rodBrowser.MustPage(listing1688SellerPublishEntryURL)
	defer page.MustClose()
	_ = rod.Try(func() { page.MustWaitLoad() })
	merged := map[string]string{}
	for _, u := range []string{
		"https://work.1688.com",
		"https://login.1688.com",
		"https://www.1688.com",
	} {
		res, err := (&proto.NetworkGetCookies{Urls: []string{u}}).Call(page)
		if err != nil {
			continue
		}
		for _, c := range res.Cookies {
			merged[c.Name] = c.Value
		}
	}
	if len(merged) == 0 {
		return "", fmt.Errorf("未获取到商家 Cookie")
	}
	parts := make([]string, 0, len(merged))
	for k, v := range merged {
		parts = append(parts, fmt.Sprintf("%s=%s", k, v))
	}
	return strings.Join(parts, "; "), nil
}

func listing1688SellerVerifiedBindings() map[string]string {
	return map[string]string{
		"title":      `input[placeholder*="建议使用通俗的产品名称"]`,
		"images":     `input[type="file"]`,
		"save_draft": `button:has-text("保存草稿")`,
		"submit":     `#submitFormButton`,
	}
}
