package alibaba

import (
	"encoding/json"
	"testing"
)

func TestListing1688FirstSKUPrice_CanonicalKeys(t *testing.T) {
	raw, _ := json.Marshal([]map[string]any{
		{"price": 18.5, "spec_attrs": "红色"},
	})
	if got := listing1688FirstSKUPrice(raw); got != "18.5" {
		t.Fatalf("price=%q", got)
	}
}

func TestListing1688FirstSKUCode_PrefersSourceSkuID(t *testing.T) {
	// 1688- shape: source_sku_id + spec_attrs (no legacy name)
	raw, _ := json.Marshal([]map[string]any{
		{
			"source_sku_id": "sku-red-m",
			"spec_attrs":    "红色>M",
			"sku_key":       "红色>M",
			"price":         18.5,
		},
	})
	if got := listing1688FirstSKUCode(raw); got != "sku-red-m" {
		t.Fatalf("code=%q, want source_sku_id", got)
	}
}

func TestListing1688FirstSKUCode_FallsBackSpecAttrs(t *testing.T) {
	raw, _ := json.Marshal([]map[string]any{
		{"spec_attrs": "蓝色", "price": 20},
	})
	if got := listing1688FirstSKUCode(raw); got != "蓝色" {
		t.Fatalf("code=%q", got)
	}
}
