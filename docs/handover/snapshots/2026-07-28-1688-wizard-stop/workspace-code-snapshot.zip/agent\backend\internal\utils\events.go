package utils

import (
	"commander-agent-t260220/backend/internal/constants"
	"commander-agent-t260220/backend/types"
	"context"

	"github.com/wailsapp/wails/v2/pkg/runtime"
)

type Events struct {
	Ctx context.Context
}

func NewEvents(ctx context.Context) *Events {
	return &Events{
		Ctx: ctx,
	}
}

// 发送通知给前端
func (s *Events) EventMessage(data types.Response) {
	runtime.EventsEmit(s.Ctx, constants.EventsMessage, data)
}

// 发送调度器事件（AC-08：发射脱敏副本，避免 Cookie 明文进 Agent UI）
func (s *Events) EventDispatcher(data types.AgentMessage[any, any]) {
	runtime.EventsEmit(s.Ctx, constants.EventsDispatcher, Listing1688RedactAgentMessageCopy(data))
}
