// Package offer1688 transplants 1688 offer HTML parsing from
// D:\reverselab\1688-\fetch_1688_offer.py (same regexes / field paths).
package offer1688

import (
	"encoding/json"
	"html"
	"regexp"
	"strconv"
	"strings"
)

// CAPTCHA_MARKERS mirrors fetch_1688_offer.py CAPTCHA_MARKERS.
var CAPTCHA_MARKERS = []string{
	"_____tmd_____",
	"punish",
	"x5secdata",
	`"action":"captcha"`,
}

var (
	offerIDRe = regexp.MustCompile(`(?i)offer/(\d+)`)
	ldJSONRe  = regexp.MustCompile(`(?is)<script[^>]+type=["']application/ld\+json["'][^>]*>(.*?)</script>`)
	initDataRe = regexp.MustCompile(`(?i)window\.__INIT_DATA\s*=\s*(\{[\s\S]*?\})\s*;\s*</script>`)
	// CONTEXT_INVOKE_RE — same as Python.
	// Python uses {0,1200}; Go RE2 caps repeats at 1000 — keep same shape.
	contextInvokeRe = regexp.MustCompile(`(?i)window\.context\s*=\s*\(function[\s\S]{0,999}?return\s+d\s*;?\s*\}\)\s*\(\s*[^,]+,\s*(\{)`)
	ogTitleRe       = regexp.MustCompile(`(?i)<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']`)
	ogImageRe       = regexp.MustCompile(`(?i)<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']`)
	subjectRe       = regexp.MustCompile(`"subject"\s*:\s*"((?:\\.|[^"\\])*)"`)

	jsIdentKeyRe = regexp.MustCompile(`([{\[,]\s*)([A-Za-z_][\w]*)\s*:`)
	jsNumKeyRe   = regexp.MustCompile(`([{\[,]\s*)(\d+)\s*:`)
	jsTrailObjRe = regexp.MustCompile(`,\s*}`)
	jsTrailArrRe = regexp.MustCompile(`,\s*]`)
)

var (
	loginURLMarkers   = []string{"login.taobao.com", "login.1688.com/member/signin"}
	captchaURLMarkers = []string{"_____tmd_____", "/punish", "x5secdata"}
	productFieldKeys  = []string{"offerDetail", "skuMap", "application/ld+json", "og:title", "__INIT_DATA"}
)

// ProductResult is the parsed offer payload (C4: title + ≥1 image + ≥1 sku).
type ProductResult struct {
	OK         bool     `json:"ok"`
	Status     string   `json:"status"`
	URL        string   `json:"url"`
	OfferID    string   `json:"source_item_id"`
	Title      string   `json:"title"`
	MainImages []string `json:"main_images"`
	Skus       []Sku    `json:"skus"`
	PriceMin   *float64 `json:"price_min,omitempty"`
	PriceMax   *float64 `json:"price_max,omitempty"`
	Error      string   `json:"error,omitempty"`
	Captcha    bool     `json:"captcha,omitempty"`
	NeedLogin  bool     `json:"need_login,omitempty"`
}

// Sku is one offer SKU row.
// Field names mirror D:\reverselab\1688-\fetch_1688_offer.py _skus_from_context;
// `name` is a wizard/M3 alias of `spec_attrs` (seller fill reads name / source_sku_id).
type Sku struct {
	SkuKey      string   `json:"sku_key,omitempty"`
	SpecAttrs   string   `json:"spec_attrs,omitempty"`
	Name        string   `json:"name,omitempty"`
	Price       *float64 `json:"price"`
	Stock       any      `json:"stock,omitempty"`
	SourceSkuID string   `json:"source_sku_id,omitempty"`
	SpecID      string   `json:"spec_id,omitempty"`
}

// ExtractOfferID mirrors extract_offer_id.
func ExtractOfferID(url string) string {
	m := offerIDRe.FindStringSubmatch(url)
	if len(m) < 2 {
		return ""
	}
	return m[1]
}

// NormalizeURL mirrors _normalize_url.
func NormalizeURL(url string) string {
	url = strings.TrimSpace(url)
	if !strings.HasPrefix(url, "http") {
		url = "https://" + strings.TrimLeft(url, "/")
	}
	return url
}

// IsCaptchaPage mirrors _is_captcha_page (CAPTCHA_MARKERS + redirect/login heuristics).
// 对齐 1688- CDP：document.title 含「验证码」即拦；_____tmd_____ 可能落在超大壳 HTML 后部。
func IsCaptchaPage(htmlStr, finalURL string) bool {
	if isLoginRedirect(finalURL) || htmlLooksLikeLoginPage(htmlStr) {
		return false
	}
	if isCaptchaRedirect(finalURL) {
		return true
	}
	if title := htmlDocumentTitle(htmlStr); strings.Contains(title, "验证码") {
		return true
	}
	head := htmlStr
	if len(head) > 20000 {
		head = head[:20000]
	}
	hasMarker := strings.Contains(head, "_____tmd_____") ||
		strings.Contains(head, `"action":"captcha"`) ||
		strings.Contains(head, "x5secdata")
	// Also honour CAPTCHA_MARKERS (includes "punish") on the head slice.
	if !hasMarker {
		for _, m := range CAPTCHA_MARKERS {
			if strings.Contains(head, m) {
				hasMarker = true
				break
			}
		}
	}
	// 大页壳：marker 常在后部脚本；无商品字段时扫全文关键标记
	if !hasMarker {
		for _, m := range []string{"_____tmd_____", `"action":"captcha"`, "x5secdata", "/_____tmd_____/verify"} {
			if strings.Contains(htmlStr, m) {
				hasMarker = true
				break
			}
		}
	}
	if !hasMarker {
		return false
	}
	hasProduct := false
	for _, k := range []string{"offerDetail", "skuMap", "application/ld+json", "og:title", "window.context"} {
		if strings.Contains(htmlStr, k) {
			hasProduct = true
			break
		}
	}
	if hasProduct {
		return false
	}
	return true
}

func htmlDocumentTitle(htmlStr string) string {
	lower := strings.ToLower(htmlStr)
	i := strings.Index(lower, "<title")
	if i < 0 {
		return ""
	}
	frag := htmlStr[i:]
	if len(frag) > 400 {
		frag = frag[:400]
	}
	start := strings.Index(frag, ">")
	if start < 0 {
		return ""
	}
	rest := frag[start+1:]
	end := strings.Index(strings.ToLower(rest), "</title>")
	if end < 0 {
		return strings.TrimSpace(rest)
	}
	return strings.TrimSpace(rest[:end])
}

// NeedsLogin mirrors _needs_login.
func NeedsLogin(htmlStr, finalURL string) bool {
	hasProduct := false
	for _, k := range productFieldKeys {
		if strings.Contains(htmlStr, k) {
			hasProduct = true
			break
		}
	}
	if hasProduct {
		return false
	}
	if isLoginRedirect(finalURL) || htmlLooksLikeLoginPage(htmlStr) {
		return true
	}
	head := htmlStr
	if len(head) > 5000 {
		head = head[:5000]
	}
	titleGeneric := strings.Contains(head, "采购批发平台")
	return titleGeneric && len(htmlStr) > 10_000
}

// ParseProductFromHTML mirrors _parse_product_from_html (no network side-effects).
// C4: title + ≥1 image + ≥1 sku. If skus empty but price known, inject synthetic "默认" sku;
// if skus empty and no price → parse_fail.
func ParseProductFromHTML(htmlStr, url, offerID, finalURL string) ProductResult {
	base := ProductResult{
		URL:     url,
		OfferID: offerID,
		Skus:    []Sku{},
	}

	if NeedsLogin(htmlStr, finalURL) {
		base.OK = false
		base.Status = "need_login"
		base.NeedLogin = true
		base.Error = "1688 会话失效或未登录，请重新「打开浏览器登录 1688」"
		return base
	}
	if IsCaptchaPage(htmlStr, finalURL) {
		base.OK = false
		base.Status = "captcha_or_blocked"
		base.Captcha = true
		base.Error = "1688 返回验证码/拦截页"
		return base
	}

	ld := parseLDJSON(htmlStr)
	ctx := parseWindowContext(htmlStr)
	if ctx == nil {
		ctx = parseInitData(htmlStr)
	}

	title := ""
	mainImages := []string{}
	skus := []Sku{}
	var priceMin, priceMax *float64

	if ld != nil {
		if name, ok := ld["name"].(string); ok {
			title = name
		} else if name := asString(ld["name"]); name != "" {
			title = name
		}
		mainImages = imagesFromLD(ld)
		if offers, ok := ld["offers"].(map[string]any); ok {
			if p, ok := toFloatPtr(offers["price"]); ok {
				priceMin, priceMax = p, p
			}
		}
	}

	if ctx != nil {
		if title == "" {
			title = titleFromContext(ctx)
		}
		if imgs := imagesFromContext(ctx); len(imgs) > 0 {
			mainImages = imgs
		}
		if s := skusFromContext(ctx); len(s) > 0 {
			skus = s
		}
		if priceMin == nil {
			mn, mx := pricesFromContext(ctx)
			priceMin, priceMax = mn, mx
		}
	}

	if title == "" || len(mainImages) == 0 {
		meta := parseFallbackMeta(htmlStr)
		if title == "" {
			title = meta.title
		}
		if len(mainImages) == 0 {
			mainImages = meta.images
		}
	}

	if title == "" || len(mainImages) == 0 {
		base.OK = false
		base.Status = "parse_fail"
		base.Error = "页面已打开但未能解析商品字段（可能改版或需登录态）"
		return base
	}

	if len(skus) > 0 {
		var nums []float64
		for _, s := range skus {
			if s.Price != nil {
				nums = append(nums, *s.Price)
			}
		}
		if len(nums) > 0 {
			mn, mx := nums[0], nums[0]
			for _, n := range nums[1:] {
				if n < mn {
					mn = n
				}
				if n > mx {
					mx = n
				}
			}
			priceMin, priceMax = &mn, &mx
		}
	}

	// C4: require ≥1 sku — synthesize from price when skuMap absent.
	if len(skus) == 0 {
		if priceMin == nil {
			base.OK = false
			base.Status = "parse_fail"
			base.Title = title
			base.MainImages = mainImages
			base.Error = "未能解析 SKU（无 skuMap 且无价格可合成默认 SKU）"
			return base
		}
		p := *priceMin
		skus = []Sku{{
			SkuKey:    "默认",
			SpecAttrs: "默认",
			Name:      "默认",
			Price:     &p,
		}}
	}

	base.OK = true
	base.Status = "success"
	base.Title = title
	base.MainImages = mainImages
	base.Skus = skus
	base.PriceMin = priceMin
	base.PriceMax = priceMax
	return base
}

func isCaptchaRedirect(url string) bool {
	u := strings.ToLower(url)
	for _, m := range captchaURLMarkers {
		if strings.Contains(u, m) {
			return true
		}
	}
	return false
}

func isLoginRedirect(url string) bool {
	u := strings.ToLower(url)
	if len(u) > 2048 {
		u = u[:2048]
	}
	for _, m := range loginURLMarkers {
		if strings.Contains(u, m) {
			return true
		}
	}
	return false
}

func htmlLooksLikeLoginPage(htmlStr string) bool {
	if htmlStr == "" {
		return false
	}
	for _, k := range productFieldKeys {
		if strings.Contains(htmlStr, k) {
			return false
		}
	}
	head := htmlStr
	if len(head) > 16000 {
		head = head[:16000]
	}
	headLower := strings.ToLower(head)
	strong := strings.Contains(head, `name="loginId"`) ||
		strings.Contains(headLower, `id="login-form"`) ||
		(strings.Contains(head, "密码登录") && (strings.Contains(head, "扫码登录") || strings.Contains(head, "手机扫码"))) ||
		(strings.Contains(headLower, "login.1688.com/member/signin") && len(htmlStr) < 50_000)
	return strong
}

func parseLDJSON(htmlStr string) map[string]any {
	for _, m := range ldJSONRe.FindAllStringSubmatch(htmlStr, -1) {
		if len(m) < 2 {
			continue
		}
		var data any
		if err := json.Unmarshal([]byte(strings.TrimSpace(m[1])), &data); err != nil {
			continue
		}
		switch v := data.(type) {
		case map[string]any:
			if t := asString(v["@type"]); t == "Product" || t == "product" {
				return v
			}
		case []any:
			for _, item := range v {
				if obj, ok := item.(map[string]any); ok {
					if t := asString(obj["@type"]); t == "Product" || t == "product" {
						return obj
					}
				}
			}
		}
	}
	return nil
}

func extractBalanced(text string, start int) string {
	if start >= len(text) {
		return ""
	}
	open := text[start]
	if open != '{' && open != '[' {
		return ""
	}
	pairs := map[byte]byte{'{': '}', '[': ']'}
	stack := []byte{open}
	inStr := false
	esc := false
	for i := start + 1; i < len(text); i++ {
		ch := text[i]
		if inStr {
			if esc {
				esc = false
			} else if ch == '\\' {
				esc = true
			} else if ch == '"' {
				inStr = false
			}
			continue
		}
		if ch == '"' {
			inStr = true
		} else if ch == '{' || ch == '[' {
			stack = append(stack, ch)
		} else if ch == '}' || ch == ']' {
			if len(stack) == 0 {
				return ""
			}
			op := stack[len(stack)-1]
			stack = stack[:len(stack)-1]
			if pairs[op] != ch {
				return ""
			}
			if len(stack) == 0 {
				return text[start : i+1]
			}
		}
	}
	return ""
}

func jsObjectLiteralToJSON(text string) string {
	out := jsIdentKeyRe.ReplaceAllString(text, `${1}"${2}":`)
	out = jsNumKeyRe.ReplaceAllString(out, `${1}"${2}":`)
	out = jsTrailObjRe.ReplaceAllString(out, "}")
	out = jsTrailArrRe.ReplaceAllString(out, "]")
	return out
}

func loadWindowContextRoot(htmlStr string) map[string]any {
	m := contextInvokeRe.FindStringSubmatchIndex(htmlStr)
	if m == nil {
		return nil
	}
	// group 1 start is m[2]
	raw := extractBalanced(htmlStr, m[2])
	if raw == "" {
		return nil
	}
	var root map[string]any
	if err := json.Unmarshal([]byte(jsObjectLiteralToJSON(raw)), &root); err != nil {
		return nil
	}
	return root
}

func moduleFields(data map[string]any, name string) map[string]any {
	node, ok := data[name].(map[string]any)
	if !ok {
		return map[string]any{}
	}
	fields, ok := node["fields"].(map[string]any)
	if !ok {
		return map[string]any{}
	}
	return fields
}

func normalizeContextProduct(root map[string]any) map[string]any {
	result := root
	if r, ok := root["result"].(map[string]any); ok {
		result = r
	}
	data, _ := result["data"].(map[string]any)
	if data == nil {
		data = map[string]any{}
	}

	globalModel := map[string]any{}
	if g, ok := result["global"].(map[string]any); ok {
		if gd, ok := g["globalData"].(map[string]any); ok {
			if model, ok := gd["model"].(map[string]any); ok {
				globalModel = model
			}
		}
	}

	offer, _ := globalModel["offerDetail"].(map[string]any)
	if offer == nil {
		offer = map[string]any{}
	}

	gallery := moduleFields(data, "gallery")
	titleFields := moduleFields(data, "productTitle")
	priceFields := moduleFields(data, "mainPrice")
	descFields := moduleFields(data, "description")
	rootFields := moduleFields(data, "Root")
	dataJSON, _ := rootFields["dataJson"].(map[string]any)
	if dataJSON == nil {
		dataJSON = map[string]any{}
	}
	skuModel, _ := dataJSON["skuModel"].(map[string]any)
	if skuModel == nil {
		skuModel = map[string]any{}
	}

	skuInfo, _ := skuModel["skuInfoMap"].(map[string]any)
	if skuInfo == nil {
		skuInfo, _ = offer["skuInfoMap"].(map[string]any)
	}
	if skuInfo == nil {
		skuInfo, _ = offer["skuMap"].(map[string]any)
	}
	if skuInfo == nil {
		skuInfo = map[string]any{}
	}

	var galleryImgs any
	if v, ok := gallery["offerImgList"]; ok {
		galleryImgs = v
	} else {
		galleryImgs = gallery["mainImage"]
	}
	var dataJSONImgs any
	if imgs, ok := dataJSON["images"].([]any); ok {
		dataJSONImgs = imgs
	}

	subject := firstNonEmpty(
		asString(offer["subject"]),
		asString(gallery["subject"]),
		asString(titleFields["title"]),
	)

	return map[string]any{
		"offerDetail":     offer,
		"skuInfoMap":      skuInfo,
		"skuMap":          skuInfo,
		"subject":         subject,
		"galleryImages":   galleryImgs,
		"dataJsonImages":  dataJSONImgs,
		"priceModel":      priceFields["priceModel"],
		"description_url": firstNonEmpty(asString(descFields["detailUrl"]), asString(offer["detailUrl"])),
		"dataJson":        dataJSON,
		"skuProps":        firstList(skuModel["skuProps"], offer["skuProps"]),
	}
}

func parseWindowContext(htmlStr string) map[string]any {
	root := loadWindowContextRoot(htmlStr)
	if root == nil {
		return nil
	}
	return normalizeContextProduct(root)
}

func parseInitData(htmlStr string) map[string]any {
	m := initDataRe.FindStringSubmatch(htmlStr)
	if m == nil {
		return nil
	}
	var root map[string]any
	if err := json.Unmarshal([]byte(jsObjectLiteralToJSON(m[1])), &root); err != nil {
		return nil
	}
	for _, key := range []string{"data", "globalData", "result"} {
		if nested, ok := root[key].(map[string]any); ok {
			if nested["offerDetail"] != nil || nested["skuMap"] != nil || nested["skuInfoMap"] != nil {
				return nested
			}
		}
	}
	if root["offerDetail"] != nil || root["skuMap"] != nil || root["skuInfoMap"] != nil {
		return root
	}
	return root
}

type fallbackMeta struct {
	title  string
	images []string
}

func parseFallbackMeta(htmlStr string) fallbackMeta {
	out := fallbackMeta{images: []string{}}
	if m := ogTitleRe.FindStringSubmatch(htmlStr); m != nil {
		out.title = strings.TrimSpace(m[1])
	}
	if out.title == "" {
		if m2 := subjectRe.FindStringSubmatch(htmlStr); m2 != nil {
			var decoded string
			if err := json.Unmarshal([]byte(`"`+m2[1]+`"`), &decoded); err == nil {
				out.title = decoded
			} else {
				out.title = m2[1]
			}
		}
	}
	seen := map[string]struct{}{}
	for _, im := range ogImageRe.FindAllStringSubmatch(htmlStr, -1) {
		u := absURL(strings.TrimSpace(im[1]))
		if u == "" {
			continue
		}
		if _, ok := seen[u]; ok {
			continue
		}
		seen[u] = struct{}{}
		out.images = append(out.images, u)
	}
	return out
}

func absURL(u string) string {
	if u == "" {
		return u
	}
	if strings.HasPrefix(u, "//") {
		return "https:" + u
	}
	if strings.HasPrefix(u, "img/") || strings.HasPrefix(u, `img\`) {
		return "https://cbu01.alicdn.com/" + strings.ReplaceAll(u, `\`, "/")
	}
	return u
}

func imagesFromLD(ld map[string]any) []string {
	raw := ld["image"]
	var list []any
	switch v := raw.(type) {
	case string:
		if v != "" {
			return []string{absURL(v)}
		}
		return nil
	case []any:
		list = v
	default:
		return nil
	}
	out := make([]string, 0, len(list))
	for _, x := range list {
		s := asString(x)
		if s != "" {
			out = append(out, absURL(s))
		}
	}
	return out
}

func collectImageURLs(raw any) []string {
	var urls []string
	switch v := raw.(type) {
	case string:
		s := strings.TrimSpace(v)
		if s != "" {
			urls = append(urls, absURL(s))
		}
	case []any:
		for _, item := range v {
			switch it := item.(type) {
			case string:
				s := strings.TrimSpace(it)
				if s != "" {
					urls = append(urls, absURL(s))
				}
			case map[string]any:
				u := firstNonEmpty(
					asString(it["fullPathImageURI"]),
					asString(it["url"]),
					asString(it["imageURI"]),
					asString(it["src"]),
				)
				if u != "" {
					urls = append(urls, absURL(u))
				}
			}
		}
	}
	return urls
}

func skusFromContext(ctx map[string]any) []Sku {
	offer, _ := ctx["offerDetail"].(map[string]any)
	if offer == nil {
		offer, _ = ctx["offer"].(map[string]any)
	}
	if offer == nil {
		offer = map[string]any{}
	}

	var skuMap map[string]any
	for _, cand := range []any{ctx["skuInfoMap"], ctx["skuMap"], offer["skuInfoMap"], offer["skuMap"]} {
		if m, ok := cand.(map[string]any); ok && len(m) > 0 {
			skuMap = m
			break
		}
	}
	if skuMap == nil {
		return nil
	}

	skus := make([]Sku, 0, len(skuMap))
	for key, val := range skuMap {
		vm, ok := val.(map[string]any)
		if !ok {
			continue
		}
		skuKey := html.UnescapeString(key)
		attrs := html.UnescapeString(firstNonEmpty(asString(vm["specAttrs"]), skuKey))
		var price *float64
		if p, ok := toFloatPtr(vm["discountPrice"]); ok {
			price = p
		} else if p, ok := toFloatPtr(vm["price"]); ok {
			price = p
		}
		var stock any
		if v, ok := vm["canBookCount"]; ok && v != nil {
			stock = v
		} else if v, ok := vm["stock"]; ok && v != nil {
			stock = v
		}
		skus = append(skus, Sku{
			SkuKey:      skuKey,
			SpecAttrs:   attrs,
			Name:        attrs, // M3 seller alias
			Price:       price,
			Stock:       stock,
			SourceSkuID: asString(vm["skuId"]),
			SpecID:      asString(vm["specId"]),
		})
	}
	return skus
}

func titleFromContext(ctx map[string]any) string {
	offer, _ := ctx["offerDetail"].(map[string]any)
	if offer == nil {
		offer = map[string]any{}
	}
	return firstNonEmpty(
		asString(ctx["subject"]),
		asString(offer["subject"]),
		asString(offer["title"]),
	)
}

func imagesFromContext(ctx map[string]any) []string {
	offer, _ := ctx["offerDetail"].(map[string]any)
	if offer == nil {
		offer = map[string]any{}
	}
	seen := map[string]struct{}{}
	var urls []string
	for _, raw := range []any{
		offer["imageList"],
		offer["mainImageList"],
		offer["images"],
		ctx["galleryImages"],
		ctx["dataJsonImages"],
		ctx["imageList"],
		ctx["images"],
	} {
		for _, u := range collectImageURLs(raw) {
			if _, ok := seen[u]; ok {
				continue
			}
			seen[u] = struct{}{}
			urls = append(urls, u)
		}
	}
	return urls
}

func pricesFromContext(ctx map[string]any) (*float64, *float64) {
	priceModel, ok := ctx["priceModel"].(map[string]any)
	if !ok {
		return nil, nil
	}
	current, ok := priceModel["currentPrices"].([]any)
	if !ok || len(current) == 0 {
		return nil, nil
	}
	var nums []float64
	for _, item := range current {
		if m, ok := item.(map[string]any); ok {
			if p, ok := toFloatPtr(m["price"]); ok {
				nums = append(nums, *p)
			}
		}
	}
	if len(nums) == 0 {
		return nil, nil
	}
	mn, mx := nums[0], nums[0]
	for _, n := range nums[1:] {
		if n < mn {
			mn = n
		}
		if n > mx {
			mx = n
		}
	}
	return &mn, &mx
}

func asString(v any) string {
	switch t := v.(type) {
	case string:
		return t
	case float64:
		return strconv.FormatFloat(t, 'f', -1, 64)
	case json.Number:
		return t.String()
	case nil:
		return ""
	default:
		return ""
	}
}

func toFloatPtr(v any) (*float64, bool) {
	switch t := v.(type) {
	case float64:
		return &t, true
	case float32:
		f := float64(t)
		return &f, true
	case int:
		f := float64(t)
		return &f, true
	case int64:
		f := float64(t)
		return &f, true
	case json.Number:
		f, err := t.Float64()
		if err != nil {
			return nil, false
		}
		return &f, true
	case string:
		s := strings.TrimSpace(t)
		if s == "" {
			return nil, false
		}
		f, err := strconv.ParseFloat(s, 64)
		if err != nil {
			return nil, false
		}
		return &f, true
	default:
		return nil, false
	}
}

func firstNonEmpty(vals ...string) string {
	for _, v := range vals {
		if v != "" {
			return v
		}
	}
	return ""
}

func firstList(a, b any) any {
	if list, ok := a.([]any); ok {
		return list
	}
	if list, ok := b.([]any); ok {
		return list
	}
	return []any{}
}
