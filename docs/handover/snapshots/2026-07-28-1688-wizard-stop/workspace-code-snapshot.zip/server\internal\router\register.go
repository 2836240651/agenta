package router

import "github.com/gin-gonic/gin"

// 注册路由
func (r *Router) Register() {
	// CORS 必须在 Engine 层注册，否则 OPTIONS 预检请求会因未匹配到路由而 404
	r.Engine.Use(r.Middleware.Cross())
	base := r.Engine.Group("/api/v1")
	r.UserModuleRegister(base.Group("user"))
	r.InvitationModuleRegister(base.Group("invitation"))
	r.AgentModuleRegister(base.Group("agent"))
	r.OpenapiModuleRegister(base.Group("openapi"))
	r.TicketModuleRegister(base.Group("ticket"))
	r.SaleModuleRegister(base.Group("sale"))
	r.ReptileModuleRegister(base.Group("reptile"))
	r.AiChatModuleRegister(base.Group("ai"))
	r.ExpressModuleRegister(base.Group("express"))
	r.AeCspModuleRegister(base.Group("ae_csp"))
	r.Listing1688ModuleRegister(base.Group("listing1688"))
}

// 用户模块注册
func (r *Router) UserModuleRegister(base *gin.RouterGroup) {
	base.POST("register", r.Service.UserRegister) // 用户注册
	base.POST("login", r.Service.UserLogin)       // 用户登录
	base.POST("loginout", r.Service.UserLoginout) // 用户登出（允许过期 token 撤销 Redis 会话）
	base.Use(r.Middleware.Authentication)
	base.POST("refresh", r.Service.UserRefreshToken) // 主动续期 token
	base.POST("chat", r.Service.UserChat)            // 用户聊天
	base.POST("session", r.Service.UserSession)      // 用户历史会话列表
	base.POST("list", r.Service.UserList)            // 用户列表
	base.POST("delete", r.Service.UserDelete)        // 删除用户
	base.POST("repass", r.Service.UserRepass)        // 用户修改密码
	base.POST("reinfo", r.Service.UserReinfo)        // 用户修改个人信息
	base.POST("info", r.Service.UserInfo)            // 获取用户个人信息
	base.POST("avatar", r.Service.UserAvatar)        // 更新用户头像
	base.POST("set_role", r.Service.UserSetRole)     // 设置用户角色
}

// 邀请码模块注册
func (r *Router) InvitationModuleRegister(base *gin.RouterGroup) {
	base.Use(r.Middleware.Authentication)
	base.POST("create", r.Service.InvitationCreate) // 创建邀请码
	base.POST("delete", r.Service.InvitationDelete) // 删除邀请码
	base.POST("list", r.Service.InvitationList)     // 邀请码列表
}

// Agent 模块注册
func (r *Router) AgentModuleRegister(base *gin.RouterGroup) {
	base.GET("online", r.Service.AgentOnline) // Agent 上线
	base.GET("status", r.Service.AgentStatus) // Agent 在线状态（只读）
	base.Use(r.Middleware.Authentication)
	base.POST("product_issue", r.Service.AgentProductIssue)                  // Agent 产品发布
	base.POST("product_issue_precheck", r.Service.AgentProductIssuePrecheck) // Agent 上架预检
	base.POST("task_list", r.Service.AgentTaskList)                          // Agent 任务列表（无需参数）
	base.POST("shop_list", r.Service.AgentShopList)                          // Agent 店铺列表
	base.POST("category_list", r.Service.AgentCategoryList)                  // Agent 类目列表
	base.POST("list", r.Service.AgentList)                                   // Agent 列表
	base.POST("retask", r.Service.AgentRetask)                               // Agent 重新执行任务
	base.POST("product_list", r.Service.AgentProductList)                    // Agent 产品列表
	base.POST("task_delete", r.Service.AgentTaskDelete)                      // Agent 删除任务
}

// 开放API注册
func (r *Router) OpenapiModuleRegister(base *gin.RouterGroup) {
	base.GET("agent_version", r.Service.OpenapiAgentVersion)
	base.GET("vision_images/:id", r.Service.OpenapiVisionImage)                    // 检查客户端最新版本
	base.POST("temu_sales", r.Service.OpenapiTemuSales)                            // temu销量上传
	base.POST("reptile_express", r.Service.OpenapiReptileExpress)                  // 快递单号上传
	base.POST("temu_return", r.Service.OpenapiTemuReturn)                          // temu退货上传
	base.POST("temu_qc_failed", r.Service.OpenapiTemuQc)                           // temu抽检上传
	base.POST("reptile_analytical_words", r.Service.OpenapiReptileAnalyticalWords) // 热搜词列表上传
}

// 工单模块注册
func (r *Router) TicketModuleRegister(base *gin.RouterGroup) {
	base.Use(r.Middleware.Authentication)
	base.POST("create", r.Service.TicketCreate)     // 创建工单
	base.POST("delete", r.Service.TicketDelete)     // 删除工单
	base.POST("close", r.Service.TicketClose)       // 关闭工单
	base.POST("accepted", r.Service.TicketAccepted) // 受理工单
	base.POST("list", r.Service.TicketList)         // 工单列表
}

// 销售模块注册
func (r *Router) SaleModuleRegister(base *gin.RouterGroup) {
	base.Use(r.Middleware.Authentication)
	base.POST("sales_list", r.Service.SaleList)                               // 销售数据列表
	base.POST("shop_list", r.Service.SaleShopList)                            // 销售上传的店铺列表
	base.POST("user_list", r.Service.SaleUserList)                            // 销售上传的用户列表
	base.POST("enterprise_list", r.Service.SaleEnterpriseList)                // 销售上传的企业列表
	base.POST("delete", r.Service.SaleDelete)                                 // 删除销售上传的数据
	base.POST("inventory_early_warning", r.Service.SaleInventoryEarlyWarning) // 库存预警
	base.POST("low_sale_warning", r.Service.SaleLowSaleWarning)               // 低销量预警
	base.POST("import_cost", r.Service.SaleImportCost)                        // 导入成本
	base.POST("overload_product", r.Service.SaleOverloadProduct)              // 霸王产品
	base.POST("lose_warning", r.Service.SaleLoseWarning)                      // 亏损产品预警
}

// 爬虫模块注册
func (r *Router) ReptileModuleRegister(base *gin.RouterGroup) {
	base.Use(r.Middleware.Authentication)
	base.POST("return_list", r.Service.ReptileSearchReturnList)              // 获取爬虫的退货列表
	base.POST("qc_list", r.Service.ReptileSearchQcList)                      // 获取爬虫的抽检列表
	base.POST("keyword_add", r.Service.ReptileSearchKeywordAdd)              // 添加爬虫的关键词
	base.POST("keyword_delete", r.Service.ReptileSearchKeywordDelete)        // 删除爬虫的关键词
	base.POST("keyword_list", r.Service.ReptileSearchKeywordList)            // 获取爬虫的关键词列表
	base.POST("product_list", r.Service.ReptileSearchProductList)            // 获取爬虫的产品列表
	base.POST("analytical_words_list", r.Service.ReptileAnalyticalWordsList) // 获取爬虫的分析词列表
}

// AI模块注册
func (r *Router) AiChatModuleRegister(base *gin.RouterGroup) {
	base.Use(r.Middleware.Authentication)
	base.POST("chat", r.Service.AiChat)                                      // AI 聊天
	base.POST("produce_images", r.Service.AiProduceImages)                   // 提交 AI 生图任务（异步，立即返回）
	base.POST("produce_images_task_list", r.Service.AiProduceImagesTaskList) // AI 生图任务列表
	base.POST("chat_session", r.Service.AiChatSession)                       // AI 对话历史会话列表
	base.POST("produce_images_delete", r.Service.AiProduceImagesDelete)      // 删除 AI 生图任务
}

// 快递模块注册
func (r *Router) ExpressModuleRegister(base *gin.RouterGroup) {
	base.Use(r.Middleware.Authentication)
	base.POST("list", r.Service.ExpressList) // 快递列表
}

// 速卖通全托管类目录制模块
func (r *Router) AeCspModuleRegister(base *gin.RouterGroup) {
	tpl := base.Group("template")
	tpl.Use(r.Middleware.Authentication)
	tpl.POST("upload", r.Service.AeCspTemplateUpload)
	tpl.POST("list", r.Service.AeCspTemplateList)
	tpl.POST("detail", r.Service.AeCspTemplateDetail)
	tpl.GET("recorder_config", r.Service.AeCspTemplateRecorderConfig)
	tpl.GET("recorder_bundle", r.Service.AeCspTemplateRecorderBundle)
}

// 1688 竞品向导（与 v1 /agent/product_issue 妙手一键物理隔离）
func (r *Router) Listing1688ModuleRegister(base *gin.RouterGroup) {
	base.Use(r.Middleware.Authentication)
	base.POST("workflows", r.Service.Listing1688WorkflowCreate)
	base.GET("store-preset", r.Service.Listing1688StorePresetGet)
	base.POST("store-preset", r.Service.Listing1688StorePresetUpsert)
	base.GET("category-templates", r.Service.Listing1688CategoryTemplateList)
	base.POST("category-templates", r.Service.Listing1688CategoryTemplateUpsert)
	base.GET("workflows/:id", r.Service.Listing1688WorkflowGet)

	wf := base.Group("workflows/:id")
	wf.POST("session/open-login", r.Service.Listing1688SessionOpenLogin)
	wf.POST("session/confirm", r.Service.Listing1688SessionConfirm)
	wf.POST("session/validate", r.Service.Listing1688SessionValidate)
	wf.POST("session/seller/open-login", r.Service.Listing1688SellerSessionOpenLogin)
	wf.POST("session/seller/confirm", r.Service.Listing1688SellerSessionConfirm)
	wf.POST("session/seller/validate", r.Service.Listing1688SellerSessionValidate)
	wf.POST("collect", r.Service.Listing1688Collect)
	wf.POST("collect/retry", r.Service.Listing1688CollectRetry)
	wf.POST("images/generate", r.Service.Listing1688ImagesGenerate)
	wf.POST("images/regenerate", r.Service.Listing1688ImagesRegenerate)
	wf.POST("images/select", r.Service.Listing1688ImagesSelect)
	wf.POST("images/use-original", r.Service.Listing1688ImagesUseOriginal)
	wf.POST("templates/candidates", r.Service.Listing1688TemplateCandidates)
	wf.POST("templates/select", r.Service.Listing1688TemplateSelect)
	wf.POST("templates/open-similar", r.Service.Listing1688TemplateOpenSimilar)
	wf.POST("category/inspect", r.Service.Listing1688CategoryInspect)
	wf.POST("form/validate", r.Service.Listing1688PublishFormValidate)
	wf.POST("form/save-draft", r.Service.Listing1688PublishFormSaveDraft)
	wf.POST("publish", r.Service.Listing1688Publish)
	wf.GET("publish/status", r.Service.Listing1688PublishStatus)
}
