package core

import (
	"commander-agent-t260220/backend/internal/constants"
	"commander-agent-t260220/backend/internal/crontabs"
	"commander-agent-t260220/backend/internal/dispatcher"
	"commander-agent-t260220/backend/internal/factory/aliexpress"
	"commander-agent-t260220/backend/internal/factory/alibaba"
	"commander-agent-t260220/backend/internal/factory/dxm"
	"commander-agent-t260220/backend/internal/factory/ozon"
	"commander-agent-t260220/backend/internal/pkg"
	"commander-agent-t260220/backend/internal/services"
	"commander-agent-t260220/backend/internal/utils"
	"commander-agent-t260220/backend/types"
	"context"
	"fmt"
	"runtime"
	"time"
)

// Container 应用容器，按顺序持有各模块，支持相互注入
type Container struct {
	Ctx context.Context

	// 1. 基础层（无外部依赖）
	Config *utils.AgentConfig
	Logger *utils.Logger
	Events *utils.Events

	// 2. 调度层
	Dispatcher *dispatcher.Dispatcher

	// 3. 网络层
	WsAgent *utils.WsAgent

	// 4. 数据层
	Resty             *types.Resty
	RestyDxm          *utils.RestyDxmUtils
	RestyAlibaba      *utils.RestyAlibabaUtils
	RestyTemuUtils    *utils.RestyTemuUtils
	Resty1688Utils    *utils.Resty1688Utils
	RestyOpenapiUtils *utils.RestyOpenapiUtils
	Services          *services.Services

	// 5. 浏览器
	Browser *utils.Browser

	// 6. 定时任务
	Crontab *crontabs.Crontab

	// 7. 自更新
	Update *utils.Update
}

// Dashboard 获取仪表盘数据（HomeService 已移除，返回基于容器数据的聚合）
func (c *Container) Dashboard() types.HomeDashboard {
	// 平台状态：基于 Browser 中各平台登录状态
	platformStatus := []types.HomePlatformStatus{
		{Name: "Temu", Connected: c.Browser != nil}, // 简化：仅表示浏览器就绪
		{Name: "速卖通", Connected: c.Browser != nil},
	}
	return types.HomeDashboard{
		Card: types.HomeCard{
			TotalTasks:   0,
			PendingTasks: 0,
			Protocols:    3,
			RunningTime:  "-",
		},
		ActivityLog:    []types.HomeActivityLog{},
		PlatformStatus: platformStatus,
	}
}

// NewContainer 创建容器（仅创建，不启动）
func NewContainer(ctx context.Context) *Container {
	return &Container{Ctx: ctx}
}

// Init 按顺序初始化各模块，支持依赖注入
func (c *Container) Init() error {
	// ---------- 1. 配置与日志（无外部依赖）----------
	c.Config = utils.NewAgentConfig()
	logger, err := utils.NewLogger(pkg.GetLogDir())
	if err != nil {
		return fmt.Errorf("初始化日志失败: %w", err)
	}
	c.Logger = logger

	if err := c.Config.Start(); err != nil {
		return fmt.Errorf("初始化配置文件失败: %w", err)
	}

	// ---------- 2. 调度器（先创建，后续注册平台）----------
	c.Dispatcher = dispatcher.NewDispatcher()

	// ---------- 3. 事件总线 ----------
	c.Events = utils.NewEvents(c.Ctx)

	c.Resty = types.NewResty()

	// ---------- 5. 浏览器（仅创建实例）----------
	c.Browser = utils.NewBrowser(c.Config)

	// ---------- 5.1 店小秘请求工具（依赖 Browser，需在注册平台前创建）----------
	c.RestyDxm = utils.NewRestyDxmUtils(c.Browser)
	c.RestyAlibaba = utils.NewRestyAlibabaUtils(c.Browser)
	c.RestyTemuUtils = utils.NewRestyTemuUtils(c.Browser)
	c.Resty1688Utils = utils.NewResty1688Utils(c.Browser)
	c.RestyOpenapiUtils = utils.NewRestyOpenapiUtils(c.Browser)
	c.Crontab = crontabs.NewCrontab(c.Browser, c.Dispatcher, c.Events, c.RestyTemuUtils, c.Config, c.Logger, c.Resty1688Utils, c.RestyOpenapiUtils)
	c.Services = services.NewServices(c.Browser, c.Config, c.Crontab, c.RestyTemuUtils, c.RestyOpenapiUtils)

	// ---------- 6. 注册多平台到调度器 ----------
	c.registerPlatforms()

	// ---------- 7. WebSocket（依赖 Config, Logger, Events, Dispatcher）----------
	c.WsAgent = utils.NewWsAgent(c.Logger, c.Config, c.Events, c.Dispatcher)
	c.WsAgent.Start()

	// ---------- 8. 自更新 ----------
	c.Update = utils.NewUpdate()

	c.Crontab.Start()

	return nil
}

// registerPlatforms 注册所有平台实现到调度器
func (c *Container) registerPlatforms() {
	config := c.Config.GetConfig()

	// 店小秘 平台
	dxmFactory := dxm.NewDxmFactory(config, c.Browser, c.RestyDxm)
	c.Dispatcher.Register(constants.PlatformDxm, dxmFactory)

	// 速卖通平台
	aliexpressFactory := aliexpress.NewAliExpressFactory(config, c.Browser)
	c.Dispatcher.Register(constants.PlatformAliExpress, aliexpressFactory)

	// 1688 平台（国内，妙手导入；与速卖通 AliExpress 隔离）
	alibabaFactory := alibaba.NewAlibabaFactory(config, c.Browser)
	c.Dispatcher.Register(constants.Platform1688, alibabaFactory)

	// Ozon平台
	ozonFactory := ozon.NewOzonFactory(config, c.Browser, c.RestyDxm)
	c.Dispatcher.Register(constants.PlatformOzon, ozonFactory)
}

// StartBrowserDeferred 延迟启动浏览器（Windows 上延后更久）
func (c *Container) StartBrowserDeferred() {
	delay := 1 * time.Second
	if runtime.GOOS == "windows" {
		delay = 3 * time.Second
	}
	time.Sleep(delay)
	c.Browser.Init()
}

// Shutdown 按依赖顺序优雅退出，确保浏览器/Chromium 进程被正确回收。
func (c *Container) Shutdown() {
	if c == nil {
		return
	}

	// 先停掉会继续触发浏览器/网络请求的组件
	if c.Crontab != nil {
		c.Crontab.Stop()
	}
	if c.WsAgent != nil {
		c.WsAgent.Stop()
	}

	// 关闭浏览器（包含 Kill Chromium）
	if c.Browser != nil {
		c.Browser.Close()
	}

	// 最后关闭日志等资源
	if c.Logger != nil {
		c.Logger.Close()
	}
}
