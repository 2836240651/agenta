package alibaba

// 1688 商家发品选择器 / URL（改版只改本文件）
const (
	listing1688SellerLoginURL        = "https://login.1688.com/member/signin.htm?Done=https%3A%2F%2Fwork.1688.com%2F%3F_path_%3DsellerPro%2F2017sellerbase_offer%2ForderPost"
	listing1688SellerWorkbenchURL    = "https://work.1688.com/"
	listing1688SellerPublishEntryURL = "https://work.1688.com/?_path_=sellerPro/2017sellerbase_offer/orderPost"
	listing1688SellerManageURL       = "https://work.1688.com/page/offer_manage.html"
)

// 发品入口点击文案（ElementR tag + regex）
var listing1688SellerEntryClickPairs = [][2]string{
	{"a", "发布供应"},
	{"a", "发布产品"},
	{"a", "我要发布"},
	{"button", "发布"},
}

var listing1688SellerEntryHrefSelectors = []string{
	`a[href*="offer/post"]`,
	`a[href*="publish"]`,
	`a[href*="post.htm"]`,
}

var listing1688SellerManageClickPairs = [][2]string{
	{"a", "商品管理（新）"},
	{"a", "商品管理"},
	{"span", "商品管理（新）"},
	{"span", "商品管理"},
}

var listing1688SellerTitleSelectors = []string{
	`input[name*="title"]`,
	`input[placeholder*="标题"]`,
	`textarea[name*="title"]`,
	`input[id*="title"]`,
}

var listing1688SellerFileInputSelectors = []string{
	`input[type="file"][accept*="image"]`,
	`input[type="file"]`,
}

var listing1688SellerSubmitPairs = [][2]string{
	{"button", "我要发布"},
	{"button", "提交"},
	{"button", "发布"},
}

var listing1688SellerPriceSelectors = []string{
	`input[name*="price"]`,
	`input[placeholder*="价格"]`,
}

var listing1688SellerSKUSelectors = []string{
	`input[name*="sku"]`,
	`input[placeholder*="SKU"]`,
	`input[placeholder*="货号"]`,
}
