package constants

// 应用信息
const (
	AgentTitle        = "Agent"
	AgentVersion      = "4.0.2"
	WsProtocol        = "ws"             // 本地开发：ws
	BaseServerAddress = "localhost:34206" // 本地开发服务器地址
)
