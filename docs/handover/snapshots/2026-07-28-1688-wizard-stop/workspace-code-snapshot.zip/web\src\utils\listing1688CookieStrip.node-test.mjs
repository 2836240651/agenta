/**
 * Node 静态单测：stripCookieKeys（无 vitest 时用 node 直接跑）
 * 运行：node src/utils/listing1688CookieStrip.node-test.mjs
 */
import { stripCookieKeys } from './listing1688CookieStrip.js'
import assert from 'node:assert/strict'

const nested = {
  workflow_id: 1,
  data: { Cookie: 'secret=abc', ok: true },
  list: [{ cookie: 'a=1', x: 2 }]
}
const out = stripCookieKeys(nested)
assert.equal(out.workflow_id, 1)
assert.equal(out.data.ok, true)
assert.equal('Cookie' in out.data, false)
assert.equal('cookie' in out.list[0], false)
assert.equal(out.list[0].x, 2)
assert.deepEqual(stripCookieKeys(null), null)
assert.deepEqual(stripCookieKeys([1, { cookie: 'x' }]), [1, {}])

console.log('listing1688CookieStrip.node-test: OK')
