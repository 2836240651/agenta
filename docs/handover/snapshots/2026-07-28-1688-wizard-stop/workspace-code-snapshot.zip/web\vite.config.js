import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import tailwindcss from '@tailwindcss/vite'
import path from 'path'

// https://vite.dev/config/
export default defineConfig({
  plugins: [vue(), tailwindcss()],
  optimizeDeps: {
    include: ['@vueuse/motion'],
  },
  server: {
    host: '0.0.0.0',  // 允许局域网访问，本机以外用 http://本机IP:5173
    port: 5173,
    strictPort: true,  // 端口被占用时直接报错，避免悄悄换成 5174
    open: true,        // 启动后自动打开浏览器，避免进不去
    proxy: {
      // 本地开发避免跨域：浏览器请求 /api/* 同源到 Vite，再由 Vite 转发到生产反代域名
      '/api': {
        target: 'http://localhost:34206',
        changeOrigin: true,
        secure: false,
      },
      // 本地 gpt-image-playground（需先在 playground 目录 npm run dev，默认 8787）
      '/gpt-image-playground': {
        target: 'http://127.0.0.1:8787',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/gpt-image-playground/, '') || '/',
      },
    },
    hmr: {
      overlay: true
    }
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
    }
  }
})
