package router

import "fmt"

func (r *Router) Run() error {
	c := fmt.Sprintf("%s:%d", r.Config.Get().Server.Host, r.Config.Get().Server.Port)
	r.Logger.Info("Running router on %s", c)
	return r.Engine.Run(c)
}
