package offer1688

import (
	"encoding/json"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

func TestExtractOfferID(t *testing.T) {
	url := "https://detail.1688.com/offer/1234567890.html"
	got := ExtractOfferID(url)
	if got != "1234567890" {
		t.Fatalf("ExtractOfferID(%q) = %q, want 1234567890", url, got)
	}
}

func TestIsCaptchaPage_DetectsTmd(t *testing.T) {
	html := `<html><body>_____tmd_____ captcha challenge</body></html>`
	if !IsCaptchaPage(html, "") {
		t.Fatal("expected IsCaptchaPage to detect _____tmd_____ marker")
	}
}

func TestIsCaptchaPage_TitleAndLateTmd(t *testing.T) {
	if !IsCaptchaPage(`<html><head><title>验证码拦截</title></head><body>ok</body></html>`, "https://www.1688.com/") {
		t.Fatal("expected title 验证码拦截")
	}
	pad := strings.Repeat("x", 25000)
	late := `<html><head><title>home</title></head><body>` + pad + `/_____tmd_____/verify/ SECDATA</body></html>`
	if !IsCaptchaPage(late, "https://www.1688.com/?spm=a260k.notfound&theme=index") {
		t.Fatal("expected late _____tmd_____ on notfound shell")
	}
}

func TestParseProductFromHTML_OGFallbackSyntheticSKU(t *testing.T) {
	html := `<!DOCTYPE html>
<html>
<head>
<meta property="og:title" content="测试商品标题">
<meta property="og:image" content="//cbu01.alicdn.com/img/ibank/test.jpg">
<script type="application/ld+json">{"@type":"Product","offers":{"price":"9.90"}}</script>
</head>
<body>
<script>var x={"subject":"备用 subject 标题"};</script>
</body>
</html>`

	url := "https://detail.1688.com/offer/9876543210.html"
	offerID := ExtractOfferID(url)
	res := ParseProductFromHTML(html, url, offerID, url)

	if !res.OK {
		t.Fatalf("expected ok, got status=%s error=%s", res.Status, res.Error)
	}
	if res.Status != "success" {
		t.Fatalf("status=%s, want success", res.Status)
	}
	if res.Title == "" {
		t.Fatal("expected title")
	}
	if !strings.Contains(res.Title, "测试商品标题") && !strings.Contains(res.Title, "备用") {
		t.Fatalf("unexpected title %q", res.Title)
	}
	if len(res.MainImages) < 1 {
		t.Fatal("expected ≥1 main image")
	}
	if !strings.HasPrefix(res.MainImages[0], "https:") {
		t.Fatalf("expected abs image url, got %q", res.MainImages[0])
	}
	if len(res.Skus) < 1 {
		t.Fatal("expected ≥1 sku (synthetic if needed)")
	}
	if res.Skus[0].Name != "默认" {
		t.Fatalf("expected synthetic sku name 默认, got %q", res.Skus[0].Name)
	}
	if res.Skus[0].Price == nil || *res.Skus[0].Price != 9.90 {
		t.Fatalf("expected synthetic sku price 9.90, got %+v", res.Skus[0].Price)
	}
	if res.OfferID != "9876543210" {
		t.Fatalf("offer id = %q", res.OfferID)
	}
}

func TestParseProductFromHTML_NoSKUNoPriceFails(t *testing.T) {
	html := `<html>
<meta property="og:title" content="仅标题无价">
<meta property="og:image" content="https://cbu01.alicdn.com/img/a.jpg">
</html>`
	res := ParseProductFromHTML(html, "https://detail.1688.com/offer/1.html", "1", "")
	if res.OK {
		t.Fatal("expected parse_fail when no sku and no price")
	}
	if res.Status != "parse_fail" {
		t.Fatalf("status=%s, want parse_fail", res.Status)
	}
}

func TestNormalizeURL(t *testing.T) {
	got := NormalizeURL("detail.1688.com/offer/1.html")
	if got != "https://detail.1688.com/offer/1.html" {
		t.Fatalf("got %q", got)
	}
}

func testdataPath(t *testing.T, name string) string {
	t.Helper()
	_, file, _, ok := runtime.Caller(0)
	if !ok {
		t.Fatal("runtime.Caller failed")
	}
	return filepath.Join(filepath.Dir(file), "testdata", name)
}

// TestParseProductFromHTML_InitDataCanonicalFields locks wizard snapshot keys
// consumed by M2 (main_images/title) and M3 (skus price/spec) — TC-C-05.
func TestParseProductFromHTML_InitDataCanonicalFields(t *testing.T) {
	raw, err := os.ReadFile(testdataPath(t, "init_data_offer.html"))
	if err != nil {
		t.Fatal(err)
	}
	url := "https://detail.1688.com/offer/9876543210123.html"
	offerID := ExtractOfferID(url)
	res := ParseProductFromHTML(string(raw), url, offerID, url)

	if !res.OK {
		t.Fatalf("expected ok, status=%s err=%s", res.Status, res.Error)
	}
	if strings.TrimSpace(res.Title) == "" {
		t.Fatal("canonical title empty")
	}
	if !strings.Contains(res.Title, "TC-C-05") {
		t.Fatalf("title=%q", res.Title)
	}
	if res.OfferID != "9876543210123" {
		t.Fatalf("source_item_id=%q", res.OfferID)
	}
	if res.URL != url {
		t.Fatalf("url=%q", res.URL)
	}
	if len(res.MainImages) < 1 {
		t.Fatal("canonical main_images empty")
	}
	for _, u := range res.MainImages {
		if !strings.HasPrefix(u, "https:") && !strings.HasPrefix(u, "http:") {
			t.Fatalf("main_images URL not absolute: %q", u)
		}
	}
	if len(res.Skus) < 1 {
		t.Fatal("canonical skus empty")
	}

	// JSON wire shape must use locked keys (not images / offer_id at root).
	wire, err := json.Marshal(res)
	if err != nil {
		t.Fatal(err)
	}
	var m map[string]any
	if err := json.Unmarshal(wire, &m); err != nil {
		t.Fatal(err)
	}
	for _, k := range []string{"title", "main_images", "skus", "source_item_id", "url", "price_min", "price_max"} {
		if _, ok := m[k]; !ok {
			t.Fatalf("missing canonical key %q in ProductResult JSON", k)
		}
	}
	if _, ok := m["images"]; ok {
		t.Fatal("root key images must not be canonical (use main_images)")
	}

	sku0, ok := m["skus"].([]any)[0].(map[string]any)
	if !ok {
		t.Fatal("sku[0] not object")
	}
	for _, k := range []string{"spec_attrs", "name", "price", "spec_id", "source_sku_id", "sku_key"} {
		if _, ok := sku0[k]; !ok {
			t.Fatalf("sku missing key %q: %#v", k, sku0)
		}
	}
	if sku0["spec_attrs"] != sku0["name"] {
		t.Fatalf("name must alias spec_attrs: %#v", sku0)
	}
	if res.PriceMin == nil || res.PriceMax == nil {
		t.Fatal("expected price_min/price_max from skus")
	}
	if *res.PriceMin > *res.PriceMax {
		t.Fatalf("price_min=%v > price_max=%v", *res.PriceMin, *res.PriceMax)
	}
}

// TestSample1688DirectShape_DocumentsSourceAuthority ensures the synthetic
// 1688- shape fixture still carries the keys we ported from fetch_1688_offer.py.
func TestSample1688DirectShape_DocumentsSourceAuthority(t *testing.T) {
	raw, err := os.ReadFile(testdataPath(t, "sample_1688_direct_shape.json"))
	if err != nil {
		t.Fatal(err)
	}
	var sample map[string]any
	if err := json.Unmarshal(raw, &sample); err != nil {
		t.Fatal(err)
	}
	for _, k := range []string{"title", "main_images", "skus", "source_item_id", "url", "price_range"} {
		if _, ok := sample[k]; !ok {
			t.Fatalf("1688- sample missing %q", k)
		}
	}
	skus, ok := sample["skus"].([]any)
	if !ok || len(skus) < 1 {
		t.Fatal("sample skus")
	}
	sku0 := skus[0].(map[string]any)
	for _, k := range []string{"sku_key", "spec_attrs", "price", "source_sku_id", "spec_id"} {
		if _, ok := sku0[k]; !ok {
			t.Fatalf("sample sku missing %q", k)
		}
	}
	pr, ok := sample["price_range"].(map[string]any)
	if !ok {
		t.Fatal("price_range")
	}
	if pr["min"] == nil || pr["max"] == nil {
		t.Fatalf("price_range incomplete: %#v", pr)
	}
}
