package router

import (
	"context"

	"commander-server-t260220/internal/crontabs"
	"commander-server-t260220/internal/manager"
	"commander-server-t260220/internal/middleware"
	"commander-server-t260220/internal/services"
	"commander-server-t260220/internal/utils"

	"github.com/gin-gonic/gin"
)

// 路由层
type Router struct {
	Engine        *gin.Engine
	Logger        *utils.LoggerUtils
	Config        *utils.ConfigUtils
	Service       *services.Service
	Middleware    *middleware.Middleware
	WorkerManager *manager.WorkerManager
	Crontab       *crontabs.Crontab
}

func NewRouter(
	logger *utils.LoggerUtils,
	config *utils.ConfigUtils,
	service *services.Service,
	middleware *middleware.Middleware,
	workerManager *manager.WorkerManager,
	crontab *crontabs.Crontab,
) *Router {
	return &Router{
		Engine:        gin.Default(),
		Logger:        logger,
		Config:        config,
		Service:       service,
		Middleware:    middleware,
		WorkerManager: workerManager,
		Crontab:       crontab,
	}
}

// Prepare 启动前准备：恢复未完成任务并启动定时任务（注册后随路由启动）
func (r *Router) Prepare() {
	_ = r.WorkerManager.RecoverFromStore(context.Background())
	if r.Crontab != nil {
		r.Crontab.Run()
	}
}
