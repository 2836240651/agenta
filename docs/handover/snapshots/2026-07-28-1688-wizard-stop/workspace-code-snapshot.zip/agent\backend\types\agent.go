package types

// 服务端发送给 Agent 处理产品上架的请求
type AgentProductIssue struct {
	AgentId            string                           `json:"-"` // AgentID
	TaskId             string                           `json:"-"` // 任务ID
	UserId             uint                             `json:"-"` // 用户ID
	UserName           string                           `json:"-"` // 用户名
	Url                string                           `json:"-"` // 图片在线地址(原始图片)
	Query              string                           `json:"-"` // 产品描述
	CategoryId         string                           `json:"categoryId"`
	CategoryAttributes string                           `json:"categoryAttributes"` // 产品类目属性
	ShopId             string                           `json:"shopId"`
	VariationList      []AgentProductIssueVariationList `json:"variants"` // 服务端发送 variants
	TitleZh            string                           `json:"titleZh"`  // 根级中文标题(服务端可能直接发送)
	TitleEn            string                           `json:"titleEn"`  // 根级英文标题(服务端可能直接发送)
	TitleRu            string                           `json:"titleRu"`  // 根级俄罗斯语标题(服务端可能直接发送)
	Images             []AgentProductIssueImages        `json:"images"`
	PeerUrl            string                           `json:"peerUrl"`        // 1688 同行链接（采集图优链路）
	SourceImages       []string                         `json:"sourceImages"`   // 采集原图（审计/调试）
}
type AgentProductIssueVariationList struct {
	Url     string  `json:"url"`
	Index   string  `json:"index"`
	Model   string  `json:"model"`
	Count   string  `json:"count"`
	Price   float64 `json:"price"`
	ExtCode string  `json:"extCode"`
	Length  int     `json:"length"`
	Width   int     `json:"width"`
	Height  int     `json:"height"`
	Weight  int     `json:"weight"`
}
type AgentProductIssueImages struct {
	ImageUrl string `json:"url"` // 图片在线地址(服务端发送 url)
	Prompt   string `json:"prompt"`
	Status   string `json:"status"` // 状态(success | error | running) 运行中,成功,失败
	Message  string `json:"message"`
}
