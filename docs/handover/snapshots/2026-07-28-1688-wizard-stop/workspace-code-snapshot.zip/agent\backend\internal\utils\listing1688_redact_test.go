package utils

import (
	"strings"
	"testing"

	"commander-agent-t260220/backend/types"
)

func TestListing1688RedactCookiePlain(t *testing.T) {
	got := Listing1688RedactCookiePlain("a=1;b=2")
	if strings.Contains(got, "a=1") {
		t.Fatalf("leaked: %q", got)
	}
	if !strings.Contains(got, "len=7") {
		t.Fatalf("want len, got %q", got)
	}
}

func TestListing1688RedactAgentMessageCopy_DoesNotMutateOriginal(t *testing.T) {
	orig := types.AgentMessage[any, any]{
		Protocol: "listing1688_probe",
		Send:     map[string]any{"cookie": "secret=xyz"},
	}
	safe := Listing1688RedactAgentMessageCopy(orig)
	sendOrig, _ := orig.Send.(map[string]any)
	if sendOrig["cookie"] != "secret=xyz" {
		t.Fatalf("original mutated: %#v", orig.Send)
	}
	sendSafe, _ := safe.Send.(map[string]any)
	s, _ := sendSafe["cookie"].(string)
	if strings.Contains(s, "secret=xyz") || !strings.HasPrefix(s, "***") {
		t.Fatalf("safe cookie=%q", s)
	}
}

func TestListing1688RedactCookieInJSON_ReceiveExport(t *testing.T) {
	raw := []byte(`{"protocol":"listing1688_export_cookie","receive":{"data":{"cookie":"a=1;b=2"}}}`)
	out := Listing1688RedactCookieInJSON(raw)
	if strings.Contains(out, "a=1") {
		t.Fatalf("export receive leaked: %s", out)
	}
}
