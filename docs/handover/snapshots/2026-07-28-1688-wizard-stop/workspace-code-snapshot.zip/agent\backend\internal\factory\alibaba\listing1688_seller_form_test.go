package alibaba

import (
	"reflect"
	"testing"
)

func TestListing1688SellerRequiredFieldsFromPageText(t *testing.T) {
	text := "*产品类别\n*钓钩种类\n*品牌\n*是否有倒刺\n产品规格\n*规格\n*计量单位\n*图文详情\n保存草稿"
	want := []string{"产品类别", "钓钩种类", "品牌", "是否有倒刺", "规格", "计量单位", "图文详情"}
	if got := listing1688SellerRequiredFieldsFromPageText(text); !reflect.DeepEqual(got, want) {
		t.Fatalf("required fields=%#v, want=%#v", got, want)
	}
}

func TestListing1688SellerValidationErrorsFromPageText(t *testing.T) {
	text := "第1行的发货时间为必填项\n重量不能为空\n请填写图文详情\n保存草稿"
	want := []string{"第1行的发货时间为必填项", "重量不能为空", "请填写图文详情"}
	if got := listing1688SellerValidationErrorsFromPageText(text); !reflect.DeepEqual(got, want) {
		t.Fatalf("validation errors=%#v, want=%#v", got, want)
	}
}
func TestListing1688SellerDraftSaveConfirmed(t *testing.T) {
	if !listing1688SellerDraftSaveConfirmed("草稿保存成功，可在草稿箱继续编辑") {
		t.Fatal("explicit draft save success must be accepted")
	}
	if listing1688SellerDraftSaveConfirmed("保存草稿") {
		t.Fatal("button text alone must not be treated as draft save success")
	}
}
func TestListing1688SellerVerifiedBindings(t *testing.T) {
	bindings := listing1688SellerVerifiedBindings()
	if bindings["title"] == "" || bindings["save_draft"] == "" || bindings["submit"] == "" {
		t.Fatalf("verified bindings=%#v", bindings)
	}
	for _, unsafeField := range []string{"brand", "shipping_template_id", "weight_kg"} {
		if bindings[unsafeField] != "" {
			t.Fatalf("unsafe binding %s=%q", unsafeField, bindings[unsafeField])
		}
	}
}

func TestListing1688SellerResolvePublishTitleImages(t *testing.T) {
	title, images := listing1688SellerResolvePublishTitleImages("", nil, map[string]any{
		"title":  "  hook title  ",
		"images": []any{" https://cdn.example/a.png ", "", "https://cdn.example/b.png"},
	})
	if title != "hook title" {
		t.Fatalf("title=%q", title)
	}
	if len(images) != 2 || images[0] != "https://cdn.example/a.png" {
		t.Fatalf("images=%#v", images)
	}
	title2, images2 := listing1688SellerResolvePublishTitleImages("top", []string{"https://cdn.example/top.png"}, map[string]any{
		"title":  "form",
		"images": []string{"https://cdn.example/form.png"},
	})
	if title2 != "top" || len(images2) != 1 || images2[0] != "https://cdn.example/top.png" {
		t.Fatalf("top-level must win: title=%q images=%#v", title2, images2)
	}
}
