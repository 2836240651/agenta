package constants

const (
	WsTaskStatusSuccess = "success"    // 成功
	WsTaskStatusFailed  = "failed"     // 失败
	WsTaskStatusRunning = "processing" // 运行中
)

const (
	WsServerAddress  = BaseServerAddress      // 服务器地址
	WsServerPath     = "/api/v1/agent/online" // 服务器路径
	WsServerProtocol = WsProtocol             // 服务器协议
)
